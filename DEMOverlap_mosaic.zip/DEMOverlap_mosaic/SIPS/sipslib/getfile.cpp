#include<string.h>
#include<stdio.h>
#include "sips.h"

/*
	Function Name	-	int kchead::getfilename(char infile[],int num,char outfile[], char str[])
	Descr			-	This gets the filename with the extension passed
	Input			-	infile -> input file name 
						num	   -> number to be added to input file name 
						outfile-> output file name 
						str    -> string to be added after 
	Output			-	none.
*/
void kchead::getfilename(char infile[],int num,char outfile[], char str[])
{
	char x[KD_STRING_SIZE];
	int count=0;

	if ( num < 0)
		strcpy(x,"");   /*	 for pla data */
	else
		sprintf(x,"%d",num);

	strcpy(outfile,infile);
	count--;

	strcat(outfile,x);
	strcat(outfile,".");
	strcat(outfile,str);
return;
}

