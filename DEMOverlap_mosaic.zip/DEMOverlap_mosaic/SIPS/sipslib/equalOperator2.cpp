#include "sips.h"
#include <string.h>

kchead kchead::operator=(  kchead& Obj)
{
	KT_HEAD temp;
	int i, j;
	strcpy(temp.m_psatellite_type, Obj.m_psatellite_type);
	strcpy(temp.m_psensor_type, Obj.m_psensor_type);
	strcpy(temp.m_pcamera_type, Obj.m_pcamera_type);
	strcpy(temp.m_pdate, Obj.m_pdate);
	strcpy(temp.m_pscene_descr, Obj.m_pscene_descr);
	temp.m_ppath = Obj.m_ppath;
	temp.m_prow = Obj.m_prow;
	for(i=0;i<5;i++)
		for(j=0;j<3;j++)
			temp.m_pcoord_scan_lat.coord[i][j] = Obj.m_pcoord_scan_lat.coord[i][j];
	for(i=0;i<5;i++)
		for(j=0;j<2;j++)
			temp.m_pcoord_scan_lat.scan_pix[i][j] = Obj.m_pcoord_scan_lat.scan_pix[i][j];
	temp.m_pcoord_scan_lat;
	temp.m_pbands = Obj.m_pbands;
	temp.m_pbandno = Obj.m_pbandno;
	temp.m_pscans = Obj.m_pscans;
	temp.m_ppixels = Obj.m_ppixels;
	temp.m_popno = Obj.m_popno;
	strcpy(temp.m_popcode, Obj.m_popcode);
	strcpy(temp.m_pco_ord_sys,Obj.m_pco_ord_sys); /* new fields */
	strcpy(temp.m_pdatum, Obj.m_pdatum);
	strcpy(temp.m_pproduct_code, Obj.m_pproduct_code);
	strcpy(temp.m_pmap_proj, Obj.m_pmap_proj);
	temp.m_pn_resolution = Obj.m_pn_resolution;
	temp.m_pview_angle = Obj.m_pview_angle;
	temp.m_psubleft_scan = Obj.m_psubleft_scan;
	temp.m_psubleft_pixel = Obj.m_psubleft_pixel;
	//strcpy(temp.m_pmode, Obj.m_pmode);
	temp.m_pmode[0]=Obj.m_pmode[0];
	temp.m_ppayload_angle = Obj.m_ppayload_angle;
	temp.m_ptruser_defined = Obj.m_ptruser_defined;

	return temp;
}
