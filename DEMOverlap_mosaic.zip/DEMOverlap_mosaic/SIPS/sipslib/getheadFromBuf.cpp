#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>


#include "sips.h"


/*
	Function Name	-	void kchead::Coord_lat(KT_coord_scan_pix *xyz, char *str)
	Descr			-	splits the string into values of corresponding fields & assign them
	Input			-	coord_scan_pix struct & string 
	Output			-	none.

void kchead::Coord_lat(KT_coord_scan_pix *xyz, char *str)
{
	int length,i=0,j=0,p,k;
	char st[KD_STRING_SIZE];
	length=strlen(str);
	while((i<5) && (j<length))
		{
		for(p=0;p<3;p++)
			{
			k=0;
			while(str[j]!=' ')
				{
				st[k]=str[j];
				k++;j++;
				}
			j++;
			st[k]='\0';
			xyz->coord[i][p]=float(atof(st));
			}
		i++;
		}
	i=0;
	while((i<5) && (j<length))
		{
		for(p=0;p<2;p++)
			{
			k=0;
			while(str[j]!=' ')
				{
				st[k]=str[j];
				k++;j++;
				}
			j++;
			st[k]='\0'; 
			xyz->scan_pix[i][p]=atoi(st);
			}
		i++;
		}
}
*/
/*
	Function Name	-	int kchead::getheaderFromBuf(char *buffer)
	Descr			-	gets the contents of header of aips image 
	Input			-	buffer -> containing header info.
	Output			-	header size.
*/
int kchead::getheaderFromBuf(char * &buffer)
{

	//char buffer[KD_MAX_SIZE];
	int i,j,p=2;
	//FILE *fp;

	int header_size;
	int buffer_pointer;
	int data_pointer;
	int fieldno;
	int field_length;
	int table_size;
	char string[KD_STRING_SIZE];


	/*if ((fp=fopen(file,"rb"))==NULL){
		printf("File  %s  not found ! Exiting \n",file);
		return(-4);
	}
	fseek(fp,10,0); 
	i=fread(string,sizeof (char),KD_SIZE_HEADER,fp);
	string[KD_SIZE_HEADER] = '\0'; 
	header_size = atoi(string);
	fseek(fp,0,0);

	fread(buffer,sizeof (char),header_size,fp);
	fclose(fp);
	buffer[header_size-1]='\0';*/
	header_size = KD_MAX_SIZE;
	buffer[KD_MAX_SIZE-1]='\0';

	for(i=0;i<10;i++)
		string[i] = buffer[i];
	string[10]='\0';

	if (strcmp(string,"AdRiN2001#") != 0)
		{
		//printf("Not in aips format\n");
		return(-5);
		}

	for(i=10+KD_SIZE_HEADER,j=0;j<KD_POINTER_HEADER_TABLE;j++)
	{
		string[j]=buffer[i];
		i++;
	}
	string[j]='\0';
	buffer_pointer=atoi(string);

	for(i=10+KD_SIZE_HEADER+KD_POINTER_HEADER_TABLE,j=0;j<KD_SIZE_HEADER_TABLE;j++)
	{
		string[j]=buffer[i];
		i++;
	}
	string[j]='\0';
	table_size=atoi(string);
	for(i=10+KD_SIZE_HEADER+KD_POINTER_HEADER_TABLE+KD_SIZE_HEADER_TABLE,j=0;j<KD_POINTER_HEADER_DATA;j++){
		string[j]=buffer[i];
		i++;
	}
	string[j]='\0';
	data_pointer = atoi(string);
	m_ptruser_defined=NULL;
 	while(data_pointer < header_size )
		{
		if(buffer_pointer>=(table_size+28)) break;
		
		sscanf(&buffer[buffer_pointer],"%s",string);
		buffer_pointer += (1+strlen(string));
		fieldno = atoi(string);

		sscanf(&buffer[buffer_pointer],"%s",string);
		buffer_pointer += (1+strlen(string));
		field_length = atoi(string);
	
		for(j=0;j<field_length;j++)
			{
			string[j]=buffer[data_pointer];
			data_pointer++;
			}
		string[field_length]='\0';
		if(fieldno>=50) fieldno=50;
		switch(fieldno){

		case 1 :
			strcpy(m_psatellite_type,string);
			break;

		case 2 :
			strcpy(m_psensor_type,string);
			break;

		case 3 :
			strcpy(m_pcamera_type,string);
			break;

		case 4 :
			strcpy(m_pdate,string);
			break;

		case 5 :
			strcpy(m_pscene_descr,string);
			break;

		case 6 :
			m_ppath = atoi(string);
			break;

		case 7 :
			m_prow = atoi(string);
			break;

		case 8 :
			Coord_lat(&(m_pcoord_scan_lat),string);
			break;

		case 9 :
			m_pbands=atoi(string);
			break;
		case 10 :
			m_pbandno=atoi(string);
			break;

		case 11 :
			m_pscans=atoi(string);
			break;

		case 12 :
			m_ppixels=atoi(string);
			break;

		case 13 :
			m_popno=atoi(string);
			break;

		case 14 :
			strcpy(m_popcode,string);
			break;

		case 15 :
			strcpy(m_pco_ord_sys,string);
			break;
		case 16 :
			strcpy(m_pdatum,string);
			break;
		case 17 :
			strcpy(m_pproduct_code,string);
			break;
		case 18 :
			strcpy(m_pmap_proj,string);
			break;
		case 19 :
			m_pn_resolution=float(atof(string));
			break;
		case 20 :
			m_pview_angle=float(atof(string));
			break;
		case 21 :
			m_psubleft_scan=atoi(string);
			break;
		case 22 :
			m_psubleft_pixel=atoi(string);
			break;
		case 23 :
			strncpy(m_pmode,string,1);break;
		case 24 :
			m_ppayload_angle=float(atof(string));break;
		case 50  :
		{
			if(m_pUserDefineCount== 0)  //this is added by  tirupathi on 30/01/08.
			{
               m_ptruser_defined=(char **) malloc((p)*sizeof(char *));  
		       m_ptruser_defined[p-2]=(char *) malloc((strlen(string)+1) * sizeof(char));
			   m_ptruser_defined[p-1]=(char *) malloc(5 * sizeof(char));
			}
			else
			{
			   m_ptruser_defined=(char **) realloc(m_ptruser_defined,(p)*sizeof(char *));
			   m_ptruser_defined[p-2]=(char *) realloc(m_ptruser_defined[p-2],(strlen(string)+1) * sizeof(char));
			   m_ptruser_defined[p-1]=(char *) malloc(5 * sizeof(char));
			}

			strcpy(m_ptruser_defined[p-2],string);
			strcpy(m_ptruser_defined[p-1],"NULL");
			m_pUserDefineCount=p;//added by tirupathi, to delete m_ptruser_defined in kchead destructor.
			p++;
			/*m_ptruser_defined=new char*[p+1];
			m_ptruser_defined[p-1]=new char[5];
			m_ptruser_defined[p]=new char[5];
			strcpy(m_ptruser_defined[p-1],string);
			strcpy(m_ptruser_defined[p],"NULL");
			p++;
			m_pUserDefineCount=p;*/

			}break;
		}
	}
	
/*	m_ptruser_defined=(char **) realloc(m_ptruser_defined,(p+1)*sizeof(char *));
	m_ptruser_defined[p]=(char *) malloc(strlen(string) * sizeof(char));
	strcpy(m_ptruser_defined[p],"NULL");*///--------commented by tirupathi on 14/09/07.
	
	return(header_size);

}

