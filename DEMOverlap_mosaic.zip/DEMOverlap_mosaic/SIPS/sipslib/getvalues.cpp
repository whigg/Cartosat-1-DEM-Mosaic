
#include<stdarg.h>
#include<string.h>
#include"sips.h"

/*
	Function Name	-	void kchead::getvalues(int first, ...)
	Descr			-	It is for assigning values to one or more member variables of kchead class
	Input			-	pair of (constant, value) & last argument will always be NULL
						constant -> identifier of the member varible field, 
						value -> contains the value of the member variable, set inside the function 
	Output			-	none
	Remark			-   This function does not get the value of m_ptruser_defined field
*/
void kchead::getvalues( int first, ... )
{
   int count = 0, sum = 0, constant = first, *value, i, j;
   float *fvalue;
   char *str;
   KT_coord_scan_pix *coord_value;
   char **char_value;
   va_list marker;
   
   va_start( marker, first );     /* Initialize variable arguments. */
   while( constant != NULL )
   {
	   switch(constant)
		{
		case KD_PATH:
			value = (va_arg( marker, int *));
			*value = m_ppath;
			break;
		case KD_ROW:
			value = (va_arg( marker, int *));
			*value = m_prow;
			break;
		case KD_BANDS:
			value = (va_arg( marker, int *));
			*value = m_pbands;
			break;
		case KD_BANDNO:
			value = (va_arg( marker, int *));
			*value = m_pbandno;
			break;
		case KD_SCANS:
			value = (va_arg( marker, int *));
			*value = m_pscans;
			break;
		case KD_PIXELS:
			value = (va_arg( marker, int *));
			*value = m_ppixels;
			break;
		case KD_OPNO:
			value = (va_arg( marker, int *));
			*value = m_popno;
			break;
		case KD_SUBLEFT_SCAN:
			value = (va_arg( marker, int *));
			*value = m_psubleft_scan;
			break;
		case KD_SUBLEFT_PIXEL:
			value = (va_arg( marker, int *));
			*value = m_psubleft_pixel;
			break;
		case KD_N_RESOLUTION:
			fvalue = (va_arg( marker, float *));
			*fvalue = m_pn_resolution;
			break;
		case KD_VIEW_ANGLE:
			fvalue = (va_arg( marker, float *));
			*fvalue = m_pview_angle;
			break;
		case KD_PAYLOAD_ANGLE:
			fvalue = (va_arg( marker, float *));
			*fvalue = m_ppayload_angle;
			break;
		case KD_SAT_TYPE:
			str = (va_arg( marker, char *));
			strcpy(str, m_psatellite_type);
			break;
		case KD_SENSOR_TYPE:
			str = (va_arg( marker, char *));
			strcpy(str, m_psensor_type);
			break;
		case KD_CAMERA_TYPE:
			str = (va_arg( marker, char *));
			strcpy(str, m_pcamera_type);
			break;
		case KD_DATE:
			str = (va_arg( marker, char *));
			strcpy(str, m_pdate);
			break;
		case KD_SCENE_DESCR:
			str = (va_arg( marker, char *));
			strcpy(str, m_pscene_descr);
			break;
		case KD_OPCODE:
			str = (va_arg( marker, char *));
			strcpy(str, m_popcode);
			break;
		case KD_CO_ORD_SYS:
			str = (va_arg( marker, char *));
			strcpy(str, m_pco_ord_sys);
			break;
		case KD_DATUM:
			str = (va_arg( marker, char *));
			strcpy(str, m_pdatum);
			break;
		case KD_PRODUCT_CODE:
			str = (va_arg( marker, char *));
			strcpy(str, m_pproduct_code);
			break;
		case KD_MAP_PROJ:
			str = (va_arg( marker, char *));
			strcpy(str, m_pmap_proj);
			break;
		case KD_MODE:
			str = (va_arg( marker, char *));
			//strcpy(str, m_pmode);
			str[0]=m_pmode[0];
			break;
		case KD_COORD_SCAN_LAT:
			coord_value = (va_arg( marker, KT_coord_scan_pix *));
			for(i=0; i<5; i++)
				for(j=0; j<3; j++)
					(*coord_value).coord[i][j] = m_pcoord_scan_lat.coord[i][j];

			for(i=0; i<5; i++)
				for(j=0; j<2; j++)
					(*coord_value).scan_pix[i][j] = m_pcoord_scan_lat.scan_pix[i][j];
			break;
		case KD_USER_DEFINED://---------Uncommented by tirupathi on 16/10/07.
			char_value = (va_arg( marker, char **));
			char_value = m_ptruser_defined;
			break;
		default:
			//cout << "Not a valid field.\n";
			value = NULL; 
			break;
		}

      constant = va_arg( marker, int);
   }
   va_end( marker );              /* Reset variable arguments.      */
   return ;
}
