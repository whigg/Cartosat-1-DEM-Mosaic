#include<string.h>


#include "sips.h"

KT_HEAD kchead::operator=(const KT_HEAD& Obj)
{
//	KT_HEAD temp;
	int i, j;
	strcpy(m_psatellite_type, Obj.m_psatellite_type);
	strcpy(m_psensor_type, Obj.m_psensor_type);
	strcpy(m_pcamera_type, Obj.m_pcamera_type);
	strcpy(m_pdate, Obj.m_pdate);
	strcpy(m_pscene_descr, Obj.m_pscene_descr);
	m_ppath = Obj.m_ppath;
	m_prow = Obj.m_prow;
	for(i=0;i<5;i++)
		for(j=0;j<3;j++)
			m_pcoord_scan_lat.coord[i][j] = Obj.m_pcoord_scan_lat.coord[i][j];
	for(i=0;i<5;i++)
		for(j=0;j<2;j++)
			m_pcoord_scan_lat.scan_pix[i][j] = Obj.m_pcoord_scan_lat.scan_pix[i][j];
	m_pcoord_scan_lat;
	m_pbands = Obj.m_pbands;
	m_pbandno = Obj.m_pbandno;
	m_pscans = Obj.m_pscans;
	m_ppixels = Obj.m_ppixels;
	m_popno = Obj.m_popno;
	strcpy(m_popcode, Obj.m_popcode);
	strcpy(m_pco_ord_sys,Obj.m_pco_ord_sys); /* new fields */
	strcpy(m_pdatum, Obj.m_pdatum);
	strcpy(m_pproduct_code, Obj.m_pproduct_code);
	strcpy(m_pmap_proj, Obj.m_pmap_proj);
	m_pn_resolution = Obj.m_pn_resolution;
	m_pview_angle = Obj.m_pview_angle;
	m_psubleft_scan = Obj.m_psubleft_scan;
	m_psubleft_pixel = Obj.m_psubleft_pixel;
//	strcpy(m_pmode, Obj.m_pmode);
	m_pmode[0]=Obj.m_pmode[0];
	m_ppayload_angle = Obj.m_ppayload_angle;
	m_ptruser_defined = Obj.m_ptruser_defined;
	m_pUserDefineCount=0;
	

	return *this;
}
