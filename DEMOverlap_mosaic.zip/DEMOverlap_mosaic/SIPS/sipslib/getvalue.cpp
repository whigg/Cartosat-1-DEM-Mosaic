#include <string.h>
#include "sips.h"

/*
	Function Name	-	void kchead::getvalue(int constant, int &value)
	Descr			-	It is for accessing value of integer member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						value -> contains the value of the member variable, set inside this function 
	Output			-	none
*/
void kchead::getvalue(int constant, int &value)   
{
	switch(constant)
	{
	case KD_PATH:
		value = m_ppath;
		break;
	case KD_ROW:
		value = m_prow;
		break;
	case KD_BANDS:
		value = m_pbands;
		break;
	case KD_BANDNO:
		value = m_pbandno;
		break;
	case KD_SCANS:
		value = m_pscans;
		break;
	case KD_PIXELS:
		value = m_ppixels;
		break;
	case KD_OPNO:
		value = m_popno;
		break;
	case KD_SUBLEFT_SCAN:
		value = m_psubleft_scan;
		break;
	case KD_SUBLEFT_PIXEL:
		value = m_psubleft_pixel;
		break;
	default:
		//cout << "Not a valid field.\n";
		value = NULL; 
		break;
	}
}

/*
	Function Name	-	void kchead::getvalue(int constant, float &value)
	Descr			-	It is for accessing value of float member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						value -> contains the value of the member variable, set inside this function 
	Output			-	none
*/
void kchead::getvalue(int constant, float &value)   
{
	switch(constant)
	{
	case KD_N_RESOLUTION:
		value = m_pn_resolution;
		break;
	case KD_VIEW_ANGLE:
		value = m_pview_angle;
		break;
	case KD_PAYLOAD_ANGLE:
		value = m_ppayload_angle;
		break;
	default:
		//cout << "Not a valid field.\n";
		value = NULL;
		break;
	}
}

/*
	Function Name	-	void kchead::getvalue(int constant, char str[])
	Descr			-	It is for accessing value of string member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						str -> contains the value of the member variable, set inside this function 
	Output			-	none
*/
void kchead::getvalue(int constant, char str[])    
{
	switch(constant)
	{
	case KD_SAT_TYPE:
		strcpy(str, m_psatellite_type);
		break;
	case KD_SENSOR_TYPE:
		strcpy(str, m_psensor_type);
		break;
	case KD_CAMERA_TYPE:
		strcpy(str, m_pcamera_type);
		break;
	case KD_DATE:
		strcpy(str, m_pdate);
		break;
	case KD_SCENE_DESCR:
		strcpy(str, m_pscene_descr);
		break;
	case KD_OPCODE:
		strcpy(str, m_popcode);
		break;
	case KD_CO_ORD_SYS:
		strcpy(str, m_pco_ord_sys);
		break;
	case KD_DATUM:
		strcpy(str, m_pdatum);
		break;
	case KD_PRODUCT_CODE:
		strcpy(str, m_pproduct_code);
		break;
	case KD_MAP_PROJ:
		strcpy(str, m_pmap_proj);
		break;
	case KD_MODE:
		//strcpy(str, m_pmode);
		str[0]=m_pmode[0];
		break;
	default:
		//cout << "Not a valid field.\n";
		strcpy(str, "\0");
		break;
	}
}

/*
	Function Name	-	void kchead::getvalue(int constant, KT_coord_scan_pix str[])
	Descr			-	It is for accessing value of KT_coord_scan_pix member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						value -> contains the value of the member variable, set inside this function 
	Output			-	none
*/
void kchead::getvalue(int constant, KT_coord_scan_pix &value)   
{															   
	int i, j;

	switch(constant)
	{
	case KD_COORD_SCAN_LAT:
		for(i=0; i<5; i++)
			for(j=0; j<3; j++)
				value.coord[i][j] = m_pcoord_scan_lat.coord[i][j];

		for(i=0; i<5; i++)
			for(j=0; j<2; j++)
				value.scan_pix[i][j] = m_pcoord_scan_lat.scan_pix[i][j];
		break;

	default:
		//cout << "Not a valid field.\n";
	//	value = NULL;
		break;
	}
}

void kchead::getvalue(int constant, KT_sub_head &value)   
{															   
	int i;

	switch(constant)
	{
	case KD_SUB_HEAD:
		strcpy(value.Satellite,m_psub_head.Satellite);
		strcpy(value.Camera,m_psub_head.Camera);
		value.GR_orbit=m_psub_head.GR_orbit;
		value.IR_orbit=m_psub_head.IR_orbit;
		strcpy(value.Acq_stn_id,m_psub_head.Acq_stn_id);
		strcpy(value.Pass_type,m_psub_head.Pass_type);
		strcpy(value.Date_receiving,m_psub_head.Date_receiving);
		strcpy(value.Date_imaging,m_psub_head.Date_imaging);
		value.No_of_target=m_psub_head.No_of_target;
		strcpy(value.Org_name,m_psub_head.Org_name);
		value.Sourceid_ORB_flag=m_psub_head.Sourceid_ORB_flag;
		value.Sourceid_ATD_flag=m_psub_head.Sourceid_ATD_flag;
		strcpy(value.Segment_no,m_psub_head.Segment_no);
		strcpy(value.PL_ontime,m_psub_head.PL_ontime);
		strcpy(value.PL_offtime,m_psub_head.PL_offtime);
		value.Data_quality_str1=m_psub_head.Data_quality_str1;
		value.Data_quality_str2=m_psub_head.Data_quality_str2;
		for(i=0;i<2;i++)
			value.LatLon_middleleft[i]=m_psub_head.LatLon_middleleft[i];
		for(i=0;i<2;i++)
			value.LatLon_middleright[i]=m_psub_head.LatLon_middleright[i];
		for(i=0;i<2;i++)
			value.Scpix_middleleft[i]=m_psub_head.Scpix_middleleft[i];
		for(i=0;i<2;i++)
			value.Scpix_middleright[i]=m_psub_head.Scpix_middleright[i];
		strcpy(value.Seg_starttime,m_psub_head.Seg_starttime);
		strcpy(value.Seg_centertime,m_psub_head.Seg_centertime);
		strcpy(value.Seg_endtime,m_psub_head.Seg_endtime);
		value.GR_sc_vel=m_psub_head.GR_sc_vel;
		value.Integration_time=m_psub_head.Integration_time;
		value.Satellite_altitude=m_psub_head.Satellite_altitude;
		value.Satellite_heading=m_psub_head.Satellite_heading;
		value.Image_heading=m_psub_head.Image_heading;
		value.Sun_elevation=m_psub_head.Sun_elevation;
		value.Sun_azimuth=m_psub_head.Sun_azimuth;
		value.Angle_incidence=m_psub_head.Angle_incidence;
		value.Line_resolution=m_psub_head.Line_resolution;
		value.Oversampling_factor=m_psub_head.Oversampling_factor;
		value.Image_mode=m_psub_head.Image_mode;
		value.Mono_stereo_flag=m_psub_head.Mono_stereo_flag;
		value.PrePostfacto_flag=m_psub_head.PrePostfacto_flag;
		strcpy(value.Related_Image,m_psub_head.Related_Image);
		break;

	default:
		//cout << "Not a valid field.\n";
	//	value = NULL;
		break;
	}
}
/*
	Function Name	-	void kchead::getvalue(int constant, char** str[])
	Descr			-	It is for accessing value of char** member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						value -> contains the value of the member variable, set inside this function 
	Output			-	none
*/
void kchead::getvalue(int constant, char** value)			
{
	switch(constant)
	{
	case KD_USER_DEFINED:
		value = m_ptruser_defined;
		break;
	default:
		//cout << "Not a valid field.\n";
		value = NULL;
		break;
	}
}























