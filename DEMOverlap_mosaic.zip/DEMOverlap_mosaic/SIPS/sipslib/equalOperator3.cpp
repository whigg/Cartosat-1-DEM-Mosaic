#include "sips.h"

kchead kchead::operator=(  kchead & Obj)
{
    KT_HEAD temp;
    char *str;
    int ivalue;
    float fvalue;
    KT_coord_scan_pix Coord;

    str = new char[100];
    Obj.getvalue(KD_SAT_TYPE, str);
    this->setvalue(KD_SAT_TYPE, str);
    Obj.getvalue(KD_SENSOR_TYPE, str);
    this->setvalue(KD_SENSOR_TYPE, str);
    Obj.getvalue(KD_CAMERA_TYPE, str);
    this->setvalue(KD_CAMERA_TYPE, str);
    Obj.getvalue(KD_DATE, str);
    this->setvalue(KD_DATE, str);
    Obj.getvalue(KD_SCENE_DESCR, str);
    this->setvalue(KD_SCENE_DESCR, str);
    Obj.getvalue(KD_PATH, ivalue);
    this->setvalue(KD_PATH, ivalue);
    Obj.getvalue(KD_ROW, ivalue);
    this->setvalue(KD_ROW, ivalue);
    Obj.getvalue(KD_COORD_SCAN_LAT, Coord);
    this->setvalue(KD_COORD_SCAN_LAT, Coord);
    Obj.getvalue(KD_BANDS, ivalue);
    this->setvalue(KD_BANDS, ivalue);
    Obj.getvalue(KD_BANDNO, ivalue);
    this->setvalue(KD_BANDNO, ivalue);
    Obj.getvalue(KD_SCANS, ivalue);
    this->setvalue(KD_SCANS, ivalue);
    Obj.getvalue(KD_PIXELS, ivalue);
    this->setvalue(KD_PIXELS, ivalue);
    Obj.getvalue(KD_OPNO, ivalue);
    this->setvalue(KD_OPNO, ivalue);
    Obj.getvalue(KD_OPCODE, str);
    this->setvalue(KD_OPCODE, str);
    Obj.getvalue(KD_CO_ORD_SYS, str);
    this->setvalue(KD_CO_ORD_SYS, str);
    Obj.getvalue(KD_DATUM, str);
    this->setvalue(KD_DATUM, str);
    Obj.getvalue(KD_PRODUCT_CODE, str);
    this->setvalue(KD_PRODUCT_CODE, str);
    Obj.getvalue(KD_MAP_PROJ, str);
    this->setvalue(KD_MAP_PROJ, str);
    Obj.getvalue(KD_N_RESOLUTION, fvalue);
    this->setvalue(KD_N_RESOLUTION, fvalue);
    Obj.getvalue(KD_VIEW_ANGLE, fvalue);
    this->setvalue(KD_VIEW_ANGLE, fvalue);
    Obj.getvalue(KD_SUBLEFT_SCAN, ivalue);
    this->setvalue(KD_SUBLEFT_SCAN, ivalue);
    Obj.getvalue(KD_SUBLEFT_PIXEL, ivalue);
    this->setvalue(KD_SUBLEFT_PIXEL, ivalue);
    Obj.getvalue(KD_MODE, str);
    this->setvalue(KD_MODE, str);
    Obj.getvalue(KD_PAYLOAD_ANGLE, fvalue);
    this->setvalue(KD_PAYLOAD_ANGLE, fvalue);
    Obj.getvalue(KD_USER_DEFINED, str);
    this->setvalue(KD_USER_DEFINED, str);

    delete str;

    return temp;
}

