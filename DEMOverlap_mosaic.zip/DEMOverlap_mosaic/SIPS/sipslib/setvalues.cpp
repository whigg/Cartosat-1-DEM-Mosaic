
#include<stdarg.h>
#include<string.h>


#include "sips.h"

/*
	Function Name	-	void kchead::setvalues(int first, ...)
	Descr			-	It is for assigning values to one or more member variables of kchead class
	Input			-	pair of (constant, value) & last argument will always be NULL
						constant -> identifier of the member varible field, 
						value -> contains the value of the member variable 
	Output			-	none
	Remark			-   This function does not set the value of m_ptruser_defined field
*/
void kchead::setvalues(int first, ...)    
{
	va_list marker;
    va_start( marker, first );     
	int constant = first, i, j;
	int *value;
	float *fvalue;
	char *str;
	KT_coord_scan_pix *coord_value; 
	char **char_value;
	int everest_height = 9000;
	while(constant != NULL)
	{
		switch(constant)
		{
		case KD_PATH:
			value = va_arg(marker, int *);
			m_ppath = *value;
			break;
		case KD_ROW:
			value = va_arg(marker, int *);
			m_prow = *value;
			break;
		case KD_BANDS:
			value = va_arg(marker, int *);
			m_pbands = *value;
			break;
		case KD_BANDNO:
			value = va_arg(marker, int *);
			m_pbandno = *value;
			break;
		case KD_SCANS:
			value = va_arg(marker, int *);
			m_pscans = *value;
			break;
		case KD_PIXELS:
			value = va_arg(marker, int *);
			m_ppixels = *value;
			break;
		case KD_OPNO:
			value = va_arg(marker, int *);
			m_popno = *value;
			break;
		case KD_SUBLEFT_SCAN:
			value = va_arg(marker, int *);
			m_psubleft_scan = *value;
			break;
		case KD_SUBLEFT_PIXEL:
			value = va_arg(marker, int *);
			m_psubleft_pixel = *value;
			break;
		case KD_N_RESOLUTION:
			fvalue = va_arg(marker, float *);
			m_pn_resolution = *fvalue;
			break;
		case KD_VIEW_ANGLE:
			fvalue = va_arg(marker, float *);
			m_pview_angle = *fvalue;
			break;
		case KD_PAYLOAD_ANGLE:
			fvalue = va_arg(marker, float *);
			m_ppayload_angle = *fvalue;
			break;
		case KD_SAT_TYPE:
			str = va_arg(marker, char *);
			strcpy(m_psatellite_type, str);
			break;
		case KD_SENSOR_TYPE:
			str = va_arg(marker, char *);
			strcpy(m_psensor_type, str);
			break;
		case KD_CAMERA_TYPE:
			str = va_arg(marker, char *);
			strcpy(m_pcamera_type, str);
			break;
		case KD_DATE:
			str = va_arg(marker, char *);
			strcpy(m_pdate, str);
			break;
		case KD_SCENE_DESCR:
			str = va_arg(marker, char *);
			strcpy(m_pscene_descr, str);
			break;
		case KD_OPCODE:
			str = va_arg(marker, char *);
			strcpy(m_popcode, str);
			break;
		case KD_CO_ORD_SYS:
			str = va_arg(marker, char *);
			strcpy(m_pco_ord_sys, str);
			break;
		case KD_DATUM:
			str = va_arg(marker, char *);
			strcpy(m_pdatum, str);
			break;
		case KD_PRODUCT_CODE:
			str = va_arg(marker, char *);
			strcpy(m_pproduct_code, str);
			break;
		case KD_MAP_PROJ:
			str = va_arg(marker, char *);
			strcpy(m_pmap_proj, str);
			break;
		case KD_MODE:
			str = va_arg(marker, char *);
			//strcpy(m_pmode, str);
			m_pmode[0]=str[0];
			break;
		case KD_COORD_SCAN_LAT:
			coord_value = va_arg(marker, KT_coord_scan_pix *);
			for(i=0; i<5; i++)
			for(j=0; j<3; j++)
			{

				if(j==2)
				{
					if((*coord_value).coord[i][j]>0 && (*coord_value).coord[i][j]<everest_height)
						m_pcoord_scan_lat.coord[i][j]=(*coord_value).coord[i][j];
				}
				else if(i==4)
				{
					if((*coord_value).coord[i][j]==((*coord_value).coord[1][j]+(*coord_value).coord[3][j])/2)
						m_pcoord_scan_lat.coord[i][j] = (*coord_value).coord[i][j];
				}
				else
				    m_pcoord_scan_lat.coord[i][j] = (*coord_value).coord[i][j];
			}

		for(i=0; i<5; i++)
			for(j=0; j<2; j++)
			{
				if(i==4)
				{
					if((*coord_value).scan_pix[i][j]==((*coord_value).scan_pix[1][j]+(*coord_value).scan_pix[3][j])/2)
						m_pcoord_scan_lat.scan_pix[i][j] = (*coord_value).scan_pix[i][j];
				}
				else
				    m_pcoord_scan_lat.scan_pix[i][j] = (*coord_value).scan_pix[i][j];
			}
			/*for(i=0; i<5; i++)
				for(j=0; j<3; j++)
					m_pcoord_scan_lat.coord[i][j] = (*coord_value).coord[i][j];

			for(i=0; i<5; i++)
				for(j=0; j<2; j++)
					m_pcoord_scan_lat.scan_pix[i][j] = (*coord_value).scan_pix[i][j];*/
			break;	
		case KD_USER_DEFINED://-----Uncommented by tirupathi on 16/10/07.
			char_value = va_arg(marker, char **);
			m_ptruser_defined = char_value;
			break;

		default:
			//cout << "Not a valid field\n";
			break;
		
		}
		constant = va_arg(marker, int);
	}
	va_end( marker );
}
