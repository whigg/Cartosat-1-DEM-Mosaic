
#include <string.h>


#include "sips.h"

/*
	Function Name	-	void kchead::setvalue(const int &constant, const int &value)
	Descr			-	It is for assigning value to integer member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						value -> contains the value of the member variable 
	Output			-	none
*/
void kchead::setvalue(const int &constant, const int &value)
{															   	
	switch(constant)
	{
	case KD_PATH:
		m_ppath = value;
		break;
	case KD_ROW:
		m_prow = value;
		break;
	case KD_BANDS:
		m_pbands = value;
		break;
	case KD_BANDNO:
		m_pbandno = value;
		break;
	case KD_SCANS:
		m_pscans = value;
		break;
	case KD_PIXELS:
		m_ppixels = value;
		break;
	case KD_OPNO:
		m_popno = value;
		break;
	case KD_SUBLEFT_SCAN:
		m_psubleft_scan = value;
		break;
	case KD_SUBLEFT_PIXEL:
		m_psubleft_pixel = value;
		break;
	default:
		//cout << "Not a valid field.\n";
		break;
	}
}

/*
	Function Name	-	void kchead::setvalue(const int &constant, const float &value)
	Descr			-	It is for assigning value to float member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						value -> contains the value of the member variable 
	Output			-	none
*/
void kchead::setvalue(const int &constant, const float &value)
{																 
	switch(constant)
	{
	case KD_N_RESOLUTION:
		m_pn_resolution = value;
		break;
	case KD_VIEW_ANGLE:
		m_pview_angle = value;
		break;
	case KD_PAYLOAD_ANGLE:
		m_ppayload_angle = value;
		break;
	default:
		//cout << "Not a valid field.\n";
		break;
	}
}

/*
	Function Name	-	void kchead::setvalue(const int &constant, const char str[])
	Descr			-	It is for assigning value to string member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						str -> contains the value of the member variable 
	Output			-	none
*/
void kchead::setvalue(const int &constant, const char str[])
{															   
	switch(constant)
	{
	case KD_SAT_TYPE:
		strcpy(m_psatellite_type, str);
		break;
	case KD_SENSOR_TYPE:
		strcpy(m_psensor_type, str);
		break;
	case KD_CAMERA_TYPE:
		strcpy(m_pcamera_type, str);
		break;
	case KD_DATE:
		strcpy(m_pdate, str);
		break;
	case KD_SCENE_DESCR:
		strcpy(m_pscene_descr, str);
		break;
	case KD_OPCODE:
		strcpy(m_popcode, str);
		break;
	case KD_CO_ORD_SYS:
		strcpy(m_pco_ord_sys, str);
		break;
	case KD_DATUM:
		strcpy(m_pdatum, str);
		break;
	case KD_PRODUCT_CODE:
		strcpy(m_pproduct_code, str);
		break;
	case KD_MAP_PROJ:
		strcpy(m_pmap_proj, str);
		break;
	case KD_MODE:
		//strcpy(m_pmode, str);
		m_pmode[0]=str[0];
		break;
	default:
		//cout << "Not a valid field.\n";
		break;
	}
}

/*
	Function Name	-	void kchead::setvalue(const int &constant, const KT_coord_scan_pix &value)
	Descr			-	It is for assigning value to const KT_coord_scan_pix member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						value -> contains the value of the member variable 
	Output			-	none
*/
void kchead::setvalue(const int &constant, const KT_coord_scan_pix &value)
{																			 		
	int i, j;																 			
	int everest_height=9000;

	switch(constant)
	{
	case KD_COORD_SCAN_LAT:
		for(i=0; i<5; i++)
			for(j=0; j<3; j++)
			{

				if(j==2)
				{
					if(value.coord[i][j]>0 && value.coord[i][j]<everest_height)
						m_pcoord_scan_lat.coord[i][j]=value.coord[i][j];
				}
				else if(i==4)
				{
					if(value.coord[i][j]==(value.coord[1][j]+value.coord[3][j])/2)
						m_pcoord_scan_lat.coord[i][j] = value.coord[i][j];
				}
				else
				    m_pcoord_scan_lat.coord[i][j] = value.coord[i][j];
			}

		for(i=0; i<5; i++)
			for(j=0; j<2; j++)
			{
				if(i==4)
				{
					if(value.scan_pix[i][j]==(value.scan_pix[1][j]+value.scan_pix[3][j])/2)
						m_pcoord_scan_lat.scan_pix[i][j] = value.scan_pix[i][j];
				}
				else
				    m_pcoord_scan_lat.scan_pix[i][j] = value.scan_pix[i][j];
			}
				
		break;

	default:
		//cout << "Not a valid field.\n";
		break;
	}
}

/*
	Function Name	-	void kchead::setvalue(const int &constant, char** value)
	Descr			-	It is for assigning value to const KT_coord_scan_pix member variable of kchead class
	Input			-	constant -> identifier of the member varible field, 
						char** -> contains the value of the member variable 
	Output			-	none
*/
void kchead::setvalue(const int &constant, char** value)
{														   	
	switch(constant)
	{
	case KD_USER_DEFINED:
		m_ptruser_defined = value;
		break;

	default:
		//cout << "Not a valid field.\n";
		break;
	}
}


void kchead::setvalue(const int &constant, const KT_sub_head &value)
{																			 		
	int i;																 			

	switch(constant)
	{
	case KD_SUB_HEAD:
		strcpy(m_psub_head.Satellite,value.Satellite);
		strcpy(m_psub_head.Camera,value.Camera);
		m_psub_head.GR_orbit=value.GR_orbit;
		m_psub_head.IR_orbit=value.IR_orbit;
		strcpy(m_psub_head.Acq_stn_id,value.Acq_stn_id);
		strcpy(m_psub_head.Pass_type,value.Pass_type);
		strcpy(m_psub_head.Date_receiving,value.Date_receiving);
		strcpy(m_psub_head.Date_imaging,value.Date_imaging);
		m_psub_head.No_of_target=value.No_of_target;
		strcpy(m_psub_head.Org_name,value.Org_name);
		m_psub_head.Sourceid_ORB_flag=value.Sourceid_ORB_flag;
		m_psub_head.Sourceid_ATD_flag=value.Sourceid_ATD_flag;
		strcpy(m_psub_head.Segment_no,value.Segment_no);
		strcpy(m_psub_head.PL_ontime,value.PL_ontime);
		strcpy(m_psub_head.PL_offtime,value.PL_offtime);
		m_psub_head.Data_quality_str1=value.Data_quality_str1;
		m_psub_head.Data_quality_str2=value.Data_quality_str2;
		for(i=0;i<2;i++)
			m_psub_head.LatLon_middleleft[i]=value.LatLon_middleleft[i];
		for(i=0;i<2;i++)
			m_psub_head.LatLon_middleright[i]=value.LatLon_middleright[i];
		for(i=0;i<2;i++)
			m_psub_head.Scpix_middleleft[i]=value.Scpix_middleleft[i];
		for(i=0;i<2;i++)
			m_psub_head.Scpix_middleright[i]=value.Scpix_middleright[i];
		strcpy(m_psub_head.Seg_starttime,value.Seg_starttime);
		strcpy(m_psub_head.Seg_centertime,value.Seg_centertime);
		strcpy(m_psub_head.Seg_endtime,value.Seg_endtime);
		m_psub_head.GR_sc_vel=value.GR_sc_vel;
		m_psub_head.Integration_time=value.Integration_time;
		m_psub_head.Satellite_altitude=value.Satellite_altitude;
		m_psub_head.Satellite_heading=value.Satellite_heading;
		m_psub_head.Image_heading=value.Image_heading;
		m_psub_head.Sun_elevation=value.Sun_elevation;
		m_psub_head.Sun_azimuth=value.Sun_azimuth;
		m_psub_head.Angle_incidence=value.Angle_incidence;
		m_psub_head.Line_resolution=value.Line_resolution;
		m_psub_head.Oversampling_factor=value.Oversampling_factor;
		m_psub_head.Image_mode=value.Image_mode;
		m_psub_head.Mono_stereo_flag=value.Mono_stereo_flag;
		m_psub_head.PrePostfacto_flag=value.PrePostfacto_flag;
		strcpy(m_psub_head.Related_Image,value.Related_Image);
		break;

	default:
		//cout << "Not a valid field.\n";
		break;
	}
}
