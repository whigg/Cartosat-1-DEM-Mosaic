
#include<stdio.h>
#include<string.h>
#include "sips.h"



extern char a_buffer[KD_MAX_SIZE];
extern char data[KD_MAX_SIZE];

extern int buffer_pointer;
extern int data_pointer;

/*
	Function Name	-	int kchead::addheader(char *filename)
	Descr			-	adds header to the image file filename using the values in header object 
	Input			-	filename -> name of the image file,  
	Output			-	number of header added.
*/

int kchead::replaceheader(char *filename)
{
	char buffer1[KD_MAX_SIZE];
	char data1[KD_MAX_SIZE];
	char string[KD_STRING_SIZE];
	int i;
	int no_of_head_added = 0;
	int header_size;
	int buffer_pointer1=0;
	int data_pointer1 = 0;
	int table_position;
	int mla = 0;
	int pixels;
	FILE *fp;
  	pixels=m_ppixels;
	for(i=0;i<KD_MAX_SIZE;i++){ buffer1[i]=' ';a_buffer[i]=' ';}
	buffer_pointer=0;
	data_pointer = 0;
	strcpy(&a_buffer[0],"AdRiN2001#");
	buffer_pointer = KD_SIZE_HEADER + KD_POINTER_HEADER_TABLE + KD_SIZE_HEADER_TABLE + KD_POINTER_HEADER_DATA + 10;
	table_position = buffer_pointer;

	if (strlen(m_psatellite_type) > 0 )
		func1(1,m_psatellite_type);

	if (strlen(m_psensor_type) > 0)
		func1(2,m_psensor_type);

	if (strlen(m_pcamera_type) > 0)
		func1(3,m_pcamera_type);

	if (strlen(m_pdate) > 0)
		func1(4,m_pdate);

	if (strlen(m_pscene_descr) > 0)
		func1(5,m_pscene_descr);

	if (m_ppath>0)
		func2(6,m_ppath);

	if (m_prow>0)
		func2(7,m_prow);

	func4(8,&m_pcoord_scan_lat);
	
	if (m_pbands >0)
		func2(9,m_pbands);
	
	if (m_pscans > 0)
		func2(11,m_pscans);

	if (m_ppixels > 0)
		func2(12,m_ppixels);

	if (m_popno > 0)
		func2(13,m_popno);

	if (strlen(m_popcode) > 0)
		func1(14,m_popcode);

 	if (strlen(m_pco_ord_sys)>0)
		func1(15,m_pco_ord_sys);
	if (strlen(m_pdatum)>0)
		func1(16,m_pdatum);
	if (strlen(m_pproduct_code)>0)
		func1(17,m_pproduct_code);
	if (strlen(m_pmap_proj)>0)
		func1(18,m_pmap_proj);
	if (m_pn_resolution>=0)
		func3(19,m_pn_resolution);
	if (m_pview_angle>=-90)
		func3(20,m_pview_angle);
	if(m_psubleft_scan>-1)
		func2(21,m_psubleft_scan);
	if(m_psubleft_pixel>-1)
		func2(22,m_psubleft_pixel);
	if(m_pmode[0]!=(char ) 0)
		func1(23,m_pmode);
	if(m_ppayload_angle>-90.0)
		func3(24,m_ppayload_angle);
	
	Add_user_defined(m_ptruser_defined,50); 
	
	//free(m_ptruser_defined);
	for(i=0;i<KD_MAX_SIZE;i++)
		{
			buffer1[i]=a_buffer[i];
			data1[i]=data[i];
		}
	buffer_pointer1=buffer_pointer;
	data_pointer1=data_pointer;
	for(i=0;i<KD_MAX_SIZE;i++)
		{
		data[i]=data1[i];
		a_buffer[i]=buffer1[i];
		}
	buffer_pointer=buffer_pointer1;
	data_pointer=data_pointer1;
	if((fp=fopen(filename,"rb+"))==NULL)
		{
			return(-3);
		}

	func2(10,m_pbandno);

	header_size = 2048;/*(data_pointer + buffer_pointer); */
	sprintf(string,"%d",header_size);
	strcpy(&a_buffer[10],string);
	sprintf(string,"%d",table_position);
	strcpy(&a_buffer[10 + KD_SIZE_HEADER],string);
	sprintf(string,"%d",buffer_pointer-table_position);
	strcpy(&a_buffer[10 + KD_SIZE_HEADER + KD_POINTER_HEADER_TABLE],string);
	strcpy(string,"");
	sprintf(string,"%d",buffer_pointer);
	strcpy(&a_buffer[10 + KD_SIZE_HEADER + KD_POINTER_HEADER_TABLE + KD_SIZE_HEADER_TABLE],string);

	for(i=0;i<data_pointer;i++)
		{
		a_buffer[buffer_pointer++]=data[i];
		}
	for(i=0;i<header_size;i++)
		{
		if (a_buffer[i]=='\0') a_buffer[i]=' ';
		}
	for(i=header_size;i<2048;i++)
		{
		a_buffer[i]=' ';
		}
	no_of_head_added ++;
	fwrite(a_buffer,sizeof(char),header_size,fp);
	fclose(fp);
	return(no_of_head_added);

}
#if 0
void kchead::Add_user_defined(char **xyz, int id)
{
	int i=0;
	while( (strcmp(xyz[i],"NULL")) != (unsigned int)0)
		{
		if((buffer_pointer+data_pointer+1)<2048)
			func1(id+i,xyz[i]);
		else
			break;
		i++;
		}
	strcpy(xyz[i],"NULL");
	xyz[i][4]='\0';
	func1(id+i,xyz[i]);
}
void kchead::func1(int n, char str[])
{

	char string1[KD_STRING_SIZE];
	int field_length;
	sprintf(string1,"%d",n);
	strcpy(&a_buffer[buffer_pointer],string1);
	buffer_pointer += (1+strlen(string1));
	field_length = strlen(str);
	sprintf(string1,"%d",field_length);
	strcpy(&a_buffer[buffer_pointer],string1);
	buffer_pointer += (1+strlen(string1));
	strcpy(&data[data_pointer],str);
	data_pointer += strlen(str);

	return;

}


void kchead::func2(int i, int n)
{

	char string1[KD_STRING_SIZE];
	int field_length;
	sprintf(string1,"%d",i);
	strcpy(&a_buffer[buffer_pointer],string1);
	buffer_pointer += (1+strlen(string1));
	sprintf(string1,"%d",n);
	field_length = strlen(string1);
	sprintf(string1,"%d",field_length);
	strcpy(&a_buffer[buffer_pointer],string1);
	buffer_pointer += (1+strlen(string1));
	sprintf(string1,"%d",n);
	strcpy(&data[data_pointer],string1);
	data_pointer += strlen(string1);

	return;
}


void kchead::func3(int i,float n)
{

	char string1[KD_STRING_SIZE];
	int field_length;
	sprintf(string1,"%d",i);
	strcpy(&a_buffer[buffer_pointer],string1);
	buffer_pointer += (1+strlen(string1));
	sprintf(string1,"%f",n);
	field_length = strlen(string1);
	sprintf(string1,"%d",field_length);
	strcpy(&a_buffer[buffer_pointer],string1);
	buffer_pointer += (1+strlen(string1));
	sprintf(string1,"%f",n);
	strcpy(&data[data_pointer],string1);
	data_pointer += strlen(string1);

	return;

}
void kchead::func4(int j, KT_coord_scan_pix *xyz)
{
	char string1[KD_STRING_SIZE],string2[KD_STRING_SIZE];
	int field_length=0,i;
	sprintf(string1,"%d",j);
	strcpy(&a_buffer[buffer_pointer],string1);
	buffer_pointer+=(1+strlen(string1));
	strcpy(string2,"");
	for(i=0;i<5;i++)
		{
		sprintf(string1,"%f",xyz->coord[i][0]);
		strcpy(&string2[field_length],string1);
		field_length=field_length+strlen(string1);
		string2[field_length]=' '; 
		field_length++;
		sprintf(string1,"%f",xyz->coord[i][1]);
		strcpy(&string2[field_length],string1);
		field_length=field_length+strlen(string1);
		string2[field_length]=' ';
		field_length++;
		sprintf(string1,"%f",xyz->coord[i][2]);
		strcpy(&string2[field_length],string1);
		field_length=field_length+strlen(string1);
		string2[field_length]=' '; 
		field_length++;
		}
	for(i=0;i<5;i++)
		{
		sprintf(string1,"%d",xyz->scan_pix[i][0]);
		strcpy(&string2[field_length],string1);
		field_length=field_length+strlen(string1);
		string2[field_length]=' ';
		field_length++;
		sprintf(string1,"%d",xyz->scan_pix[i][1]);
		strcpy(&string2[field_length],string1);
		field_length=field_length+strlen(string1);
		string2[field_length]=' ';
		field_length++;
		}	
	string2[field_length]='\0';
	sprintf(string1,"%d",field_length);
	strcpy(&a_buffer[buffer_pointer],string1);
	buffer_pointer+=(1+strlen(string1));
	strcpy(&data[data_pointer],string2);
	string2[field_length]='\0';
	data_pointer=data_pointer+strlen(string2);
}
#endif
