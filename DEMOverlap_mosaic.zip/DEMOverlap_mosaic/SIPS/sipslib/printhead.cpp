#include<stdio.h>
#include<string.h>


#include "sips.h"
/*
	Function Name	-	void kchead::printheader(void)
	Descr			-	prints the contents of the  image header
	Input			-	none 
	Output			-	none.
*/  
void kchead::printheader(void)
{
int i,corner=0;
	printf("               H E A D E R     D E T A I L S\n");
	printf("               -----------------------------\n\n");
if(strcmp(m_psatellite_type,"") !=0)
	printf("Satellitetype                :%s\n",m_psatellite_type);
if(strcmp(m_psensor_type,"") !=0)
	printf("Sensortype                   :%s\n",m_psensor_type);
if(strcmp(m_pcamera_type,"")!=0)
	printf("Cameratype                   :%s\n",m_pcamera_type);
if(strcmp(m_pdate,"")!=0)
	printf("Date                         :%s\n",m_pdate);
if(strcmp(m_pscene_descr,"")!=0)
	printf("Scenedescsription            :%s\n",m_pscene_descr);
if(m_ppath!=-1)
	printf("Path                         :%7d",m_ppath);
if(m_prow!=-1)
	printf(" Row                   :%d\n",m_prow);
if(strcmp(m_pco_ord_sys,"")!=0)
	printf("Coordinate system            :%s\n",m_pco_ord_sys);
if(strcmp(m_pco_ord_sys,"")==0)
	{
	for(i=0;i<5;i++)
		{
		if(i==4)
			{
			printf("Latitude,Longitude,Height of centre  :");
			}
		else
			{
			printf("Latitude,Longitude Height of corner %d:",i+1);
			}
		if(m_pcoord_scan_lat.coord[i][0]>=0)
			printf("%8.3f ",(m_pcoord_scan_lat).coord[i][0]);
		else
 			printf("Unknown ");
		if(m_pcoord_scan_lat.coord[i][1]>=0)
			printf("%8.3f ",(m_pcoord_scan_lat).coord[i][1]);
		else
 			printf("Unknown ");
		if(m_pcoord_scan_lat.coord[i][2]>=0)
			printf("%8.3f \n",(m_pcoord_scan_lat).coord[i][2]);
		else
 			printf("Unknown \n");
		}
	}
else
	for(i=0;i<5;i++)
		{
		if(i==4)
			{
			printf("X Y Z of centre              :");
			}
		else
			{
			printf("X Y Z of corner %d            :",i+1);
			}
		if(m_pcoord_scan_lat.coord[i][0]>=0)
			printf("%8.3f ",(m_pcoord_scan_lat).coord[i][0]);
		else
 			printf("Unknown ");
		if(m_pcoord_scan_lat.coord[i][1]>=0)
			printf("%8.3f ",(m_pcoord_scan_lat).coord[i][1]);
		else
 			printf("Unknown ");
		if(m_pcoord_scan_lat.coord[i][2]>=0)
			printf("%8.3f \n",(m_pcoord_scan_lat).coord[i][2]);
		else
 			printf("Unknown \n");
		}
corner=0;
for(i=0;i<5;i++)
	{
	if(i!=4)
		printf("Corner %d  scans , pixels     :",i+1);
	else
		printf("Centre    scans , pixels     :");
	if(m_pcoord_scan_lat.scan_pix[i][0]>=0)
		printf(" %4d",m_pcoord_scan_lat.scan_pix[i][0]);
	else
		printf("Unknown ");
	if(m_pcoord_scan_lat.scan_pix[i][1]>=0)
		printf(" %4d\n",m_pcoord_scan_lat.scan_pix[i][1]);
	else
		printf("Unknown\n");
	}
printf("No. of bands                 :%7d",m_pbands);
printf(" Band no               :%d\n",m_pbandno);
printf("Scans                        :%7d ",m_pscans);
printf("Pixels                :%d\n",m_ppixels);
printf("Subscene Left scan	     :%7d ",m_psubleft_scan);
printf("Subscene Left pixel   :%d\n",m_psubleft_pixel);
printf("Mode			    :");
if((m_pmode[0]=='A') || (m_pmode[0]=='a'))
	printf("Ascending\n");
else
if((m_pmode[0]=='D') || (m_pmode[0]=='d'))
	printf("Descending\n");
else
	printf("Unknown\n");
if(m_popno>0)
	{
	printf("No.of operations performed   :%d\n",m_popno);
	printf("Operation code               :%s\n",m_popcode);
	}
if(strcmp(m_pdatum,"")!=0)
	printf("Datum                        :%s",m_pdatum);
if(strcmp(m_pproduct_code,"")!=0)
	printf(" Product_code          :%s\n",m_pproduct_code);
if(strcmp(m_pmap_proj,"")!=0)
	printf("Map projection               :%s\n",m_pmap_proj);
if(m_pn_resolution>=0.0)
	printf("Nominal Resolution           :%7.3f ",m_pn_resolution);
if(m_pview_angle>-90.0)
	printf("View angle            :%8.3f \n",m_pview_angle);
if(m_ppayload_angle>-90)
	printf("HRV to payload angle	     :%7.3f\n",m_ppayload_angle);
i=0;
while(strcmp(m_ptruser_defined[i],"NULL")!=0)
		{
		if(i==0){
		 printf("\n\n                  Other   Informations    \n");
		 printf("                  --------------------    \n");
		 }
		if(strcmp(m_ptruser_defined[i],"")!=0)
			printf("%s \n",m_ptruser_defined[i]);
		i++;
		}

return;
}
