#ifndef SIPSLIB_GLOBAL_H
#define SIPSLIB_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(SIPSLIB_LIBRARY)
#  define SIPSLIBSHARED_EXPORT Q_DECL_EXPORT
#else
#  define SIPSLIBSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // SIPSLIB_GLOBAL_H
