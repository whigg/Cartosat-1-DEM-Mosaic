#include<string.h>
#include<malloc.h>


#include "sips.h"



/*
    Function Name	-	void kchead::initialization(void)
    Descr			-	initializes the header data structure
    Input			-	none
    Output			-	none.
*/
kchead::kchead() {

    m_pUserDefineCount = 0;
    m_ptruser_defined = NULL;

}

kchead::~kchead() {}

void kchead::initialization(void)
{
    if(m_pUserDefineCount>0 && m_ptruser_defined!=NULL)
    {
        for(int i=0;i<m_pUserDefineCount;i++)
        {
            if(m_ptruser_defined[i]!=NULL)
                free(m_ptruser_defined[i]);
            m_ptruser_defined[i]=NULL;
        }
        if(m_ptruser_defined!=NULL)
            free(m_ptruser_defined);
        m_ptruser_defined=NULL;
        m_pUserDefineCount = 0;
    }

    int i;
    strcpy(m_psatellite_type,"\0");
    strcpy(m_psensor_type,"\0");
    strcpy(m_pcamera_type,"\0");
    strcpy(m_pdate,"\0");
    strcpy(m_pscene_descr,"\0");
    strcpy(m_popcode,"\0");
    m_ppath=-1;
    m_prow=-1;
    m_pscans=-1;
    m_ppixels=-1;
    m_pbands=-1;
    m_pbandno=-1;
    m_popno=-1;
    for(i=0;i<5;i++)
    {
        m_pcoord_scan_lat.coord[i][0]=-1;
        m_pcoord_scan_lat.coord[i][1]=-1;
        m_pcoord_scan_lat.coord[i][2]=-1;
        m_pcoord_scan_lat.scan_pix[i][0]=-1;
        m_pcoord_scan_lat.scan_pix[i][1]=-1;
    }
    strcpy(m_pco_ord_sys,"\0");
    strcpy(m_pdatum,"\0");
    strcpy(m_pproduct_code,"\0");
    strcpy(m_pmap_proj,"\0");
    m_pn_resolution=-1.0;
    m_pview_angle=-90.0;
    m_psubleft_scan=0;
    m_psubleft_pixel=0;
    m_pmode[0]=' ';
    m_ppayload_angle=-90;
   
    m_pUserDefineCount+=1;
    m_ptruser_defined=(char **) malloc(sizeof(char *));
    m_ptruser_defined[0]=(char *) malloc(5 * sizeof(char));
    strcpy(m_ptruser_defined[0],"NULL");

    return;
}
