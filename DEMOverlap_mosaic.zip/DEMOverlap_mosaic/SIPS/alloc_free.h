#ifndef _ALLOC_FREE
#define _ALLOC_FREE
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <iostream>
#include <fstream>
template <class T>
T **Alloc(int n1,int n2)
{

	int i;
	T **u;

	if ((u=(T **)malloc(sizeof(T *)*n1)) == NULL)
	{
		printf("Memory can not be allocated\n");
	}
	for(i=0;i<n1;i++)
	{
		if ((u[i]=(T *)malloc(sizeof(T )*n2)) == NULL)
			printf("Memory can not be allocated at %d\n",i);
	}

	return u;
}

template <class T>
T *Alloc(int n1)
{

	T *u;
	
	if ((u=(T *)malloc(sizeof(T )*n1)) == NULL)
		printf("Memory can not be allocated\n");
	return u;
}


template <class T>
T ***Alloc(int n1,int n2,int n3)
{

	int i;
	T ***u;

	 if ((u=(T ***)malloc(sizeof(T **)*n1)) == NULL)
		 printf("Memory can not be allocated\n");

	for(i=0;i<n1;i++)
	{
		if ((u[i]=Alloc<T>(n2,n3)) == NULL)
			 printf("Memory can not be allocated at %d\n",i);
	}


	return u;
}
template <class T>
void Free_Variable(T *a)
{
	free(a);
}
template <class T>
void Free_Variable(T **a,int size)
{
	for(int i=0;i<size;i++)
		free(a[i]);
	free(a);
}
template <class T>
void Free_Variable(T ***a,int size1,int size2)
{
	for(int i=0;i<size1;i++)
	{
		for(int j=0;j<size2;j++)
			free(a[i][j]);
		free(a[i]);
	}
	free(a);
}
#endif