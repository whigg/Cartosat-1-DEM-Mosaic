#ifndef _LEAST_SQUARE
#define _LEAST_SQUARE
#include "stdio.h"
#include "math.h"
#include "stdlib.h"
#include "malloc.h"
#include "string.h"
#include <iostream>
#include <fstream>
#include "alloc_free.h"

using namespace std;
class LEAST_SQUARE{

private:
	int total_points,total_coefficients,nequn;
	int Read_File_Flag;
	double **matinv_a;
	
	double **At,**AAt,**AAt_in,**AtB,**AX;
	double **Solution,**err_values;

	
public:
	
	int Least_Square_Fit();
	char message[100];

	
	LEAST_SQUARE(double **Aa,double **Bb,int n1,int n2,double *coeff)
	{
		nequn=n1;
		total_coefficients=n2;
		At=Alloc<double>(total_coefficients,nequn);
		AAt=Alloc<double>(total_coefficients,total_coefficients);
		AAt_in=Alloc<double>(total_coefficients,total_coefficients);
		AtB=Alloc<double>(total_coefficients,1);
		AX=Alloc<double>(nequn,1);
		Solution=Alloc<double>(total_coefficients,1);
		err_values=Alloc<double>(nequn,1);

		matinv_a=Alloc<double>(total_coefficients,total_coefficients);
		mattran(Aa,At,n1,n2);
		matmul(At,Aa,AAt,n2,n1,n2);
		matinv(AAt,AAt_in,n2);

	/*	printf("\n\n");
		print_dmat(AAt,n2,n2);
		printf("\n\n");
		print_dmat(AAt_in,n2,n2);
	*/	

		if (AAt_in[0][0] == -9999.0)
		{
			return;
		}
		matmul(At,Bb,AtB,n2,n1,1);
		matmul(AAt_in,AtB,Solution,n2,n2,1);
		matmul(Aa,Solution,AX,n1,n2,1);
		matsub(Bb,AX,err_values,n1,1);

		for(int j=0;j<total_coefficients;j++)
			  coeff[j]=Solution[j][0];
	
	}
		
	~LEAST_SQUARE()
	{
		Free_Variable<double>(matinv_a,total_coefficients);
		Free_Variable<double>(At,total_coefficients);
		Free_Variable<double>(AAt,total_coefficients);
		Free_Variable<double>(AAt_in,total_coefficients);
		Free_Variable<double>(AtB,total_coefficients);
		Free_Variable<double>(AX,nequn);
		Free_Variable<double>(Solution,total_coefficients);	
		Free_Variable<double>(err_values,nequn);
	}
	double** matinv(double **b,int row)
	{
		double piv,temp,num,**id,**a;
		int i,j,k,l,s;

		if ((id=(double **) malloc(sizeof(double *)*row)) == NULL)
				printf("Memory can not be allocated");

		a=Alloc<double>(row,row);
		for(i=0;i<row;i++)
		{
			if ((id[i]=(double *) malloc(sizeof(double )*row)) == NULL)
				 printf("Memeory can not be allocated at %d\n",i);
		}

		for(i=0;i<row;i++)
		{
			for(j=0;j<row;j++)
			{
				a[i][j]=b[i][j];
				if (i==j)
					id[i][j]=1.0;
				else
					id[i][j]=0.0;
			}
		}


		for(i=0;i<row;i++)
		{
			if (a[i][i]==0.0)
			{
				for(s=i;s<row;s++)
				{
					if (a[s][i] !=0.0)
					{
						for(l=0;l<row;l++)
						{
							 temp=a[i][l];
							 a[i][l]=a[s][l];
							 a[s][l]=temp;
 
							 temp=id[i][l];
							 id[i][l]=id[s][l];
							 id[s][l]=temp;
						}
						break;
					}
				}
				if (s==row)
				{
					printf("\nError in matrix\n");
					id[0][0]=-9999.0;
					return id;
				}
			}

			num=a[i][i];

			for(j=0;j<row;j++)
			{
				piv=a[j][i];
				if (i==j)
					continue;
				for(k=0;k<row;k++)
				{
					a[j][k]-=(double)a[i][k]*piv/num;
					id[j][k]-=(double)id[i][k]*piv/num;
				}
			}
			for(l=0;l<row;l++)
			{
				a[i][l]/=num;
				id[i][l]/=num;
			}
			//print_dmat(a,row,row);
		}
		Free_Variable<double>(a,row);
		return id;
	}				

	double** mattran(double **mat,int no1,int no2)
	{
		double **a;
		int i,j;

		if ((a=(double **)malloc(sizeof(double *)*no2)) == NULL)
			printf("Memory can not be allocated");

		for(i=0;i < no2;i++)
			if ((a[i]=(double *)malloc(sizeof(double )*no1)) == NULL)
				printf("Memory can not be allocated at %d",i);

		
		for(i=0;i<no2;i++)
		{
			for(j=0;j<no1;j++)
				a[i][j] = mat[j][i];
		}
		return a;
	}

	double** matmul(double **mat1,double **mat2,int no1,int no2,int no3)
	{
		int i,j,k;
		
		double **a;

		a=(double **)malloc(sizeof(double *)*(no1));
		if (a == NULL)
			printf("\n 1. No Memory\n");
		

		for(i=0;i < no1;i++)
		{
			a[i]=(double *)malloc(sizeof(double )*(no3));
			if (a[i]  == NULL)
				printf("\n i=%d \t Memory Fault \n",i);
		}


		for(i=0;i<no1;i++)
		{
			for(j=0;j<no3;j++)
			{
				a[i][j]=0.0;
				for(k=0;k<no2;k++)
					a[i][j] += mat1[i][k]*mat2[k][j];
			}
		}
		return a;
	}


	double** matsub(double **mat1,double **mat2,int n1,int n2)
	{

		int i,j;
		double **mat3;


		if ((mat3=(double **)malloc(sizeof(double *)*n1)) == NULL)
			printf("Memory can not be allocated");

		for(i=0;i<n1;i++)
			if ((mat3[i]=(double *)malloc(sizeof(double )*n2)) == NULL)
				printf("Memory can not be allocated at %d",i);

		for(i=0;i<n1;i++)
		{
			for(j=0;j<n2;j++)
				mat3[i][j]=mat1[i][j]-mat2[i][j];
		}

		return mat3;

	}
	double** matadd(double **mat1,double **mat2,int n1,int n2)
	{

		int i,j;
		double **mat3;


		if ((mat3=(double **)malloc(sizeof(double *)*n1)) == NULL)
			printf("Memory can not be allocated");

		for(i=0;i<n1;i++)
			if ((mat3[i]=(double *)malloc(sizeof(double )*n2)) == NULL)
				printf("Memory can not be allocated at %d",i);

		for(i=0;i<n1;i++)
		{
			for(j=0;j<n2;j++)
				mat3[i][j]=mat1[i][j]+mat2[i][j];
		}

		return mat3;

	}
	void matinv(double **b,double **id,int row)
	{
		double piv,temp,num;
		int i,j,k,l,s;

		for(i=0;i<row;i++)
		{
			for(j=0;j<row;j++)
			{
				matinv_a[i][j]=b[i][j];
				if (i==j)
					id[i][j]=1.0;
				else
					id[i][j]=0.0;
			}
		}


		for(i=0;i<row;i++)
		{
			if (matinv_a[i][i]==0.0)
			{
				for(s=i;s<row;s++)
				{
					if (matinv_a[s][i] !=0.0)
					{
						for(l=0;l<row;l++)
						{
							 temp=matinv_a[i][l];
							 matinv_a[i][l]=matinv_a[s][l];
							 matinv_a[s][l]=temp;
 
							 temp=id[i][l];
							 id[i][l]=id[s][l];
							 id[s][l]=temp;
						}
						break;
					}
				}
				if (s==row)
				{
					printf("\nError in matrix\n");
					id[0][0]=-9999.0;
					return;
				}
			}

			num=matinv_a[i][i];

			for(j=0;j<row;j++)
			{
				piv=matinv_a[j][i];
				if (i==j)
					continue;
				for(k=0;k<row;k++)
				{
					matinv_a[j][k]-=(double)matinv_a[i][k]*piv/num;
					id[j][k]-=(double)id[i][k]*piv/num;
				}
			}
			for(l=0;l<row;l++)
			{
				matinv_a[i][l]/=num;
				id[i][l]/=num;
			}
			//print_dmat(matinv_a,row,row);
		}
		return ;
	}

	void mattran(double **mat,double **a,int no1,int no2)
	{
		int i,j;

		for(i=0;i<no2;i++)
		{
			for(j=0;j<no1;j++)
				a[i][j] = mat[j][i];
		}
		return;
	}

	void matmul(double **mat1,double **mat2,double **a,int no1,int no2,int no3)
	{
		int i,j,k;

		for(i=0;i<no1;i++)
		{
			for(j=0;j<no3;j++)
			{
				a[i][j]=0.0;
				for(k=0;k<no2;k++)
					a[i][j] += mat1[i][k]*mat2[k][j];
			}
		}
		return;
	}


	void matsub(double **mat1,double **mat2,double **mat3,int n1,int n2)
	{

		int i,j;

		for(i=0;i<n1;i++)
		{
			for(j=0;j<n2;j++)
				mat3[i][j]=mat1[i][j]-mat2[i][j];
		}

		return;

	}
	void matadd(double **mat1,double **mat2,double **mat3,int n1,int n2)
	{

		int i,j;

		for(i=0;i<n1;i++)
		{
			for(j=0;j<n2;j++)
				mat3[i][j]=mat1[i][j]+mat2[i][j];
		}

		return;
	}

	void print_dmat(double **a,int n1,int n2)
	{
		int i,j;

		printf("\n rows = %d \t cols = %d\n",n1,n2);

		for(i=0;i<n1;i++)
		{
			for(j=0;j<n2;j++)
				printf("%1.10lf ",a[i][j]);
		printf("\n\n");
		}
	}



		
};
#endif