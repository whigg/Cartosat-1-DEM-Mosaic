/* char SccsId[]="%W%	%G%";  */
#ifndef _SIPS_H
#define _SIPS_H


#include "sips_constant.h"

/* id no 50 onwards user defined fields */
#define KD_MAX_SIZE 2048
#define KD_STRING_SIZE 512
#define KD_SIZE_HEADER 6
#define KD_POINTER_HEADER_TABLE 4
#define KD_SIZE_HEADER_TABLE 4
#define KD_POINTER_HEADER_DATA 4
#define KD_NO_OF_FIELDS_FIXED 20
#define KD_MLA "Mmg"
#define KD_PLA "Img"
typedef struct coord_scan KT_coord_scan_pix;
typedef struct sub_head KT_sub_head;
class kchead;
typedef kchead KT_HEAD;
struct coord_scan{
    double coord[5][3];
    int   scan_pix[5][2];
};
struct sub_head{
    char	Satellite[9];
    char	Camera[5];
    int		GR_orbit;
    int		IR_orbit;
    char	Acq_stn_id[5];
    char	Pass_type[10];
    char	Date_receiving[11];
    char	Date_imaging[11];
    int		No_of_target;
    char	Org_name[10];
    int		Sourceid_ORB_flag;
    int		Sourceid_ATD_flag;
    char	Segment_no[3];
    char	PL_ontime[30];
    char	PL_offtime[30];
    int		Data_quality_str1;
    int		Data_quality_str2;
    double	LatLon_middleleft[2];
    double	LatLon_middleright[2];
    int		Scpix_middleleft[2];
    int 	Scpix_middleright[2];
    char	Seg_starttime[30];
    char	Seg_centertime[30];
    char	Seg_endtime[30];
    double	GR_sc_vel;
    double	Integration_time;
    double	Satellite_altitude;
    double	Satellite_heading;
    double	Image_heading;
    double	Sun_elevation;
    double	Sun_azimuth;
    double	Angle_incidence;
    double	Line_resolution;
    double	Oversampling_factor;
    int		Image_mode;
    int		Mono_stereo_flag;
    int		PrePostfacto_flag;
    char	Related_Image[9];
};

class kchead{
protected:
    /* 1 */	char m_psatellite_type[20];
    /* 2 */	char m_psensor_type[20];
    /* 3 */	char m_pcamera_type[20];
    /* 4 */	char m_pdate[40];
    /* 5 */	char m_pscene_descr[512];
    /* 6 */	int  m_ppath;
    /* 7 */	int  m_prow;
    /* 8 */ KT_coord_scan_pix  m_pcoord_scan_lat;
    /* 9 */	int  m_pbands;
    /*10 */	int  m_pbandno;
    /*11 */	int  m_pscans;
    /*12 */	int  m_ppixels;
    /*13 */	int  m_popno;
    /*14 */	char m_popcode[400];
    /*15 */	char m_pco_ord_sys[10]; /* new fields */
    /*16 */	char m_pdatum[10];
    /*17 */	char m_pproduct_code[10];
    /*18 */	char m_pmap_proj[15];
    /*19 */	float m_pn_resolution;
    /*20 */	float m_pview_angle;
    /*21 */ int m_psubleft_scan;
    /*22 */ int m_psubleft_pixel;
    /*23 */ char m_pmode[1];
    /*24 */ float m_ppayload_angle;
    /*25 */	KT_sub_head  m_psub_head;
    /*50 */ char **m_ptruser_defined;
    int m_pUserDefineCount;    /* count of the m_ptruser_defined array. Used for freeing the memory */
    /****************function used in getheader*************************/
    void Coord_lat(KT_coord_scan_pix *, char *);
    void Sub_head(KT_sub_head *, char *);
    /****************functions used in addheader*************************/
    void func1(int , char []); /* called when the string of data is to be inserted */
    void func2(int , int); /* called when integer data is to be inserted       */
    void func3(int, float); /* called when float data is to be inserted         */
    void func4(int , KT_coord_scan_pix *); /* called when a structure is  passed               */
    void func5(int , KT_sub_head *); /* called when a structure is  passed               */
    void Add_user_defined(char **, int); /* called to add user defined fields     */


public:
    kchead();
    ~kchead();
    void	getvalue(int, char *);
    void	getvalue(int, int&);
    void	getvalue(int, KT_coord_scan_pix&);
    void	getvalue(int, KT_sub_head&);
    void    getvalue(int, float&);
    void    getvalue(int, char**);
    void	getvalues(int first, ... );
    void	setvalues(int first, ... );
    void	setvalue(const int&, const char []);
    void	setvalue(const int&, const int&);
    void	setvalue(const int&, const KT_coord_scan_pix&);
    void	setvalue(const int&, const KT_sub_head&);
    void    setvalue(const int&, const float&);
    void    setvalue(const int&, char**);
    int		getheader(char *);
    int		addheader(char *);
    void	initialization(void);
    void	printheader(void);
    void	getfilename(char [],int ,char [], char []);
    kchead  operator=(const kchead&);
    int		replaceheader(char *);
    int     getheaderFromBuf(char * &buffer);
} ;

#endif
