// DEMFIlterRef.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<string.h>
#include<stdlib.h>
#include <iostream>
#include<math.h>
#include "DEMFilterLib.h"

using namespace std;
//using namespace System;

int main(int argc, char **argv)
{	
	char Input_Tiles[300];//Folder consists of Tiles containing respective individual DEM scenes
	char Mosaic_Output_Loc[300];//Folder consists of Tiles containing respective individual DEM scenes
	int opt=1;//By default, mosaic process uses proposed method; 
	//opt 2 (via command line also) for conventioanl feathering-based-blend method,3 for average method
	if(argc==4)
	{
		strcpy(Input_Tiles,argv[1]);
		strcpy(Mosaic_Output_Loc,argv[2]);
		opt=atoi(argv[3]);
		if(opt==1){
			cout<<"\t\tDEM Mosaic using Proposed method"<<endl;		
			DEMFilter::MyDEMFilter::Mosaic_Proposed(Input_Tiles,Mosaic_Output_Loc);}
		else if(opt==2){cout<<"\t\tDEM Mosaic using Average method"<<endl;
			DEMFilter::MyDEMFilter::Mosaic_Average(Input_Tiles,Mosaic_Output_Loc);			
		}			
		else{
			cout<<"\t\tDEM Mosaic using Convetnional feathering-based-blend method"<<endl;
			DEMFilter::MyDEMFilter::Mosaic_Conventional(Input_Tiles,Mosaic_Output_Loc);}
			
	}
	else
	{
		printf("Pass the arguments correctly\nUsage:DEMFIlterRef.exe <full_path_to_Tiles_Location> <Output_Location> <opt>\nopt:1-Proposed method;2-Conventional feathering-based blend;3-Average method\nE.g.,DEMFIlterRef.exe E:\\DEMmosa\\Overlap24Sept 1\n");
	}	
	
return 0;
	
}

