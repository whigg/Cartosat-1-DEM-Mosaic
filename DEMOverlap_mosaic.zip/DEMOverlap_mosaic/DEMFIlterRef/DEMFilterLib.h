 //DEMFilterLib.h
#include<stdio.h>
#include<algorithm>
#include<vector>
#include<iterator>
#include<regex>
using namespace std;
//#define NoDataVal -9999
#define NoDataVal 0
struct input_dem
		{
			char in_file[300]; 
			short PathNo;
			short RowNo;
			int rows;
			int cols;
			double ul_y;
			double ul_x;

			double ur_y;
			double ur_x;

			double lr_y;
			double lr_x;
			

			double ll_y;
			double ll_x;
			double delx;
			double dely;
			int year;
			bool qualify;
			bool used;//participation in mosaic
		};
		//struct input_dem *InDem;		
		
		struct Overlap_Info
		{
			short src_demno; 
			short trg_demno; 
			double ul_y;
			double ul_x;
			double ur_y;
			double ur_x;
			double lr_y;
			double lr_x;
			double ll_y;
			double ll_x;
			int src_st_scan;
			int src_st_pixel;
			int src_end_scan;
			int src_end_pixel;
			
			int trg_st_scan;
			int trg_st_pixel;
			int trg_end_scan;
			int trg_end_pixel;

			int output_st_scan;
			int output_st_pixel;
			int output_end_scan;
			int output_end_pixel;
		};
		
namespace DEMFilter
{

    class MyDEMFilter
    {
	
    public:
        
       static bool BasedonPathRow (string elem1, string elem2 );
	   static int Vector_process(std::vector<string> Vec_Path);
	   static vector<string> Mosaic_TwoAtaTime(char infile[300],std::vector<string> Pathwise,int path1,int fl,char out[300],int North,int East);
	   static int Mosaic_Average(char infile[300],char outfolder[300]);
	   static int Mosaic_Conventional(char infile[300],char outfolder[300]);
	   
	   static int Mosaic_Proposed(char infile[300],char outfile[300]);
	   static signed short int cubic_conv(float x,float y,signed short int **neighb);
	   static signed short int Bilinear(double x,double y,signed short int **neighb);
	   static int Mosaic_process(vector<string> Vec_Path,char infile[300],char HorV,char inter_file[300],int cut,int North,int East);
	   static int Delete_TempFiles(vector<string> TempFiles);
	   static int mtf()
	   {
		   return 0;
	   }
	   static int Zerofill(char folder[300]);   
	  
	   static int L2R_Blend(FILE *rrdfile1,int blend_freq,int fifty,char LorR,struct input_dem *InDem,struct Overlap_Info *Oinfo,int Overlap_scans,int Overlap_pixels,int intersect_count,double output_maxy,double output_minx,int r,int s,signed short int **outarr,signed short int ***inarr1, double &,double &);//Horizontal Blending		
	   static int T2B_Blend(FILE *rrdfile2,int blend_freq,int fifty,char LorR,struct input_dem *InDem,struct Overlap_Info *Oinfo,int Overlap_scans,int Overlap_pixels,int intersect_count,double output_maxy,double output_minx,int r,int s,signed short int **outarr,signed short int ***inarr1, double &,double &);//Vertical Blending
	   static int Compute_Delxy(double minx,double maxx,double miny,double maxy,float Resolution,double &,double &);//Computes DelX and DelY spacing for Output(Mosaicked DEM)
	   
	   static bool quickRejection_Passed(double rx1, double ry1, double rx2, double ry2, double rx3, double ry3, double rx4, double ry4,int e);
	   static bool doIntersect(double p1x, double p1y, double q1x, double q1y, double p2x, double p2y, double q2x, double q2y);
	   static bool isIntersected(double Pt_x1, double Pt_y1, double Pt_x2, double Pt_y2, double Test_x1, double Test_y1, double Test_x2, double Test_y2);
	   static bool onSegment(double Px, double Py, double Qx, double Qy, double Rx, double Ry);
	   static int orientation(double Px, double Py, double Qx, double Qy, double Rx, double Ry);//int orientation(Point p, Point q, Point r)
	   static struct overlap_struct computeInters_point(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4);
	   //static struct overlap_struct computeInters_point(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4);
    };
}
