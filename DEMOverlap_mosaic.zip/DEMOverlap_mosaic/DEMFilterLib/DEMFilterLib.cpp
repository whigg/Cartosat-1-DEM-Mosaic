// DEMFilterLib.cpp
// compile with: /c /EHsc
// post-build command: lib DEMFilterLib.obj

#include "DEMFilterLib.h"
#include "sips.h"
#include "sips_constant.h"
//#include "least_square.h"
//#include "alloc_free.h"
#include<stdlib.h>
#include <stdexcept>
#include <iostream>
#include <errno.h>
#include < vcclr.h >
#include <afx.h>
#include<vector>
#include<math.h>
#include <fstream>
#include <sstream>
using namespace std;
#using <System.dll>

using namespace System;
using namespace System::Diagnostics;
using namespace System::ComponentModel;


using namespace System::IO;
using namespace System::Collections;
FILE *fdrr;
errno_t err;	
char dummy[300];

namespace DEMFilter
{


int MyDEMFilter::Mosaic_Average(char infile[300],char outfolder[300])
	{
		errno_t err;		
		FILE *fout,*fqual,*fin,*f_adres,*foutput;
		int count=0,i,j,k,l,fresult;
		double drr_temp=0.000,drr_temp1=0.00;
		int nocount,Xmx,Ymx,Xmx1,Ymx1,nodata=-9999,min,max;
		signed short int NoData=NoDataVal;
		char *buffer;
		FILE *f1,*f2,*f20;
		
		char *args1,*args_aster,*args_srtm;
		//char aster_file[300],srtm_file[300],Fused_file[300];
		//String^ args1;
		//String^ args_aster;
		//String^ args_srtm;
		int m,*Samples;
		
		signed short int **h,**n,**temp,**outarr,***inarr,VAL,*arrscan,***inarr1,pindata[100],TEMP[50];
		signed int **samples;
		int result1,result2;
		long position,end;
		char outfile_avg[300],outfile[300],overlap1[300];
		double UpperLeft_Lat,UpperLeft_Lon,LowerRight_Lat,LowerRight_Lon,LowerLeft_Lat,LowerLeft_Lon,UpperRight_Lat,UpperRight_Lon;
		j=0;
		int fno=0;
		int real_count,total,pinsets,scan,pix;//pinning
		float scan_in,pix_in,xloc,yloc;
		int total_dems=0,n2,n3,qualify_count=0;
		//qualify_count<=>file_count
		signed short int  **in_address1,**out_address1;
		double min_x,min_y,max_x,max_y,quad1_minx,quad1_maxx,quad1_miny,quad1_maxy;
		min_x=99999999.0;
		max_x=-99999999.0;
		min_y=99999999.0;
		max_y=-99999999.0;
		int quad1_scans,quad1_pixels,lines,pixels;
		int temp_count=0;
		//int in_address[50][4],out_address[50][4];
		//in_file[i],&SCAN[i],&PIX[i],&ul_y[i],&ul_x[i],&lr_y[i],&lr_x[i]
		struct input_dem
		{
			char in_file[300]; 
			int rows;
			int cols;
			double ul_y;
			double ul_x;
			double lr_y;
			double lr_x;
			double delx;
			double dely;
			bool qualify;
		};
		struct input_dem *InDem;



		////////////////////////////////////////////////
		vector<string> AllDEMfiles;
		CFileFind fnd;
		BOOL bfnd;
		CString strFolder;
		string tmp="";
		char tmp1[300],tmp2[300],tmp3[300];
		double time1,time2;
		WIN32_FIND_DATA FindFileData;
		HANDLE hFind;
		string sPath;
		vector<string> MyVect;
		strcpy(tmp3,"");
		strcpy(tmp3,outfolder);
		strcat(outfolder,"\\");  	
		
		strcpy(tmp2,infile);
		strcpy(tmp1,"");
		strcat(tmp1,infile);
		strcat(tmp1,"\\*");
		sPath.assign(tmp1);
		hFind=FindFirstFile(sPath.data(),&FindFileData);
		do
		{
			if(FindFileData.dwFileAttributes==16)
			{
				MyVect.push_back(FindFileData.cFileName);
			}
			else
			{
				printf("Check the existence of the folder %s\n",infile);
				return -1;
			}
		}while(FindNextFile(hFind,&FindFileData));

		
		//Converting to binary files
		for(int x=2;x<MyVect.size();x++)
		{
			strcpy(infile,"");
			strcpy(infile,tmp2);
			strcat(infile,"\\");	  		
			strcat(infile,MyVect.at(x).data());
			strcat(outfolder,MyVect.at(x).data());
			string _dir = infile;	   
			strFolder = _dir.data();	
			strFolder += "\\*.tif";//changed DRR
			bfnd = fnd.FindFile(strFolder);
			char*ptr=strstr(infile, "_E");
			char s[5];
			ptr += 2;
			strncpy(s, ptr, 2);
			s[2]='\0';
			int e = atof(s);

			ptr +=4;
			strncpy(s, ptr, 2);
			s[2]='\0';
			int nn = atof(s);
			/***************************************/
			printf("\t=========================================================================\n");
			printf("\tCreating mosaic of DEM scenes for an ROI of 1 degree x 1 degree \n\t\t(Lat:%d to %d; Lon:%d to %d(Decimal Degrees))\n",nn,nn+1,e,e+1);
			printf("\t=========================================================================\n");			
			int fno1=0;
	    
			int distinct_paths=0;
			//AllDEMfiles.clear();
			while(bfnd)
			{
				bfnd = fnd.FindNextFile();		  
				CString f=fnd.GetFilePath();
				tmp=f.operator LPCSTR();	
				//AllDEMfiles.push_back((char *)f.operator LPCSTR());
				string arg1;
				//string outfile1=outfile
				string exe1 = "Gtiff2Bin.exe";
				arg1 +=  (char *)f.operator LPCSTR();			
				CString cmd;
				cmd.Format("%s %s",exe1.c_str(), arg1.c_str());
				STARTUPINFO stat;
				PROCESS_INFORMATION process;

				ZeroMemory( &stat, sizeof(stat) );
				stat.cb = sizeof(stat);
				ZeroMemory( &process, sizeof(process) );

				int pret=CreateProcess((char*)exe1.c_str(),(char*)cmd.operator LPCTSTR(),NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&stat,&process);
				WaitForSingleObject(process.hProcess,INFINITE);
				CloseHandle( process.hProcess );
				CloseHandle( process.hThread );
				fno1++;
			}
		}
	
		
	  	   
	   fno=0;
		for(int x=2;x<MyVect.size();x++)
		{
			time1=time(NULL);
			cout<<"\t\t\tTile Name:"<<MyVect.at(x).data()<<endl;
		    cout<<"Mosaic process using Average method is in progress. It takes few minutes.Please wait.."<<endl;
			strcpy(infile,"");
			strcpy(infile,tmp2);
			strcat(infile,"\\");	  		
			strcat(infile,MyVect.at(x).data());
			string _dir = infile;	   
			strFolder = _dir.data();	
			strFolder += "\\*.Img";//changed DRR
			bfnd = fnd.FindFile(strFolder);
			char*ptr=strstr(infile, "_E");
			char s[5];
			ptr += 2;
			strncpy(s, ptr, 2);
			s[2]='\0';
			int e = atof(s);

			ptr +=4;
			strncpy(s, ptr, 2);
			s[2]='\0';
			int nn = atof(s);
			/***************************************/		
			int fno1=0;
	    
			int distinct_paths=0;
			AllDEMfiles.clear();
			while(bfnd)
			{
				   bfnd = fnd.FindNextFile();
				   CString f=fnd.GetFilePath();
				   tmp=f.operator LPCSTR();			  
				   AllDEMfiles.push_back((char *)f.operator LPCSTR());
				   fno++;
			}	
		}
	   total_dems=fno;
	  
	   bfnd = fnd.FindFile(strFolder);
	   InDem=(struct input_dem *)malloc(sizeof(struct input_dem)*total_dems);//to track pos
		for(int v=0;v<total_dems;v++)
		{
			strcpy(InDem[v].in_file, "");
			InDem[v].rows=0;
		    InDem[v].cols=0;			
			InDem[v].ul_y=0.00;
		    InDem[v].ul_x=0.00;
			InDem[v].lr_y=0.00;
		    InDem[v].lr_x=0.00;			
			InDem[v].delx=0.00;
			InDem[v].dely=0.00;
			InDem[v].qualify=false;//Falling in OP Extent
		}
	   fno=0;
	  
	   while(bfnd)
	   {
		   bfnd = fnd.FindNextFile();
		   CString f=fnd.GetFilePath();
		   tmp=f.operator LPCSTR();
		   //InDem[fno].fname=(LPCTSTR)fnd.GetFileName();//f.operator LPCSTR();
		  
		   //Aips header info
		    KT_HEAD* head = new KT_HEAD;
			KT_coord_scan_pix corner_info;
			head->initialization();
			head->getheader((char*) f.operator LPCSTR());
			int lines, pixels;
			float resolution;
			head->getvalues(KD_SCANS, &lines, KD_PIXELS, &pixels,KD_N_RESOLUTION,&resolution, NULL);	
			head->getvalue(KD_COORD_SCAN_LAT,corner_info);
		
			/*LowerLeft_Lat=corner_info.coord[3][0];
			LowerLeft_Lon=corner_info.coord[3][1];
			UpperRight_Lat=corner_info.coord[1][0];

			UpperRight_Lon=corner_info.coord[1][1];*/
			UpperLeft_Lat=corner_info.coord[0][0];
			UpperLeft_Lon=corner_info.coord[0][1];
			LowerRight_Lat=corner_info.coord[2][0];
			LowerRight_Lon=corner_info.coord[2][1];		

			strcpy(InDem[fno].in_file, f.operator LPCSTR());
			//InDem[fno].fname=f;
			InDem[fno].rows=lines;
		    InDem[fno].cols=pixels;			
			InDem[fno].ul_y=UpperLeft_Lat;
		    InDem[fno].ul_x=UpperLeft_Lon;
			InDem[fno].lr_y=LowerRight_Lat;
		    InDem[fno].lr_x=LowerRight_Lon;			
			InDem[fno].delx=((double)(LowerRight_Lon-UpperLeft_Lon)/(double)pixels);
			InDem[fno].dely=(double)(UpperLeft_Lat - LowerRight_Lat)/(double)lines;
			InDem[fno].qualify=false;//Falling in OP Extent
		   //end of Aips 
			/*printf("\nfile[%d]=%s\n",fno,InDem[fno].in_file);

		   printf("delx[%d]=%f\t",fno,InDem[fno].delx);
		   printf("dely[%d]=%f\n",fno,InDem[fno].dely);*/
		   fno++;
		   delete head;
	   }	 
	   /*fout=fopen("G:\\drr\\Input DEMs Extent.txt","w+");
	   fqual=fopen("G:\\drr\\Qualified.txt","w+");
	   for(int r=0;r<fno;r++)

	   {
		   fprintf(fout,"%s\t",InDem[r].in_file);
		   fprintf(fout,"%d\t",InDem[r].rows);
		   fprintf(fout,"%d\t",InDem[r].cols);

		   fprintf(fout,"%f\t",InDem[r].ul_y);
		   fprintf(fout,"%f\t",InDem[r].ul_x);
		   fprintf(fout,"%f\t",InDem[r].lr_y);

		   fprintf(fout,"%f\t",InDem[r].lr_x);
		   fprintf(fout,"%f\t",InDem[r].delx);
		   fprintf(fout,"%f\n",InDem[r].dely);
	   }

	   fclose(fout);*/
	   for(int r=0;r<fno;r++)
	   {
		   if(min_x >= InDem[r].ul_x)
			   min_x=InDem[r].ul_x;
			if(min_y >= InDem[r].lr_y)
				min_y=InDem[r].lr_y;
			//printf("min vaaaaaaaaaaaals X = %lf  y = %lf\n",min_x,min_y);getchar();

			if(max_x <= InDem[r].lr_x)
				max_x=InDem[r].lr_x;
			if(max_y <= InDem[r].ul_y)
				max_y=InDem[r].ul_y;
			
	   }
	   //OP Extent computation
	   quad1_minx=min_x;
	   quad1_maxx=max_x;//min_x+(max_x-min_x)/2.0;
	   quad1_miny=min_y;
	   quad1_maxy=max_y;//min_y+(max_y-min_y)/2.0;
	   
	   /*quad1_scans=(int)((double)(quad1_maxy-quad1_miny)/(double)InDem[0].dely);
	   quad1_pixels=(int)((double)(quad1_maxx-quad1_minx)/(double)InDem[0].delx);
	   */
	   quad1_scans=((quad1_maxy-quad1_miny)/InDem[0].dely);
	   quad1_pixels=((quad1_maxx-quad1_minx)/InDem[0].delx);
	   
	   outarr=(signed short int **)malloc(sizeof(signed short int *)*quad1_scans);
	   for(int pr=0;pr<quad1_scans;pr++)
		{
			//n[i]=(signed short int *)malloc(sizeof(signed short int)*Ymx);
			outarr[pr]=(signed short int *)malloc(sizeof(signed short int)*quad1_pixels);

		}
		//Initialization of OP Grid
		for(int pr=0;pr<quad1_scans;pr++)
		{

			for(int qr=0;qr<quad1_pixels;qr++)
			{
				outarr[pr][qr]=0;
			}
		}

	   for(int r=0;r<fno;r++)
	   {
		   if(InDem[r].ul_x < quad1_miny  || InDem[r].lr_y > quad1_maxy || InDem[r].ul_x > quad1_maxx || InDem[r].lr_x < quad1_minx)
   				InDem[r].qualify=false;
		   else
			   InDem[r].qualify=true;

	   }
	   //fprintf(fqual,"filename\t\t\trows\tcols\tul_y\tul_x\tlr_y\tlr_x\tdelx\tdely\n");
	   for(int r=0;r<fno;r++)
	   {
		   if(InDem[r].qualify)
		   {
			  /* fprintf(fqual,"%s\t",InDem[r].in_file);
			   fprintf(fqual,"%d\t",InDem[r].rows);

			   fprintf(fqual,"%d\t",InDem[r].cols);
			   fprintf(fqual,"%f\t",InDem[r].ul_y);
			   fprintf(fqual,"%f\t",InDem[r].ul_x);
			   fprintf(fqual,"%f\t",InDem[r].lr_y);

			   fprintf(fqual,"%f\t",InDem[r].lr_x);
			   fprintf(fqual,"%f\t",InDem[r].delx);
			   fprintf(fqual,"%f\n",InDem[r].dely);*/
			   qualify_count++;
		   }

		  
	   }
	   if(qualify_count==0)
	   {
		   printf("No DEMs exist in OP Extent\n");
		   return -1;
	   }
	   //fclose(fqual);

	   /*inarr=(signed short int ***)malloc(sizeof(signed short int **)*qualify_count);
		if (inarr == NULL)
			printf("inarr Alloc prob\n");


		for(int p=0;p<fno;p++)
		{
			 if(InDem[p].qualify)
			 {

				 n2=InDem[p].rows;
				 n3=InDem[p].cols;
				printf(" infile = %d SCAN = %d PiX= %d\n",p,n2,n3);
				inarr[temp_count]=(signed short int **)malloc(sizeof(signed short int *)*n2);	

				for(int j=0;j<n2;j++)
				{
					inarr[temp_count][j]=(signed short int *)malloc(sizeof(signed short int )*n3);
			

					for(int k=0;k<n3;k++)
					{	
						inarr[temp_count][j][k]=0;
					}

				}
				temp_count++;
			 }
				
		}*/
		/*printf("allocation of ip grid is OVER. Press key\n");
		getchar();*/
		
		inarr1=(signed short int ***)malloc(sizeof(signed short int **)*fno);
		temp_count=0;
		for(int i=0;i<fno;i++)
		{
			/*if(InDem[i].qualify)
			{*/
			if( (err  = fopen_s( &fin, InDem[i].in_file, "rb" )) !=0 )
			{
				printf( "The input file: %s was not opened\n",InDem[i].in_file);
				return -1;
			}
				//fin=fopen(InDem[i].in_file,"rb");
				//printf("Reading arrays from the infile with %s-----   %d %d\n",InDem[i].in_file,InDem[i].rows,InDem[i].cols);//getchar();
				
				fresult=fseek(fin, 2048, SEEK_SET);   
				lines=InDem[i].rows;
				pixels=InDem[i].cols;
				inarr1[i]=(signed short int **)malloc(sizeof(signed short int *)*lines);	
				arrscan=(signed short int *)malloc(sizeof(signed short int)*pixels);
							
				for(int j=0;j<lines;j++)
				{ 					
					fread(arrscan,sizeof(signed short int),pixels,fin);
					inarr1[i][j]=(signed short int *)malloc(sizeof(signed short int )*pixels);
					for(int k=0;k<pixels;k++)
					{
						VAL= arrscan[k];
						inarr1[i][j][k]=VAL;
						//fread((char*)&inarr1[temp_count][j][k],  sizeof(signed short int),1, fin);
						//printf("%d\t",inarr1[temp_count][j][k]);
					}
					//printf("\n");
				}
				fclose(fin);
				//printf("Dooing file -- %d  \n",i);
				//temp_count++;
			//}
			

		}


		


	KT_coord_scan_pix output_corner_details;

	output_corner_details.scan_pix[0][0]=0;
	output_corner_details.scan_pix[0][1]=0;

	output_corner_details.scan_pix[1][0]=0;
	output_corner_details.scan_pix[1][1]=quad1_pixels-1;

	output_corner_details.scan_pix[2][0]=quad1_scans-1;
	output_corner_details.scan_pix[2][1]=quad1_pixels-1;

	output_corner_details.scan_pix[3][0]=quad1_scans-1;
	output_corner_details.scan_pix[3][1]=0;


	LowerLeft_Lat=output_corner_details.coord[3][0]=quad1_miny;
	LowerLeft_Lon=output_corner_details.coord[3][1]=quad1_minx;
	UpperRight_Lat=output_corner_details.coord[1][0]=quad1_maxy;
	UpperRight_Lon=output_corner_details.coord[1][1]=quad1_maxx;
	UpperLeft_Lat=output_corner_details.coord[0][0]=quad1_maxy;
	UpperLeft_Lon=output_corner_details.coord[0][1]=quad1_minx;
	LowerRight_Lat=output_corner_details.coord[2][0]=quad1_miny;
	LowerRight_Lon=output_corner_details.coord[2][1]=quad1_maxx;	

	KT_HEAD* head = new KT_HEAD;
	head->initialization();
	head->getheader(InDem[0].in_file);
	//head->getvalues(KD_SCANS, &lines, KD_PIXELS, &pixels,KD_N_RESOLUTION,&resolution, NULL);
	sprintf(outfile,"%s%s.DEM",outfolder,"_full");	
	//sprintf(outfile_avg,"%s.DEM",outfolder);	

	head->addheader(outfile);//adding AIPS header to outfile 
					
	head->setvalues(KD_SCANS, &quad1_scans, KD_PIXELS, &quad1_pixels, KD_COORD_SCAN_LAT, &output_corner_details, NULL);
	head->replaceheader(outfile);
	delete head;
	////Pinning data
	if( (err  = fopen_s( &foutput, outfile, "ab" )) !=0 )
	{
		printf( "The output file: %s was not opened\n",outfile);
		return -1;
	}
	
	for(i=0;i<quad1_scans;i++)
	{
		for(j=0;j<quad1_pixels;j++)
		{
			xloc=quad1_minx+j*InDem[0].delx;
			yloc=quad1_maxy-i*InDem[0].dely;
			pinsets=0;
			for(l=0;l<qualify_count;l++)
			{
				TEMP[l]=0;
				pindata[l]=0;
			}
			total=0;
			real_count=0;
			//SEARCHING IN ALL FILES for current XLOC YLOC of Out
			for(k=0;k<fno;k++)
			{
				if(InDem[k].qualify)
				{
					drr_temp=InDem[k].ul_x;
					drr_temp1=InDem[k].lr_x;
					if(xloc >= InDem[k].ul_x && xloc <= InDem[k].lr_x)
					{
						if(yloc >= InDem[k].lr_y && yloc <= InDem[k].ul_y)
						{
							pix_in=(float)((double)(xloc-InDem[k].ul_x)/(double)InDem[k].delx);
							scan_in=(float)((double)(InDem[k].ul_y-yloc)/(double)InDem[k].dely);
							pix=(int)pix_in;
							scan=(int)scan_in;
							if(pix >= InDem[k].cols)
								pix=InDem[k].cols-1;
							if(scan >= InDem[k].rows)
								scan=InDem[k].rows-1;
							//printf("for File=%s\nscan=%d\t",InDem[k].in_file,scan);
							//printf("pix=%d\n",pix);
							TEMP[pinsets]=inarr1[k][scan][pix];
							pindata[pinsets]=k;
							pinsets++;
						}
					}
				}
			}//SEARCH over 
			if(pinsets >0)
			{
				for(l=0;l<pinsets;l++)
				{
					if(TEMP[l] != 0)
					{
						total=total+TEMP[l];
						real_count++;
					}
				}
								
				if(real_count != 0)
					outarr[i][j]=(int)((double)total/(double)real_count);//pinsets;//
				else 
					outarr[i][j]=0;
			}
			else 
				outarr[i][j]=0;
			
		}
		
	}

	for(int r1=0;r1<quad1_scans;r1++)
	{
		fwrite((char *)outarr[r1], sizeof(signed short int),quad1_pixels, foutput);		
	}
		
	fclose(foutput);
	for(int r1=0;r1<quad1_scans;r1++)
	{
		free(outarr[r1]);		
	}
	free(outarr);
	//Delete_TempFiles(AllDEMfiles);
	//EOF pinning	
	//output generated for the given ROI
	char*ptr=strstr(outfolder, "_E");
		char s[5];
		ptr += 2;
		strncpy(s, ptr, 2);
		s[2]='\0';
		int e = atof(s);

		ptr +=4;
		strncpy(s, ptr, 2);
		s[2]='\0';
		int nn = atof(s);

		stringstream corner;	
		corner << e << " ";
		corner << Math::Round(nn+1.0) << " ";
		corner << Math::Round(e+1.0) << " ";
		corner << nn << " ";
		string arg;
		string exe = "gdal_translate.exe";
		arg = "-of AIPS ";
		if(NoData==0)
			arg += "-a_nodata 0";
		else
			arg += "-a_nodata 55537";
		//arg += NoData.str();
		arg += " -a_ullr ";
		arg += corner.str();
		arg += " -projwin ";
		arg += corner.str() + " ";
		arg += outfile;
		arg += " ";
		arg += outfolder;
		arg += ".DEM";
		
		
		//arg += ".DEM";
		/*arg += infile;
		arg += "\\DEMMosa.DEM";
		arg += " ";
		arg += infile;
		arg += "\\";
		arg += MyVect.at(x).data();

		arg += ".DEM";*/
		CString cmd;
		cmd.Format("%s %s",exe.c_str(), arg.c_str());
		STARTUPINFO stat;
		PROCESS_INFORMATION process;

		ZeroMemory( &stat, sizeof(stat) );
		stat.cb = sizeof(stat);
		ZeroMemory( &process, sizeof(process) );

		int pret=CreateProcess((char*)exe.c_str(),(char*)cmd.operator LPCTSTR(),NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&stat,&process);
		WaitForSingleObject(process.hProcess,INFINITE);
		CloseHandle( process.hProcess );
		CloseHandle( process.hThread );
		//Updating mode 2 to 8 in AIPS HEADER
		strcpy(overlap1,"");
		sprintf(overlap1,"%s",outfile);
			
		head = new KT_HEAD;
		head->initialization();
		head->getheader(overlap1);
		
		//head->addheader(outfile);//adding AIPS header to outfile 
		char mod1='8';
			
		head->setvalues(KD_MODE,&mod1, NULL);
		head->replaceheader(overlap1);
					
		delete head;
		//writing the final output
			
			
		string arg1;
		//string outfile1=outfile
		string exe1 = "gdal_translate.exe";
		arg1 = "-of GTIFF ";			
		arg1 += outfolder;
		arg1 += ".DEM";		
		arg1 += " ";
		arg1 += outfolder;
		arg1 += "_average.tif";	
		/*arg += infile;
		arg += "\\DEMMosa.DEM";

		arg += " ";
		arg += infile;
		arg += "\\";
		arg += MyVect.at(x).data();

		arg += ".DEM";*/
		//CString cmd;
		cmd.Format("%s %s",exe1.c_str(), arg1.c_str());
		//STARTUPINFO stat;
		//PROCESS_INFORMATION process;

		ZeroMemory( &stat, sizeof(stat) );
		stat.cb = sizeof(stat);
		ZeroMemory( &process, sizeof(process) );

		pret=CreateProcess((char*)exe.c_str(),(char*)cmd.operator LPCTSTR(),NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&stat,&process);
		WaitForSingleObject(process.hProcess,INFINITE);
		CloseHandle( process.hProcess );
		CloseHandle( process.hThread );
		printf("Mosaic process has been completed.\nDEM mosaic output is saved in %s_average.tif\n",outfolder);
		
		for(int x=2;x<MyVect.size();x++)
		{
			strcpy(outfolder,"");
			strcpy(outfolder,tmp3);
			strcat(outfolder,"\\");	  		
			//strcat(outfile,MyVect.at(x).data());
			string _dir = outfolder;	   
			strFolder = _dir.data();	
			strFolder += "\\*.DEM";
			bfnd = fnd.FindFile(strFolder);
			AllDEMfiles.clear();
			while(bfnd)
			{
				bfnd = fnd.FindNextFile();		  
				CString f=fnd.GetFilePath();
				tmp=f.operator LPCSTR();	

				AllDEMfiles.push_back((char *)f.operator LPCSTR());
			}
		
		}
		Delete_TempFiles(AllDEMfiles);
		AllDEMfiles.clear();
return 0;
}


int MyDEMFilter::Mosaic_Conventional(char infile[300],char outfolder[300])
{
	/*printf("\t=========================================================================\n");

			printf("\tCreating mosaic of DEM scenes for an ROI of 1 degree x 1 degree \n\t\t(Lat:%d to %d; Lon:%d to %d(Decimal Degrees))\n",nn,nn+1,e,e+1);
			printf("\t=========================================================================\n");
			printf("\nFeathering-based blend method between:%s\t%s\n",InDem[r].in_file,InDem[s].in_file);*/
		errno_t err;		
		FILE *fout,*fqual,*fin,*f_adres,*foutput,*fdrr,*rrdfile,*fgrid,*rrdfile1,*fA1,*fA2,*fH,*fvA1;
		int count=0,i,j,k,l,fresult;
		double drr_temp=0.000,drr_temp1=0.00;
		int nocount,Xmx,Ymx,Xmx1,Ymx1,nodata=-9999,min,max;
		int sideno=0;
		char *buffer;
		char outfile[300],overlap[300],overlap1[300],A1file[300],A2file[300],Hmfile[300],ValidA1file[300];
		FILE *f1,*f2,*f20;
		signed short int NoData=NoDataVal;
		char *args1,*args_aster,*args_srtm;
		char aster_file[300],srtm_file[300],Fused_file[300];
		//String^ args1;
		//String^ args_aster;
		//String^ args_srtm;
		int m,*Samples;
		
		signed short int **h,**n,**temp,**outarr,***inarr,VAL,*arrscan,***inarr1,pindata[100],TEMP[50],**Array1,**Array2;
		signed int **samples;
		int result1,result2;
		long position,end;
		double UpperLeft_Lat,UpperLeft_Lon,LowerRight_Lat,LowerRight_Lon,LowerLeft_Lat,LowerLeft_Lon,UpperRight_Lat,UpperRight_Lon;
		j=0;
		int fno=0;
		int real_count,total,pinsets,scan,pix;//pinning
		float scan_in,pix_in,xloc,yloc;
		int total_dems=0,n2,n3,qualify_count=0;
		//qualify_count<=>file_count
		signed short int  **in_address1,**out_address1;
		double min_x,min_y,max_x,max_y,output_minx,output_maxx,output_miny,output_maxy;
		min_x=99999999.0;
		max_x=-99999999.0;
		min_y=99999999.0;
		max_y=-99999999.0;
		output_minx=99999999.0;
		output_maxx=-99999999.0;
		output_miny=99999999.0;
		output_maxy=-99999999.0;
		int quad1_scans,quad1_pixels,output_scans,output_pixels,lines,pixels,array1_scans,array1_pixels,array2_scans,array2_pixels;
		int temp_count=0,ver=0,valid=0,int_count,semi_count,intersect_count=0;
		short **Adj;
		double xspace=0.0, yspace=0.0;
		float resolution;
		float Alpha=0.0,Hermite=0.0;
		short *Sides,side_count;//holds distinct sides of two polygons that are intersected in current session.
		int A1StPix,A1EndPix,A2StPix,A2EndPix,A1StScan,A1EndScan;
		//int in_address[50][4],out_address[50][4];
		//in_file[i],&SCAN[i],&PIX[i],&ul_y[i],&ul_x[i],&lr_y[i],&lr_x[i]
		struct input_dem
		{
			char in_file[300]; 
			int rows;
			int cols;
			double ul_y;
			double ul_x;

			double ur_y;
			double ur_x;

			double lr_y;
			double lr_x;
			

			double ll_y;
			double ll_x;
			double delx;
			double dely;
			bool qualify;
			bool used;//participation in mosaic
		};
		struct input_dem *InDem;
		
		struct edge
		{
			double r_x1;
			double r_y1;
			double r_x2;
			double r_y2;//source rect edge			

			double s_x1;
			double s_y1;
			double s_x2;
			double s_y2;//target rect edge
			int src_imageno; 
			int trg_imageno; 
		};
		struct Overlap_Info
		{
			short src_demno; 
			short trg_demno; 
			double ul_y;
			double ul_x;
			double ur_y;
			double ur_x;
			double lr_y;
			double lr_x;
			double ll_y;
			double ll_x;
			int src_st_scan;
			int src_st_pixel;
			int src_end_scan;
			int src_end_pixel;
			
			int trg_st_scan;
			int trg_st_pixel;
			int trg_end_scan;
			int trg_end_pixel;

			int output_st_scan;
			int output_st_pixel;
			int output_end_scan;
			int output_end_pixel;
		};
		struct Overlap_Info *Oinfo;

	   //Start	   
	   vector<string> AllDEMfiles;
		CFileFind fnd;
		BOOL bfnd;
		CString strFolder;
		string tmp="";
		char tmp1[300],tmp2[300],tmp3[300];

	   WIN32_FIND_DATA FindFileData;
	   HANDLE hFind;
	   string sPath;
	   vector<string> MyVect;
	   strcpy(tmp3,"");
		strcpy(tmp3,outfolder);
		strcat(outfolder,"\\");  	
		
		strcpy(tmp2,infile);
		strcpy(tmp1,"");
		strcat(tmp1,infile);
		strcat(tmp1,"\\*");
		sPath.assign(tmp1);
	   hFind=FindFirstFile(sPath.data(),&FindFileData);
	   do
	   {
		   if(FindFileData.dwFileAttributes==16)
		   {
			   MyVect.push_back(FindFileData.cFileName);
		   }
	   }while(FindNextFile(hFind,&FindFileData));


	   for(int x=2;x<MyVect.size();x++)
	   {
			   cout<<MyVect.at(x).data()<<endl;

	   }
	   //End

	   for(int x=2;x<MyVect.size();x++)
		{
			//time1=time(NULL);
			cout<<"\t\t\tTile Name:"<<MyVect.at(x).data()<<endl;
		    cout<<"Mosaic process using CONVENTIONLA FEATHERING-BASED BLEND method is in progress. It takes few minutes.Please wait.."<<endl;
			strcpy(infile,"");
			strcpy(infile,tmp2);
			strcat(infile,"\\");	  		
			strcat(infile,MyVect.at(x).data());
			strcat(outfolder,MyVect.at(x).data());
			string _dir = infile;	   
			strFolder = _dir.data();	
			strFolder += "\\*.Img";
			bfnd = fnd.FindFile(strFolder);
			char*ptr=strstr(infile, "_E");
			char s[5];
			ptr += 2;
			strncpy(s, ptr, 2);
			s[2]='\0';
			int e = atof(s);

			ptr +=4;
			strncpy(s, ptr, 2);
			s[2]='\0';
			int nn = atof(s);
			/***************************************/		
			int fno1=0;
	    
			int distinct_paths=0;
			AllDEMfiles.clear();
			while(bfnd)
			{
				   bfnd = fnd.FindNextFile();
				   CString f=fnd.GetFilePath();
				   tmp=f.operator LPCSTR();			  
				   AllDEMfiles.push_back((char *)f.operator LPCSTR());
				   fno++;
			}	
		}	 
	   total_dems=fno;
	   bfnd = fnd.FindFile(strFolder);
	   
	   InDem=(struct input_dem *)malloc(sizeof(struct input_dem)*total_dems);//to track pos
		for(int v=0;v<total_dems;v++)
		{
			strcpy(InDem[v].in_file, "");
			InDem[v].rows=0;
		    InDem[v].cols=0;			
			InDem[v].ul_y=0.00;
		    InDem[v].ul_x=0.00;		
			InDem[v].ur_y=0.00;
		    InDem[v].ur_x=0.00;
			InDem[v].lr_y=0.00;
		    InDem[v].lr_x=0.00;			
			InDem[v].ll_y=0.00;
		    InDem[v].ll_x=0.00;			
			InDem[v].delx=0.00;
			InDem[v].dely=0.00;
			InDem[v].qualify=false;//Falling in OP Extent
			//InDem[v].used=false;
		}
	   fno=0;
	  
	   while(bfnd)
	   {
		   bfnd = fnd.FindNextFile();
		   CString f=fnd.GetFilePath();
		   tmp=f.operator LPCSTR();
		   //InDem[fno].fname=(LPCTSTR)fnd.GetFileName();//f.operator LPCSTR();
		  
		   //Aips header info
		    KT_HEAD* head = new KT_HEAD;
			KT_coord_scan_pix corner_info;
			head->initialization();
			head->getheader((char*) f.operator LPCSTR());
			int lines, pixels;
			//float resolution;
			head->getvalues(KD_SCANS, &lines, KD_PIXELS, &pixels,KD_N_RESOLUTION,&resolution, NULL);	
			head->getvalue(KD_COORD_SCAN_LAT,corner_info);
		
			LowerLeft_Lat=corner_info.coord[3][0];
			LowerLeft_Lon=corner_info.coord[3][1];
			UpperRight_Lat=corner_info.coord[1][0];
			UpperRight_Lon=corner_info.coord[1][1];
			UpperLeft_Lat=corner_info.coord[0][0];
			UpperLeft_Lon=corner_info.coord[0][1];
			LowerRight_Lat=corner_info.coord[2][0];
			LowerRight_Lon=corner_info.coord[2][1];		

			strcpy(InDem[fno].in_file, f.operator LPCSTR());			
			InDem[fno].rows=lines;
		    InDem[fno].cols=pixels;			
			InDem[fno].ul_y=UpperLeft_Lat;
		    InDem[fno].ul_x=UpperLeft_Lon;

			InDem[fno].ur_y=UpperRight_Lat;
		    InDem[fno].ur_x=UpperRight_Lon;

			InDem[fno].lr_y=LowerRight_Lat;
		    InDem[fno].lr_x=LowerRight_Lon;

			InDem[fno].ll_y=LowerLeft_Lat;
		    InDem[fno].ll_x=LowerLeft_Lon;

			InDem[fno].delx=((double)(LowerRight_Lon-UpperLeft_Lon)/(double)(pixels-1));
			InDem[fno].dely=(double)(UpperLeft_Lat - LowerRight_Lat)/(double)(lines-1);
			InDem[fno].qualify=false;//Falling in OP Extent
			//InDem[v].used=false;				
			if(resolution<0.0)
			{
				printf("This has Resolution:%f\nKindly correct and submit again.\nExiting....",resolution);
				return -1;
			}
		   fno++;
		   delete head;
	   }	

	   inarr1=(signed short int ***)malloc(sizeof(signed short int **)*fno);
		//temp_count=0;
		for(int i=0;i<fno;i++)
		{
			/*if(InDem[i].qualify)
			{*/
			if( (err  = fopen_s( &fin, InDem[i].in_file, "rb" )) !=0 )
			{
				printf( "The input file: %s was not opened\n",InDem[i].in_file);
				return -1;
			}
				//fin=fopen(InDem[i].in_file,"rb");
				//printf("Reading arrays from the infile with %s-----   %d %d\n",InDem[i].in_file,InDem[i].rows,InDem[i].cols);//getchar();
				
				fresult=fseek(fin, 2048, SEEK_SET);   
				lines=InDem[i].rows;
				pixels=InDem[i].cols;
				inarr1[i]=(signed short int **)malloc(sizeof(signed short int *)*lines);	
				arrscan=(signed short int *)malloc(sizeof(signed short int)*pixels);
							
				for(int j=0;j<lines;j++)
				{ 					
					fread(arrscan,sizeof(signed short int),pixels,fin);
					inarr1[i][j]=(signed short int *)malloc(sizeof(signed short int )*pixels);
					for(int k=0;k<pixels;k++)
					{
						VAL= arrscan[k];
						inarr1[i][j][k]=VAL;
						//fread((char*)&inarr1[temp_count][j][k],  sizeof(signed short int),1, fin);
						//printf("%d\t",inarr1[temp_count][j][k]);
					}
				
					//printf("\n");
				}
				
				fclose(fin);
				
				//printf("Dooing file -- %d  \n",i);
				//temp_count++;
			//}
			

		}
		
			delete arrscan;
		//Output EXTENTS FINDING.....
		
		/*output_minx=e;
		output_maxx=e+1;

		output_miny=nn;
		output_maxy=nn+1;*/
		for(int r=0;r<fno;r++)
	   {
		   if(output_minx >= InDem[r].ul_x)
			   output_minx=InDem[r].ul_x;
			if(output_miny >= InDem[r].lr_y)
				output_miny=InDem[r].lr_y;
			if(output_maxx <= InDem[r].lr_x)
				output_maxx=InDem[r].lr_x;
			if(output_maxy <= InDem[r].ul_y)
				output_maxy=InDem[r].ul_y;
	   }   


	   Compute_Delxy( output_minx, output_maxx, output_miny,output_maxy,resolution, xspace, yspace);
	   output_scans=(int)(((double)(output_maxy-output_miny)/(double)yspace)+0.5);	  
	   output_pixels=(int)(((double)(output_maxx-output_minx)/(double)xspace)+0.5);


	   output_scans+=1;
	   output_pixels+=1;
		
		
	   in_address1=(signed short int **)malloc(sizeof(signed short int *)*fno);
	   for(int p1=0;p1<fno;p1++)
		{		
			in_address1[p1]=(signed short int *)malloc(sizeof(signed short int)*4);
		}
	   out_address1=(signed short int **)malloc(sizeof(signed short int *)*fno);
	   for(int p=0;p<fno;p++)
		{
			out_address1[p]=(signed short int *)malloc(sizeof(signed short int)*4);

		}
	    //Tagging InputDEM extents to Output Grid Extent
		for(int i=0;i<fno;i++)
		{
			in_address1[i][0]=0;
			in_address1[i][1]=0;
			in_address1[i][2]=InDem[i].rows-1;
			in_address1[i][3]=InDem[i].cols-1;					
			
			out_address1[i][0]=(int)(((double)(output_maxy-InDem[i].ul_y)/(double)yspace)+0.5);
			out_address1[i][1]=(int)(((double)(InDem[i].ul_x-output_minx)/(double)xspace)+0.5);
			out_address1[i][2]=(int)(((double)(output_maxy-InDem[i].ll_y)/(double)yspace)+0.5);
			out_address1[i][3]=(int)(((double)(InDem[i].lr_x-output_minx)/(double)xspace)+0.5);	
			//printf("Input	Start (scan,pix)=(%d,%d)\tEnd (scan,pix)=(%d,%d)\n",in_address1[i][0],in_address1[i][1],in_address1[i][2],in_address1[i][3]);
			//printf("Output	Start (scan,pix)=(%d,%d)\tEnd (scan,pix)=(%d,%d)\n ",out_address1[i][0],out_address1[i][1],out_address1[i][2],out_address1[i][3]);
		}	
	  

	    KT_coord_scan_pix output_corner_details;
	    output_corner_details.scan_pix[0][0]=0;
		output_corner_details.scan_pix[0][1]=0;

		output_corner_details.scan_pix[1][0]=0;
		output_corner_details.scan_pix[1][1]=output_pixels-1;

		output_corner_details.scan_pix[2][0]=output_scans-1;
		output_corner_details.scan_pix[2][1]=output_pixels-1;

		output_corner_details.scan_pix[3][0]=output_scans-1;
		output_corner_details.scan_pix[3][1]=0;

					
		LowerLeft_Lat=output_corner_details.coord[3][0]=output_miny;
		LowerLeft_Lon=output_corner_details.coord[3][1]=output_minx;
		UpperRight_Lat=output_corner_details.coord[1][0]=output_maxy;
		UpperRight_Lon=output_corner_details.coord[1][1]=output_maxx;
		UpperLeft_Lat=output_corner_details.coord[0][0]=output_maxy;
		UpperLeft_Lon=output_corner_details.coord[0][1]=output_minx;
		LowerRight_Lat=output_corner_details.coord[2][0]=output_miny;
		LowerRight_Lon=output_corner_details.coord[2][1]=output_maxx;	
	   /*output_scans=((output_maxy-output_miny)/InDem[0].dely);
	   output_pixels=((output_maxx-output_minx)/InDem[0].delx);*/
	    
		

	   outarr=(signed short int **)malloc(sizeof(signed short int *)*output_scans);
	   for(int pr=0;pr<output_scans;pr++)
		{
			//n[i]=(signed short int *)malloc(sizeof(signed short int)*Ymx);
			outarr[pr]=(signed short int *)malloc(sizeof(signed short int)*output_pixels);

		}
		//Initialization of OP Grid
		for(int pr=0;pr<output_scans;pr++)
		{

			for(int qr=0;qr<output_pixels;qr++)
			{
				outarr[pr][qr]=0;
			}
		}
		//printf("OUTTTTTT=%d\n",outarr[15979][1435]);
		//EOf OP extents




	   Adj=(short **)malloc(sizeof(short *)*fno);
	
		for(i=0;i<fno;i++)
		{
			//n[i]=(signed short int *)malloc(sizeof(signed short int)*Ymx);
			Adj[i]=(short *)malloc(sizeof(short)*fno);

		}
		for(int r=0;r<fno;r++)
	   {
		   for(int s=0;s<fno;s++)
		   {
			   Adj[r][s]=0;
		   }	  
	   }
	   Oinfo=(struct Overlap_Info *)malloc(sizeof(struct Overlap_Info)*(fno*(fno-1)/2.0));
	   for(int r=0;r<fno;r++)
	   {
		   
		   //fprintf(fqual,"%s\tcarto\ttest\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",InDem[r].in_file,InDem[r].ul_y, InDem[r].ul_x,InDem[r].ur_y,InDem[r].ur_x,InDem[r].lr_y,InDem[r].lr_x,InDem[r].ll_y,InDem[r].ll_x);
		   //printf("\n%s\tcarto\ttest\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",InDem[r].in_file,InDem[r].ul_y, InDem[r].ul_x,InDem[r].ur_y,InDem[r].ur_x,InDem[r].lr_y,InDem[r].lr_x,InDem[r].ll_y,InDem[r].ll_x);
		   //printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n*********",InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y);
		   struct edge *RectEdge;
		   RectEdge=(struct edge *)malloc(sizeof(struct edge)*2);//It stores points of sides that are intersected
		   Sides=(short *)malloc(sizeof(short)*4);
		   for(int s=r+1;s<fno;s++)
		   {
			   
			   valid=0;
			   sideno=0;
			   side_count=0;
			  /* printf("ul_x[%d]=%f\t",s,InDem[s].ul_x);
			   printf("lr_y[%d]=%f\n",s,InDem[s].lr_y);*/
			   //printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
			   //Case:First side of s			    
			   //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
			   
				  
				  
				   if(isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y))//side 1 of rectangle r
				   {
					   //one edge of source
					    RectEdge[valid].r_x1=InDem[r].ul_x;
						RectEdge[valid].r_y1=InDem[r].ul_y;
						RectEdge[valid].r_x2=InDem[r].ur_x;
						RectEdge[valid].r_y2=InDem[r].ur_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ul_x;
						RectEdge[valid].s_y1=InDem[s].ul_y;						
						RectEdge[valid].s_x2=InDem[s].ur_x;
						RectEdge[valid].s_y2=InDem[s].ur_y;
						//find intersection point
						//computeInters_point(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
						valid++;

						//Sides updation
						Sides[side_count++]=1;//side of r
						Sides[side_count++]=1;//side of s
						 Adj[r][s]=1;

				   }
				   if(isIntersected(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y))
				   {
					    RectEdge[valid].r_x1=InDem[r].ur_x;
						RectEdge[valid].r_y1=InDem[r].ur_y;
						RectEdge[valid].r_x2=InDem[r].lr_x;
						RectEdge[valid].r_y2=InDem[r].lr_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ul_x;
						RectEdge[valid].s_y1=InDem[s].ul_y;						
						RectEdge[valid].s_x2=InDem[s].ur_x;
						RectEdge[valid].s_y2=InDem[s].ur_y;
					   //find intersection point
						//computeInters_point(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
						valid++;
						//Sides updation
						Sides[side_count++]=2;//side of r
						Sides[side_count++]=1;//side of s
						 Adj[r][s]=1;
				   }
			   	   if(isIntersected(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y))//sideno is for rectangle r
				   {
					   RectEdge[valid].r_x1=InDem[r].lr_x;
						RectEdge[valid].r_y1=InDem[r].lr_y;
						RectEdge[valid].r_x2=InDem[r].ll_x;
						RectEdge[valid].r_y2=InDem[r].ll_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ul_x;
						RectEdge[valid].s_y1=InDem[s].ul_y;						
						RectEdge[valid].s_x2=InDem[s].ur_x;
						RectEdge[valid].s_y2=InDem[s].ur_y;
					   //find intersection point
						//computeInters_point(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
						valid++;
						//Sides updation
						Sides[side_count++]=3;//side of r
						Sides[side_count++]=1;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y))//sideno is for rectangle r
				   {///found here
					   RectEdge[valid].r_x1=InDem[r].ll_x;
						RectEdge[valid].r_y1=InDem[r].ll_y;
						RectEdge[valid].r_x2=InDem[r].ul_x;
						RectEdge[valid].r_y2=InDem[r].ul_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ul_x;
						RectEdge[valid].s_y1=InDem[s].ul_y;						
						RectEdge[valid].s_x2=InDem[s].ur_x;
						RectEdge[valid].s_y2=InDem[s].ur_y;
					   //find intersection point
						//computeInters_point(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
						valid++;
						//Sides updation
						Sides[side_count++]=4;//side of r
						Sides[side_count++]=1;//side of s
						Adj[r][s]=1;
				   }
				
				   
			  //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
			  //Case:second side of s			  
			  //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
			  
					
				   if(isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y))//side 1 of r
				   {
					   //one edge of source
					    RectEdge[valid].r_x1=InDem[r].ul_x;
						RectEdge[valid].r_y1=InDem[r].ul_y;
						RectEdge[valid].r_x2=InDem[r].ur_x;
						RectEdge[valid].r_y2=InDem[r].ur_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ur_x;
						RectEdge[valid].s_y1=InDem[s].ur_y;
						RectEdge[valid].s_x2=InDem[s].lr_x;
						RectEdge[valid].s_y2=InDem[s].lr_y;					
					   //find intersection point
						//computeInters_point(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
						valid++;
						//Sides updation
						Sides[side_count++]=1;//side of r
						Sides[side_count++]=2;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y))//side 2 of r
				   {
					   RectEdge[valid].r_x1=InDem[r].ur_x;
						RectEdge[valid].r_y1=InDem[r].ur_y;
						RectEdge[valid].r_x2=InDem[r].lr_x;
						RectEdge[valid].r_y2=InDem[r].lr_y;
					   //one edge of target
						RectEdge[valid].s_x1=InDem[s].ur_x;
						RectEdge[valid].s_y1=InDem[s].ur_y;
						RectEdge[valid].s_x2=InDem[s].lr_x;
						RectEdge[valid].s_y2=InDem[s].lr_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
						valid++;
						//Sides updation
						Sides[side_count++]=2;//side of r
						Sides[side_count++]=2;//side of s
						Adj[r][s]=1;
				   }
			   	   if(isIntersected(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y))
				   {//
					   RectEdge[valid].r_x1=InDem[r].lr_x;
						RectEdge[valid].r_y1=InDem[r].lr_y;
						RectEdge[valid].r_x2=InDem[r].ll_x;
						RectEdge[valid].r_y2=InDem[r].ll_y;
					   //one edge of target
						RectEdge[valid].s_x1=InDem[s].ur_x;
						RectEdge[valid].s_y1=InDem[s].ur_y;
						RectEdge[valid].s_x2=InDem[s].lr_x;
						RectEdge[valid].s_y2=InDem[s].lr_y;	
					   //find intersection point
						//computeInters_point(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
						valid++;
						//Sides updation
						Sides[side_count++]=3;//side of r
						Sides[side_count++]=2;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y))
				   {
					    RectEdge[valid].r_x1=InDem[r].ll_x;
						RectEdge[valid].r_y1=InDem[r].ll_y;
						RectEdge[valid].r_x2=InDem[r].ul_x;
						RectEdge[valid].r_y2=InDem[r].ul_y;
					   //one edge of target
						RectEdge[valid].s_x1=InDem[s].ur_x;
						RectEdge[valid].s_y1=InDem[s].ur_y;
						RectEdge[valid].s_x2=InDem[s].lr_x;
						RectEdge[valid].s_y2=InDem[s].lr_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
						valid++;
						//Sides updation
						Sides[side_count++]=4;//side of r
						Sides[side_count++]=2;//side of s
						Adj[r][s]=1;
				   }
			
			   
			  //Case:Third side of s			  
			  //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
			  
				  
				   if(isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y))
				   {
					   //one edge of source
					    RectEdge[valid].r_x1=InDem[r].ul_x;
						RectEdge[valid].r_y1=InDem[r].ul_y;
						RectEdge[valid].r_x2=InDem[r].ur_x;
						RectEdge[valid].r_y2=InDem[r].ur_y;
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].lr_x;
						RectEdge[valid].s_y1=InDem[s].lr_y;
						RectEdge[valid].s_x2=InDem[s].ll_x;
						RectEdge[valid].s_y2=InDem[s].ll_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
						valid++;
						//Sides updation
						Sides[side_count++]=1;//side of r
						Sides[side_count++]=3;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y))
				   {
					   //one edge of source
					     RectEdge[valid].r_x1=InDem[r].ur_x;
						RectEdge[valid].r_y1=InDem[r].ur_y;
						RectEdge[valid].r_x2=InDem[r].lr_x;
						RectEdge[valid].r_y2=InDem[r].lr_y;
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].lr_x;
						RectEdge[valid].s_y1=InDem[s].lr_y;
						RectEdge[valid].s_x2=InDem[s].ll_x;
						RectEdge[valid].s_y2=InDem[s].ll_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
						valid++;
						//Sides updation
						Sides[side_count++]=2;//side of r
						Sides[side_count++]=3;//side of s
						Adj[r][s]=1;
				   }
			   	  if(isIntersected(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y))
				   {
					   //one edge of source
					   RectEdge[valid].r_x1=InDem[r].lr_x;
						RectEdge[valid].r_y1=InDem[r].lr_y;
						RectEdge[valid].r_x2=InDem[r].ll_x;
						RectEdge[valid].r_y2=InDem[r].ll_y;
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].lr_x;
						RectEdge[valid].s_y1=InDem[s].lr_y;
						RectEdge[valid].s_x2=InDem[s].ll_x;
						RectEdge[valid].s_y2=InDem[s].ll_y	;
					   //find intersection point
						//computeInters_point(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
						valid++;
						//Sides updation
						Sides[side_count++]=3;//side of r
						Sides[side_count++]=3;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y))
				   { 
					   //one edge of source
					   RectEdge[valid].r_x1=InDem[r].ll_x;
						RectEdge[valid].r_y1=InDem[r].ll_y;
						RectEdge[valid].r_x2=InDem[r].ul_x;
						RectEdge[valid].r_y2=InDem[r].ul_y;
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].lr_x;
						RectEdge[valid].s_y1=InDem[s].lr_y;
						RectEdge[valid].s_x2=InDem[s].ll_x;
						RectEdge[valid].s_y2=InDem[s].ll_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
						valid++;
						//Sides updation
						Sides[side_count++]=4;//side of r
						Sides[side_count++]=3;//side of s
						Adj[r][s]=1;
				   }
			  
			  //Case:Fourth side of s
			   //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
			   
				  
				   if(isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y))
				   {
					    //one edge of source
					    RectEdge[valid].r_x1=InDem[r].ul_x;
						RectEdge[valid].r_y1=InDem[r].ul_y;
						RectEdge[valid].r_x2=InDem[r].ur_x;
						RectEdge[valid].r_y2=InDem[r].ur_y;
						//one edge of target
						RectEdge[valid].s_x1= InDem[s].ll_x;
						RectEdge[valid].s_y1=InDem[s].ll_y;
						RectEdge[valid].s_x2=InDem[s].ul_x;
						RectEdge[valid].s_y2=InDem[s].ul_y;
					   //find intersection point
						//computeInters_point(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,  InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
						valid++;
						//Sides updation
						Sides[side_count++]=1;//side of r
						Sides[side_count++]=4;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y))
				   {
					   //one edge of source
					     RectEdge[valid].r_x1=InDem[r].ur_x;
						RectEdge[valid].r_y1=InDem[r].ur_y;
						RectEdge[valid].r_x2=InDem[r].lr_x;
						RectEdge[valid].r_y2=InDem[r].lr_y;
						//one edge of target
						RectEdge[valid].s_x1= InDem[s].ll_x;
						RectEdge[valid].s_y1=InDem[s].ll_y;
						RectEdge[valid].s_x2=InDem[s].ul_x;
						RectEdge[valid].s_y2=InDem[s].ul_y;
					   //find intersection point
						//computeInters_point(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,  InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
						valid++;
						//Sides updation
						Sides[side_count++]=2;//side of r
						Sides[side_count++]=4;//side of s
						Adj[r][s]=1;
				   }
			   	  if(isIntersected(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y))
				   {
					    //one edge of source
					   RectEdge[valid].r_x1=InDem[r].lr_x;
						RectEdge[valid].r_y1=InDem[r].lr_y;
						RectEdge[valid].r_x2=InDem[r].ll_x;
						RectEdge[valid].r_y2=InDem[r].ll_y;
						//one edge of target
						RectEdge[valid].s_x1= InDem[s].ll_x;
						RectEdge[valid].s_y1=InDem[s].ll_y;
						RectEdge[valid].s_x2=InDem[s].ul_x;
						RectEdge[valid].s_y2=InDem[s].ul_y;
					   //find intersection point
						//computeInters_point(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y,  InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
						valid++;
						//Sides updation
						Sides[side_count++]=3;//side of r
						Sides[side_count++]=4;//side of s
						Adj[r][s]=1;
				   }
				  if(isIntersected(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y))
				   {
					   //one edge of source
					   RectEdge[valid].r_x1=InDem[r].ll_x;
						RectEdge[valid].r_y1=InDem[r].ll_y;
						RectEdge[valid].r_x2=InDem[r].ul_x;
						RectEdge[valid].r_y2=InDem[r].ul_y;
						//one edge of target
						RectEdge[valid].s_x1= InDem[s].ll_x;
						RectEdge[valid].s_y1=InDem[s].ll_y;
						RectEdge[valid].s_x2=InDem[s].ul_x;
						RectEdge[valid].s_y2=InDem[s].ul_y;
					   //find intersection point
						//computeInters_point(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
						valid++;
						//Sides updation
						Sides[side_count++]=4;//side of r
						Sides[side_count++]=4;//side of s
						Adj[r][s]=1;
				   }
			  
			   /*if(InDem[r].ul_x < InDem[s].ul_x  || InDem[r].lr_y > InDem[s].lr_y || InDem[r].ul_x > InDem[s].ul_x || InDem[r].lr_x < InDem[s].lr_x)
   					Adj[r][s]=0;

			   else
				   Adj[r][s]=1;*/

			   if(valid==2)
			   {//gather the edges and compute intersection and extents of overlap
					 //struct overlap_struct OverlapDEM;
					 //printf("\n%s\t%s\n",InDem[r].in_file,InDem[s].in_file);
					 double dx=0.0,dy=0.0,c1=0.0,m1=0.0,c2=0.0,m2=0.0,tempc1=0.0,tempc2=0.0,tempm1=0.0,tempm2=0.0;
					 double **inter1,**inter2;

					 int g=0;
					 min_x=99999999.0;
					 max_x=-99999999.0;
					 min_y=99999999.0;
					 max_y=-99999999.0;
					 inter1=(double **)malloc(sizeof(double*)*2);
					  inter2=(double **)malloc(sizeof(double*)*2);
					 //h=(signed short int **)malloc(sizeof(signed short int *)*Xmx);
					
					for(int t=0;t<2;t++)
					{
						//n[i]=(signed short int *)malloc(sizeof(signed short int)*Ymx);
						inter1[t]=(double *)malloc(sizeof(double)*2);
						inter2[t]=(double *)malloc(sizeof(double)*2);
					}
					RectEdge[0].src_imageno=r;
					RectEdge[0].trg_imageno=s;
					RectEdge[1].src_imageno=r;
					RectEdge[1].trg_imageno=s;
					// struct overlap_struct OverlapDEM;
					 //OverlapDEM=(struct overlap_struct *)malloc(sizeof(struct overlap_struct));
					 for(g=0;g<valid;g++)
					 {

						 
						  //Intersection
						/* printf("***********SOURCE****************\n");
						

						printf("RectEdge[%d].r_x1=%f\n",g,RectEdge[g].r_x1);

						 printf("RectEdge[%d].r_y1=%f\n",g,RectEdge[g].r_y1);

						 
						printf("RectEdge[%d].r_x2=%f\n",g,RectEdge[g].r_x2);
						printf("RectEdge[%d].r_y2=%f\n",g,RectEdge[g].r_y2);
						printf("***********Target****************\n");
						printf("RectEdge[%d].s_x1=%f\n",g,RectEdge[g].s_x1);
						
						 printf("RectEdge[%d].s_y1=%f\n",g,RectEdge[g].s_y1);
						 

						printf("RectEdge[%d].s_x2=%f\n",g,RectEdge[g].s_x2);
						printf("RectEdge[%d].s_y2=%f\n",g,RectEdge[g].s_y2);
						
						*/
						if(RectEdge[g].r_y2==RectEdge[g].r_y1)
						 {
							 inter1[g][1]=RectEdge[g].r_y1;
						 }

						 if(RectEdge[g].s_y2==RectEdge[g].s_y1)
						 {
							 inter1[g][1]=RectEdge[g].s_y1;
						 }
						 if(RectEdge[g].r_x2==RectEdge[g].r_x1)
						 {
							 inter1[g][0]=RectEdge[g].r_x1;
						 }
						 if(RectEdge[g].s_x2==RectEdge[g].s_x1)
						 {
							 inter1[g][0]=RectEdge[g].s_x1;
						 }

											
						
					 }
					//In addition to intersection points,Common points computation to form a polygon has TWO cases;
					 //e.g., r2-->s1;r2-->s3,(side r2 is common), 
								//then common points are points of Inclusion(s1,s3) in Polygon R
					 //e.g., r2-->s1;r3-->s4, (All are distinct sides),
								//then common points are A=Intersection{r2,r3};B={s1,s4}
					 int_count=0;
					 semi_count=0;
					 if(Sides[0]==Sides[2])
					 {//check points of sides of Polygon S(s1,s3) in polygon R
						 //doIntersect()//internal count
						 for(int h=0;h<2;h++)
						 {
							 int_count=0;
							 if(doIntersect(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,RectEdge[h].s_x1,RectEdge[h].s_y1,9999999.0,RectEdge[h].s_y1))
							 int_count++;
							 if(doIntersect(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,RectEdge[h].s_x1,RectEdge[h].s_y1,9999999.0,RectEdge[h].s_y1))
								 int_count++;
							if(doIntersect(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y,RectEdge[h].s_x1,RectEdge[h].s_y1,9999999.0,RectEdge[h].s_y1))
								 int_count++;
							if(doIntersect(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,RectEdge[h].s_x1,RectEdge[h].s_y1,9999999.0,RectEdge[h].s_y1))
								 int_count++;
							if(int_count%2==1)
							{

								inter2[semi_count][0]=RectEdge[h].s_x1;
								inter2[semi_count][1]=RectEdge[h].s_y1;
								semi_count++;
							}
						 }

						 for(int h=0;h<2;h++)
						 {
							 int_count=0;
							 if(doIntersect(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,RectEdge[h].s_x2,RectEdge[h].s_y2,9999999.0,RectEdge[h].s_y2))
							 int_count++;
							 if(doIntersect(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,RectEdge[h].s_x2,RectEdge[h].s_y2,9999999.0,RectEdge[h].s_y2))
								 int_count++;
							if(doIntersect(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y,RectEdge[h].s_x2,RectEdge[h].s_y2,9999999.0,RectEdge[h].s_y2))
								 int_count++;
							if(doIntersect(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,RectEdge[h].s_x2,RectEdge[h].s_y2,9999999.0,RectEdge[h].s_y2))
								 int_count++;
							if(int_count%2==1)
							{

								inter2[semi_count][0]=RectEdge[h].s_x2;
								inter2[semi_count][1]=RectEdge[h].s_y2;
								semi_count++;
							}
						 }
						

						 					
					 }
					 else if (Sides[1]==Sides[3])
					 {//check points of sides of Polygon R in Ploygon S
						 
						 
						for(int h=0;h<2;h++)
						 {
							 int_count=0;
							 if(doIntersect(InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y,RectEdge[h].r_x1,RectEdge[h].r_y1,9999999.0,RectEdge[h].r_y1))
							 int_count++;
							 if(doIntersect(InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y,RectEdge[h].r_x1,RectEdge[h].r_y1,9999999.0,RectEdge[h].r_y1))
								 int_count++;
							if(doIntersect(InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y,RectEdge[h].r_x1,RectEdge[h].r_y1,9999999.0,RectEdge[h].r_y1))
								 int_count++;
							if(doIntersect(InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y,RectEdge[h].r_x1,RectEdge[h].r_y1,9999999.0,RectEdge[h].r_y1))
								 int_count++;
							if(int_count%2==1)
							{

								inter2[semi_count][0]=RectEdge[h].r_x1;
								inter2[semi_count][1]=RectEdge[h].r_y1;
								semi_count++;
							}
						 }

						 for(int h=0;h<2;h++)
						 {
							 int_count=0;
							 if(doIntersect(InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y,RectEdge[h].r_x2,RectEdge[h].r_y2,9999999.0,RectEdge[h].r_y2))
							 int_count++;
							 if(doIntersect(InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y,RectEdge[h].r_x2,RectEdge[h].r_y2,9999999.0,RectEdge[h].r_y2))
								 int_count++;
							if(doIntersect(InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y,RectEdge[h].r_x2,RectEdge[h].r_y2,9999999.0,RectEdge[h].r_y2))
								 int_count++;
							if(doIntersect(InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y,RectEdge[h].r_x2,RectEdge[h].r_y2,9999999.0,RectEdge[h].r_y2))
								 int_count++;
							if(int_count%2==1)
							{

								inter2[semi_count][0]=RectEdge[h].r_x2;
								inter2[semi_count][1]=RectEdge[h].r_y2;
								semi_count++;
							}
						 }		
					 }
					 else
					 {
						 g=0;
						 if(RectEdge[g].r_x1==RectEdge[g+1].r_x1) 
						 {
							 if(RectEdge[g].r_y1==RectEdge[g+1].r_y1) 
							 {
								 inter2[0][0]=RectEdge[g].r_x1;
								 inter2[0][1]=RectEdge[g].r_y1;

							 }
						 }
						 if(RectEdge[g].r_x1==RectEdge[g+1].r_x2)
						 {
							 if(RectEdge[g].r_y1==RectEdge[g+1].r_y2) 
							 {
								 inter2[0][0]=RectEdge[g].r_x1;
								 inter2[0][1]=RectEdge[g].r_y1;

							 }
						 }
						 if(RectEdge[g].r_x2==RectEdge[g+1].r_x1) 
						 {
							 if(RectEdge[g].r_y2==RectEdge[g+1].r_y1) 
							 {
								 inter2[0][0]=RectEdge[g].r_x2;
								 inter2[0][1]=RectEdge[g].r_y2;

							 }
						 }
						 if(RectEdge[g].r_x2==RectEdge[g+1].r_x2)
						 {
							 if(RectEdge[g].r_y2==RectEdge[g+1].r_y2) 
							 {
								 inter2[0][0]=RectEdge[g].r_x2;
								 inter2[0][1]=RectEdge[g].r_y2;

							 }
						 }
						  if(RectEdge[g].s_x1==RectEdge[g+1].s_x1) 
						 {
							 if(RectEdge[g].s_y1==RectEdge[g+1].s_y1) 
							 {
								 inter2[1][0]=RectEdge[g].s_x1;
								 inter2[1][1]=RectEdge[g].s_y1;

							 }
						 }
						 if(RectEdge[g].s_x1==RectEdge[g+1].s_x2)
						 {
							 if(RectEdge[g].s_y1==RectEdge[g+1].s_y2) 
							 {
								 inter2[1][0]=RectEdge[g].s_x1;
								 inter2[1][1]=RectEdge[g].s_y1;

							 }
						 }
						 if(RectEdge[g].s_x2==RectEdge[g+1].s_x1) 
						 {
							 if(RectEdge[g].s_y2==RectEdge[g+1].s_y1) 
							 {
								 inter2[1][0]=RectEdge[g].s_x2;
								 inter2[1][1]=RectEdge[g].s_y2;

							 }
						 }
						 
						 if(RectEdge[g].s_x2==RectEdge[g+1].s_x2)
						 {
							 if(RectEdge[g].s_y2==RectEdge[g+1].s_y2) 
							 {
								 inter2[1][0]=RectEdge[g].s_x2;
								 inter2[1][1]=RectEdge[g].s_y2;

							 }
						 }
					 }
					 
					/* printf("A=(%f,%f)\n",inter2[0][0],inter2[0][1]);

					 printf("B=(%f,%f)\n",inter2[1][0],inter2[1][1]);


*/
					 //Finding out Overlapped region and its UL,UR,LR,LL

					for(int w=0;w<2;w++)
					{
						if(min_x >= inter1[w][0])
							min_x=inter1[w][0];
						if(min_x >= inter2[w][0])
							min_x=inter2[w][0];
						if(min_y >= inter1[w][1])
							min_y=inter1[w][1];
						if(min_y >= inter2[w][1])
							min_y=inter2[w][1];

						if(max_x <= inter1[w][0])
							max_x=inter1[w][0];
						if(max_x <= inter2[w][0])
							max_x=inter2[w][0];
						if(max_y <= inter1[w][1])
							max_y=inter1[w][1];
						if(max_y <= inter2[w][1])
							max_y=inter2[w][1];
					}
					//printf("********Overlap********\nUL=(%f,%f)\tUR=(%f,%f)\nLL=(%f,%f)\tLR=(%f,%f)\n",min_x,max_y,max_x,max_y,min_x,min_y,max_x,min_y);
					

					 
					/* if(min_x >= InDem[s].ul_x)

					   min_x=InDem[s].ul_x;
					if(min_y >= InDem[s].lr_y)
						min_y=InDem[s].lr_y;
					if(max_x <= InDem[s].lr_x)
						max_x=InDem[s].lr_x;
					if(max_y <= InDem[s].ul_y)
						max_y=InDem[s].ul_y;*/
					
					//printf("delyka=%.8f\n",InDem[0].dely);
					
					quad1_scans=(int)(((double)(max_y-min_y)/(double)yspace)+0.5);
					quad1_pixels=(int)(((double)(max_x-min_x)/(double)xspace)+0.5);
					
					
					
					////Pinning data
					/*
					sprintf(overlap,"%s%s%d%s%d.txt",infile,"\\overlapof",r,"with",s);

					if( (err  = fopen_s( &rrdfile,overlap, "w+" )) !=0 )
					{
						printf( "The input file: DEM Overplap analysis.txt was not opened\n");

						return -1;
					}
					fprintf(rrdfile,"xloc=%f\nyloc=%f\n",min_x,max_y);

					printf("file1:%s\tfile2:%s\n",InDem[RectEdge[0].src_imageno].in_file,InDem[RectEdge[0].trg_imageno].in_file);
*/
					//Newly added for src(st,endscan,pix) trg(st,endscan,pix)
					////////////////////////////////////////////////////////
					/*sprintf(overlap1,"%s%s%d%s%d.txt",infile,"\\overlap\\drroverlapof",r,"with",s);

					if( (err  = fopen_s( &rrdfile1,overlap1, "w+" )) !=0 )

					{
						printf( "The input file: DEM Overplap analysisdrr.txt was not opened\n");
						return -1;
					}
					fprintf(rrdfile1,"xloc=%f\nyloc=%f\n",min_x,max_y);
					*/
					/*InDem[RectEdge[0].src_imageno].used=true;
					InDem[RectEdge[0].trg_imageno].used=true;*/
					Oinfo[intersect_count].src_demno=RectEdge[0].src_imageno;
					Oinfo[intersect_count].trg_demno=RectEdge[0].trg_imageno;	
					//min_x,max_y,max_x,max_y,min_x,min_y,max_x,min_y);
					Oinfo[intersect_count].ul_x=min_x;
					Oinfo[intersect_count].ul_y=max_y;
					Oinfo[intersect_count].ur_x=max_x;
					Oinfo[intersect_count].ur_y=max_y;
					Oinfo[intersect_count].lr_x=max_x;
					Oinfo[intersect_count].lr_y=min_y;
					Oinfo[intersect_count].ll_x=min_x;
					Oinfo[intersect_count].ll_y=min_y;

					

					
					Oinfo[intersect_count].src_st_scan=(int)(((double)(InDem[RectEdge[0].src_imageno].ul_y-Oinfo[intersect_count].ul_y)/(double)InDem[RectEdge[0].src_imageno].dely)+0.5);					
					Oinfo[intersect_count].src_st_pixel=(int)(((double)(Oinfo[intersect_count].ul_x-InDem[RectEdge[0].src_imageno].ul_x)/(double)InDem[RectEdge[0].src_imageno].delx)+0.5);					
					Oinfo[intersect_count].src_end_scan=(int)(((double)(InDem[RectEdge[0].src_imageno].ul_y-Oinfo[intersect_count].ll_y)/(double)InDem[RectEdge[0].src_imageno].dely)+0.5);
					Oinfo[intersect_count].src_end_pixel=(int)(((double)(Oinfo[intersect_count].lr_x-InDem[RectEdge[0].src_imageno].ul_x)/(double)InDem[RectEdge[0].src_imageno].delx)+0.5);
					//Oinfo[intersect_count].src_end_scan=Oinfo[intersect_count].src_st_scan+(int)((double)(Oinfo[intersect_count].ul_y-Oinfo[intersect_count].ll_y)/(double)InDem[RectEdge[0].src_imageno].dely);
					//Oinfo[intersect_count].src_end_pixel=Oinfo[intersect_count].src_st_pixel+(int)((double)(Oinfo[intersect_count].lr_x-Oinfo[intersect_count].ll_x)/(double)InDem[RectEdge[0].src_imageno].delx);
					
					Oinfo[intersect_count].trg_st_scan=(int)(((double)(InDem[RectEdge[0].trg_imageno].ul_y-Oinfo[intersect_count].ul_y)/(double)InDem[RectEdge[0].trg_imageno].dely)+0.5);					
					Oinfo[intersect_count].trg_st_pixel=(int)(((double)(Oinfo[intersect_count].ul_x-InDem[RectEdge[0].trg_imageno].ul_x)/(double)InDem[RectEdge[0].trg_imageno].delx)+0.5);					
					Oinfo[intersect_count].trg_end_scan=(int)(((double)(InDem[RectEdge[0].trg_imageno].ul_y-Oinfo[intersect_count].ll_y)/(double)InDem[RectEdge[0].trg_imageno].dely)+0.5);
					Oinfo[intersect_count].trg_end_pixel=(int)(((double)(Oinfo[intersect_count].lr_x-InDem[RectEdge[0].trg_imageno].ul_x)/(double)InDem[RectEdge[0].trg_imageno].delx)+0.5);

					
					Oinfo[intersect_count].output_st_scan=(int)(((double)(output_maxy-Oinfo[intersect_count].ul_y)/(double)yspace)+0.5);					
					Oinfo[intersect_count].output_st_pixel=(int)(((double)(Oinfo[intersect_count].ul_x-output_minx)/(double)xspace)+0.5);					
					Oinfo[intersect_count].output_end_scan=(int)(((double)(output_maxy-Oinfo[intersect_count].ll_y)/(double)yspace)+0.5);
					Oinfo[intersect_count].output_end_pixel=(int)(((double)(Oinfo[intersect_count].lr_x-output_minx)/(double)xspace)+0.5);

					
					//array1_scans,array1_pixels,array2_scans,array2_pixels;
					array1_scans=(int)(((double)(Oinfo[intersect_count].ul_y-Oinfo[intersect_count].ll_y)/(double)yspace)+0.5);
					array1_pixels=(int)(((double)(Oinfo[intersect_count].lr_x-Oinfo[intersect_count].ul_x)/(double)xspace)+0.5);
					//These represent overlapped grid Extent in terms of no.of Scans & Pixels w.r.to Output Grid
//***************************************************************************************/
					//LEFT 2 RIGHT
//*************************************************************************************/
					   double pr1,qr1,t1;
					   int blscan,blpix,le_s_in,le_p_in,ri_s_in,ri_p_in;
					   	//printf("OverlappedRegion\nStScan=%d\tStPixel=%d\n",Oinfo[intersect_count].output_st_scan,Oinfo[intersect_count].output_st_pixel);
						//printf("********************\nUL=(%f,%f)\tUR=(%f,%f)\nLL=(%f,%f)\tLR=(%f,%f)\n",Oinfo[intersect_count].ul_x,Oinfo[intersect_count].ul_y,Oinfo[intersect_count].ur_x,Oinfo[intersect_count].ur_y,Oinfo[intersect_count].ll_x,Oinfo[intersect_count].ll_y,Oinfo[intersect_count].lr_x,Oinfo[intersect_count].lr_y);
								
						for(int pr=0;pr<array1_scans;pr++)
						{
							int flag1=0;
							A1StPix=-1;A1EndPix=-1,A2StPix=-1,A2EndPix=-1;

							for(int qr=0;qr<array1_pixels;qr++)
							{
								int blscan =Oinfo[intersect_count].output_st_scan+pr;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
								int blpix= Oinfo[intersect_count].output_st_pixel+qr;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
								
								double Out_lat1=output_maxy-((blscan)*yspace);//check by giving 0 inplace of r
								double Out_lon1=output_minx+((blpix)*xspace);
									
								le_s_in=(int)(((double)(InDem[r].ul_y-Out_lat1)/(double)yspace)+0.5);
								le_p_in=(int)(((double)(Out_lon1-InDem[r].ul_x)/(double)xspace)+0.5);

								ri_s_in=(int)(((double)(InDem[s].ul_y-Out_lat1)/(double)yspace)+0.5);
								ri_p_in=(int)(((double)(Out_lon1-InDem[s].ul_x)/(double)xspace)+0.5);
								
								//Whole_Image_Trans->Apply(pr,qr,pr1,qr1);
							    
								if(inarr1[r][le_s_in][le_p_in]!=0 && inarr1[s][ri_s_in][ri_p_in]!=0 &&flag1==0)
								{
									A1StPix=blpix;
									A2StPix=blpix;
									flag1=1;
								}
								if((inarr1[r][le_s_in][le_p_in]==0 || inarr1[s][ri_s_in][ri_p_in]==0) && flag1==1)
								{
									A1EndPix=blpix-1;
									A2EndPix=blpix-1;
									break;
									//flag=1;
								}							
							
							}
							
							//Handle for each scan at a time
							if(A1StPix!=-1 && A1EndPix!=-1 )
							{
								for(int t=A1StPix;t<=A1EndPix;t++)
								{
									int blscan =Oinfo[intersect_count].output_st_scan+pr;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
									int blpix= t;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
								
									//double Out_lat1=output_maxy-((blscan)*InDem[0].dely);//check by giving 0 inplace of r
									//double Out_lon1=output_minx+((blpix)*InDem[0].delx);
									//
									//le_s_in=(int)((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely);
									//le_p_in=(int)((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx);

									//ri_s_in=(int)((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely);
									//ri_p_in=(int)((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx);
								    double Out_lat1=output_maxy-((blscan)*yspace);//check by giving 0 inplace of r
									double Out_lon1=output_minx+((blpix)*xspace);
									
									le_s_in=(int)(((double)(InDem[r].ul_y-Out_lat1)/(double)yspace)+0.5);
									le_p_in=(int)(((double)(Out_lon1-InDem[r].ul_x)/(double)xspace)+0.5);

									ri_s_in=(int)(((double)(InDem[s].ul_y-Out_lat1)/(double)yspace)+0.5);
									ri_p_in=(int)(((double)(Out_lon1-InDem[s].ul_x)/(double)xspace)+0.5);
									Alpha=(float)(t-A1StPix)/(A1EndPix-A1StPix);
									//Whole_Image_Trans->Apply(le_s_in,t,pr1,t1);
									pr1=ri_s_in;
									t1=ri_p_in;
									if(outarr[blscan][blpix]==0)
										outarr[blscan][blpix]=(int)((double)(inarr1[r][le_s_in][le_p_in]*Alpha)+(double)(inarr1[s][(int)pr1][(int)t1]*(1-Alpha)));
											//outarr[blscan][blpix]=(int)((double)(Array1[pr][t]*Alpha)+(double)(Array2[(int)pr1][(int)t1]*(1-Alpha)));
									else
											outarr[blscan][blpix]=(int)(outarr[blscan][blpix]+(int)((double)(inarr1[r][le_s_in][le_p_in]*Alpha)+(double)(inarr1[s][(int)pr1][(int)t1]*(1-Alpha))))/2.0;
								}
							}	
						}
					

					intersect_count++;					
				
					delete (inter1);
					delete (inter2);				
					delete (Array1);				
					delete (Array2);
					
			}//if(valid==2)
		
		
		
		}
	  	   
	   delete (Sides);
	   delete (RectEdge);
	  
	   //printf("OK\n");
	   //getchar();
	   }
	  
	   //fclose(fqual);
	   
		int a1=0,s_out=0,p_out=0,s_in=0,p_in=0,pr=0,qr=0,k1,l1;
		double Out_lat,Out_lon;
		//Out-of-overlapped region filling		
//As inarr1 values are assigned to outgrid, loop as per inarr1(available scan pix only)	
		//This is declaration section for CC interpolation
	signed short int Ht_val=0,Right_Ht=0;
	double X_Residual=0.0,Y_Residual=0.0;
	bool Bil_Flag=false;
	signed short int **cc_adj;
	cc_adj=(signed short int **)malloc(sizeof(signed short int *)*2);
	for(pr=0;pr<2;pr++)
		cc_adj[pr]=(signed short int *)malloc(sizeof(signed short int)*2);	
	for(pr=0;pr<2;pr++)	
		for(qr=0;qr<2;qr++)
			cc_adj[pr][qr]=NoDataVal;
	//EOF CC initialization	
		for(a1=0;a1<fno;a1++)
		{
			//printf("For %s\n",InDem[a1].in_file);
			for(s_out=out_address1[a1][0];s_out<=out_address1[a1][2];s_out++)


			{	
				for(p_out=out_address1[a1][1];p_out<=out_address1[a1][3];p_out++)


				{	
					Bil_Flag=false;
					Out_lat=output_maxy-(s_out*yspace);
					Out_lon=output_minx+(p_out*xspace);					

					//s_in=(int)((double)(InDem[a1].ul_y-Out_lat)/(double)InDem[a1].dely);
					//p_in=(int)((double)(Out_lon-InDem[a1].ul_x)/(double)InDem[a1].delx);
					//For CC
					X_Residual=((double)(Out_lon-InDem[a1].ul_x)/(double)InDem[a1].delx);
					Y_Residual=((double)(InDem[a1].ul_y-Out_lat)/(double)InDem[a1].dely);
					s_in=(int)Y_Residual;
					p_in=(int)X_Residual;					

					if(s_in >= 0 && s_in+1 <= InDem[a1].rows-1 && p_in >= 0 && p_in+1 <= InDem[a1].cols-1)
					{
						for(k1=0;k1<=1;k1++)
						{
							for(l1=0;l1<=1;l1++)
							{	
								//printf("kval=%d\tl val=%d\n",k1,l1);
								cc_adj[k1][l1]=inarr1[a1][s_in+k1][p_in+l1];
								if(cc_adj[k1][l1]==NoDataVal && Bil_Flag==false)
								{
									Bil_Flag=true;
									k1=2;
									break;
								}
							}
						}	
						if(Bil_Flag==true)
						{
							s_in=(int)((double)(InDem[a1].ul_y-Out_lat)/(double)InDem[a1].dely);
							p_in=(int)((double)(Out_lon-InDem[a1].ul_x)/(double)InDem[a1].delx);
							if(s_in < InDem[a1].rows && p_in < InDem[a1].cols)
								Ht_val=inarr1[a1][s_in][p_in];
						}
						else
						{
							Ht_val=Bilinear(X_Residual,Y_Residual,cc_adj);
						}
						
						//Left_Ht=cubic_conv(X_Residual,Y_Residual,cc_adj);
					}
					else
					{
						s_in=(int)((double)(InDem[a1].ul_y-Out_lat)/(double)InDem[a1].dely);
						p_in=(int)((double)(Out_lon-InDem[a1].ul_x)/(double)InDem[a1].delx);
						if(s_in < InDem[a1].rows && p_in < InDem[a1].cols)
							Ht_val=inarr1[a1][s_in][p_in];
					}			
							
					//EOF CC

					if(outarr[s_out][p_out]==NoDataVal)
						outarr[s_out][p_out]=Ht_val;//inarr1[a1][s_in][p_in];			
					
				}
			}
			
		}
		
		int zeroflag=1;
		int windowsize=151;
		if(zeroflag==1)
		{
			int comp_val;
			//printf("zero filling..\n");
			for(i=(windowsize/2);i<=(output_scans-((windowsize/2)+1));i++)
			{		
				for(j=(windowsize/2);j<=(output_pixels-((windowsize/2)+1));j++)
				{
					count=0;
					comp_val=0;
					if(outarr[i][j]==0)
					{
						for(k=-(windowsize/2);k<=(windowsize/2);k++)
						{
							for(l=-(windowsize/2);l<=(windowsize/2);l++)
							{
									if(outarr[i+k][j+l]!=0)
									{
										comp_val+=outarr[i+k][j+l];
										count++;									
									}
							}
						}
						if(count>4)
							outarr[i][j]=comp_val/count;
					
					}
				}

			}
		

		}
		//EOF Out-of-overlapped region filling
		strcpy(outfile,"");
		/*strcpy(overlap,"");
		strcpy(overlap1,"");*/
		sprintf(outfile,"%s%s.DEM",outfolder,"_full_conv");
	   KT_HEAD* head = new KT_HEAD;
		head->initialization();
		head->getheader(InDem[0].in_file);
		
		head->addheader(outfile);//adding AIPS header to outfile 
							
		head->setvalues(KD_SCANS, &output_scans, KD_PIXELS, &output_pixels, KD_COORD_SCAN_LAT, &output_corner_details, NULL);
		head->replaceheader(outfile);
					
		delete head;
		
		if( (err  = fopen_s( &foutput, outfile, "ab" )) !=0 )
		{
			printf( "The output file: %s was not opened\n",outfile);
			return -1;
		}


		//int zeroflag=1,windowsize=11;
		zeroflag=1;
		windowsize=11;
		if(zeroflag==1)
		{
			int comp_val;
			//printf("zero filling..\n");
			for(i=(windowsize/2);i<=(output_scans-((windowsize/2)+1));i++)
			{		
				for(j=(windowsize/2);j<=(output_pixels-((windowsize/2)+1));j++)
				{
					count=0;
					comp_val=0;
					if(outarr[i][j]==0)
					{
						for(k=-(windowsize/2);k<=(windowsize/2);k++)
						{
							for(l=-(windowsize/2);l<=(windowsize/2);l++)
							{
									if(outarr[i+k][j+l]!=0)
									{
										comp_val+=outarr[i+k][j+l];
										count++;									
									}
							}
						}
						if(count>4)
							outarr[i][j]=comp_val/count;
					
					}
				}

			}
		

		}
		for(int r1=0;r1<output_scans;r1++)
		{
			fwrite(outarr[r1], sizeof(signed short int),output_pixels, foutput);
		}		
		fclose(foutput);
			//Cutting
		char*ptr=strstr(outfolder, "_E");
		char s[5];
		ptr += 2;
		strncpy(s, ptr, 2);
		s[2]='\0';
		int e = atof(s);

		ptr +=4;
		strncpy(s, ptr, 2);
		s[2]='\0';
		int nn = atof(s);

			stringstream corner;	
		corner << e << " ";
		corner << Math::Round(nn+1.0) << " ";
		corner << Math::Round(e+1.0) << " ";
		corner << nn << " ";
		string arg;
		string exe = "gdal_translate.exe";
		arg = "-of AIPS ";
		if(NoData==0)
			arg += "-a_nodata 0";
		else
			arg += "-a_nodata 55537";
		//arg += NoData.str();
		arg += " -a_ullr ";
		arg += corner.str();
		arg += " -projwin ";
		arg += corner.str() + " ";
		arg += outfile;
		arg += " ";
		arg += outfolder;
		arg += ".DEM";
		
		
		//arg += ".DEM";
		/*arg += infile;
		arg += "\\DEMMosa.DEM";
		arg += " ";
		arg += infile;
		arg += "\\";

		arg += MyVect.at(x).data();
		arg += ".DEM";*/
		CString cmd;
		cmd.Format("%s %s",exe.c_str(), arg.c_str());
		STARTUPINFO stat;
		PROCESS_INFORMATION process;

		ZeroMemory( &stat, sizeof(stat) );
		stat.cb = sizeof(stat);
		ZeroMemory( &process, sizeof(process) );

		int pret=CreateProcess((char*)exe.c_str(),(char*)cmd.operator LPCTSTR(),NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&stat,&process);
		WaitForSingleObject(process.hProcess,INFINITE);
		CloseHandle( process.hProcess );
		CloseHandle( process.hThread );
		//Updating mode 2 to 8 in AIPS HEADER
		strcpy(overlap1,"");
		sprintf(overlap1,"%s",outfile);
			
		head = new KT_HEAD;
		head->initialization();
		head->getheader(overlap1);
		
		//head->addheader(outfile);//adding AIPS header to outfile 
		char mod1='8';
			
		head->setvalues(KD_MODE,&mod1, NULL);
		head->replaceheader(overlap1);
					
		delete head;
		//writing the final output
			
			
		string arg1;
		//string outfile1=outfile
		string exe1 = "gdal_translate.exe";
		arg1 = "-of GTIFF ";			
		arg1 += outfolder;
		arg1 += ".DEM";		
		arg1 += " ";
		arg1 += outfolder;
		arg1 += "_Conventional.tif";	
		/*arg += infile;
		arg += "\\DEMMosa.DEM";
		arg += " ";

		arg += infile;
		arg += "\\";

		arg += MyVect.at(x).data();

		arg += ".DEM";*/
		//CString cmd;
		cmd.Format("%s %s",exe1.c_str(), arg1.c_str());
		//STARTUPINFO stat;
		//PROCESS_INFORMATION process;

		ZeroMemory( &stat, sizeof(stat) );
		stat.cb = sizeof(stat);
		ZeroMemory( &process, sizeof(process) );

		pret=CreateProcess((char*)exe.c_str(),(char*)cmd.operator LPCTSTR(),NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&stat,&process);
		WaitForSingleObject(process.hProcess,INFINITE);
		CloseHandle( process.hProcess );
		CloseHandle( process.hThread );
		printf("Mosaic process has been completed.\nDEM mosaic output is saved in %s_Conventional.tif\n",outfolder);
		
		for(int x=2;x<MyVect.size();x++)
		{
			strcpy(outfolder,"");
			strcpy(outfolder,tmp3);
			strcat(outfolder,"\\");	  		
			//strcat(outfile,MyVect.at(x).data());
			string _dir = outfolder;	   
			strFolder = _dir.data();	
			strFolder += "\\*.DEM";
			bfnd = fnd.FindFile(strFolder);
			AllDEMfiles.clear();
			while(bfnd)
			{
				bfnd = fnd.FindNextFile();		  
				CString f=fnd.GetFilePath();
				tmp=f.operator LPCSTR();	

				AllDEMfiles.push_back((char *)f.operator LPCSTR());
			}
		
		}
		Delete_TempFiles(AllDEMfiles);
		AllDEMfiles.clear();
		//fclose(foutput);
		
	   printf("FINISHED........\n");
	  /* for(int i=0;i<fno;i++)
		{
			free(in_address1[i]);

		}*/
		delete (in_address1);
		/*for(int i=0;i<fno;i++)
		{

			free(out_address1[i]);
		}*/
		delete (out_address1);
		/*for(int i=0;i<fno;i++)
		{
			free(Adj[i]);
		}*/
		delete (Adj);
	  /* for(int i=0;i<fno;i++)
		{
			lines=InDem[i].rows;

			pixels=InDem[i].cols;
			for(int j=0;j<lines;j++)
			{				
				free(inarr1[i][j]);

			}

			free(inarr1[i]);
		}*/
		delete (inarr1);
		/*for(int i=0;i<output_scans;i++)
		{
			free(outarr[i]);

		}*/
		delete (outarr);		

		delete (InDem);
		delete (Oinfo);


	   
	   
	   //free(InDem);
return 0;
}

int MyDEMFilter::Mosaic_Proposed(char infile[300],char outfile[300])
{	
		
	//Start
	struct Orbit
	{
		int OrbitNo;
		int path; 
		int row;
		int yyyy;
		int mm;
		int dd;
		string filename;
		int Orbits;//total orbits
		//Orbit(int OrbitNo1,int path1,int row1,int yyyy1,int mm1,int dd1,string filename1):OrbitNo(OrbitNo1),path(path1),row(row1),yyyy(yyyy1),mm(mm1),dd(dd1),filename(filename1){}
		
	};
	
	CFileFind fnd;
	BOOL bfnd;
	CString strFolder;
	string tmp="";
	char tmp1[100],tmp2[100],tmp3[300];
	double time1,time2;
	WIN32_FIND_DATA FindFileData;
	HANDLE hFind;
	string sPath;
	vector<string> MyVect;
	strcpy(tmp3,outfile);
	strcpy(tmp2,infile);
	strcpy(tmp1,"");
	strcat(tmp1,infile);
	strcat(tmp1,"\\*");
	sPath.assign(tmp1);
	hFind=FindFirstFile(sPath.data(),&FindFileData);
	do
	{
		if(FindFileData.dwFileAttributes==16)
		{
			MyVect.push_back(FindFileData.cFileName);
		}
	}while(FindNextFile(hFind,&FindFileData));

	vector<string> PATHVECTOR;
	vector<string> ORBITVECTOR;
	vector<string>::iterator Iter1;	
	vector<string>::iterator Iter2;	
	vector<string> AllDEMfiles;
	  
	//Converting to binary files
	for(int x=2;x<MyVect.size();x++)
	{
		strcpy(infile,"");
		strcpy(infile,tmp2);
		strcat(infile,"\\");	  		
		strcat(infile,MyVect.at(x).data());
		string _dir = infile;	   
		strFolder = _dir.data();	
		strFolder += "\\*.tif";
		bfnd = fnd.FindFile(strFolder);
		char*ptr=strstr(infile, "_E");
		char s[5];
		ptr += 2;
		strncpy(s, ptr, 2);
		s[2]='\0';
		int e = atof(s);

		ptr +=4;
		strncpy(s, ptr, 2);
		s[2]='\0';
		int nn = atof(s);
		/***************************************/
		printf("\t=========================================================================\n");
		printf("\tCreating mosaic of DEM scenes for an ROI of 1 degree x 1 degree \n\t\t(Lat:%d to %d; Lon:%d to %d(Decimal Degrees))\n",nn,nn+1,e,e+1);
		printf("\t=========================================================================\n");
		int fno1=0;
	    
		int distinct_paths=0;
		AllDEMfiles.clear();
		while(bfnd)
		{
			bfnd = fnd.FindNextFile();		  
			CString f=fnd.GetFilePath();
			tmp=f.operator LPCSTR();	
			//AllDEMfiles.push_back((char *)f.operator LPCSTR());
			string arg1;
			//string outfile1=outfile
			string exe1 = "Gtiff2Bin.exe";
			arg1 +=  (char *)f.operator LPCSTR();			
			CString cmd;
			cmd.Format("%s %s",exe1.c_str(), arg1.c_str());
			STARTUPINFO stat;
			PROCESS_INFORMATION process;

			ZeroMemory( &stat, sizeof(stat) );
			stat.cb = sizeof(stat);
			ZeroMemory( &process, sizeof(process) );

			int pret=CreateProcess((char*)exe1.c_str(),(char*)cmd.operator LPCTSTR(),NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&stat,&process);
			WaitForSingleObject(process.hProcess,INFINITE);
			CloseHandle( process.hProcess );
			CloseHandle( process.hThread );
			fno1++;
		}
	}
	
	for(int x=2;x<MyVect.size();x++)
	{
		time1=time(NULL);
		cout<<"\t\t\tTile Name:"<<MyVect.at(x).data()<<endl;
		   
		strcpy(infile,"");
		strcpy(infile,tmp2);
		strcat(infile,"\\");	  		
		strcat(infile,MyVect.at(x).data());
		string _dir = infile;	   
		strFolder = _dir.data();	
		strFolder += "\\*.Img";
		bfnd = fnd.FindFile(strFolder);
		char*ptr=strstr(infile, "_E");
		char s[5];
		ptr += 2;
		strncpy(s, ptr, 2);
		s[2]='\0';
		int e = atof(s);

		ptr +=4;
		strncpy(s, ptr, 2);
		s[2]='\0';
		int nn = atof(s);
		/***************************************/		
		int fno1=0;
	    
		int distinct_paths=0;
		AllDEMfiles.clear();
		while(bfnd)
		{
			bfnd = fnd.FindNextFile();		  
			CString f=fnd.GetFilePath();
			tmp=f.operator LPCSTR();	

			AllDEMfiles.push_back((char *)f.operator LPCSTR());
			char *temp=strrchr((char *)f.operator LPCSTR(),'\\');
			temp+=3;
			//cout<<temp<<endl;
			char orbi[6];			
			strncpy(orbi, temp, 6);
			orbi[6]='\0';

			char *temp_pathrow=strrchr(temp,'_');
			temp_pathrow++;
			char path[7];			
			strncpy(path, temp_pathrow, 3);
			path[3]='\0';
			
			if(!(std::find(ORBITVECTOR.begin(),ORBITVECTOR.end(),orbi)!=ORBITVECTOR.end()))
			{
				ORBITVECTOR.push_back(orbi);				
			}
			if(!(std::find(PATHVECTOR.begin(),PATHVECTOR.end(),path)!=PATHVECTOR.end()))
			{
				PATHVECTOR.push_back(path);				
			}
			
			fno1++;
		}	
		 //Sort the vector
		//std::stable_sort(ORBITVECTOR.begin(),ORBITVECTOR.end());
	   	/*for ( Iter2 = ORBITVECTOR.begin() ; Iter2 != ORBITVECTOR.end() ; Iter2++ )
			cout << *Iter2 << " ";*/
	   std::stable_sort(PATHVECTOR.begin(),PATHVECTOR.end());
	   	/*for ( Iter1 = PATHVECTOR.begin() ; Iter1 != PATHVECTOR.end() ; Iter1++ )
			cout << *Iter1 << " ";
		*/
		//Sort AllDEMfiles based on pathrow
	   std::stable_sort(AllDEMfiles.begin(),AllDEMfiles.end(),BasedonPathRow);
	   //this solves sequence problem

		vector<Orbit> DEM_Orbit_Info;

		//vector<vector<Orbit> > Path_DEMfiles;
		vector<vector<vector<Orbit> >> Path_DEMfiles_Final;
		vector<string>::iterator Iter_string;
		
		
		for (Iter_string = AllDEMfiles.begin() ; Iter_string != AllDEMfiles.end() ; Iter_string++ )
		{
			//cout<< *Iter_string<<endl;
			string t1=*Iter_string;
			const tr1::regex seperator("P5");
			const tr1::sregex_token_iterator endOfSeq;
			tr1::sregex_token_iterator token(t1.begin(), t1.end(), seperator, -1);			
			string tmp = (*token);						
				
			while(token != endOfSeq) 
			{
				tmp=(*token++);				
			}
				//cout<<tmp<<endl;
				Orbit Orbit1[1];
					
				//Orbit1=(struct Orbit *)malloc(sizeof(struct Orbit));
				string orb = (tmp).substr(0,6);	
				Orbit1[0].OrbitNo=atoi(orb.c_str());
				Orbit1[0].yyyy=atoi((tmp).substr(10,4).c_str());
				Orbit1[0].mm=atoi((tmp).substr(14,2).c_str());
				Orbit1[0].dd=atoi((tmp).substr(16,2).c_str());
				Orbit1[0].path=atoi((tmp).substr(19,3).c_str());
				Orbit1[0].row=atoi((tmp).substr(22,3).c_str());
				Orbit1[0].filename=t1;
				orb=(tmp).substr(19,3);
				DEM_Orbit_Info.push_back(Orbit1[0]);
				//string t2=*Iter1;
				//int  path1= atoi((t2).substr(0,3).c_str());
				////cout<<orb<<" "<<t2<<endl;
				//if(Orbit1[0].path==path1)
				//{
				//	cout<<"found"<<endl;
				//	DEM_Orbit_Info.push_back(Orbit1[0]);
				//	cout<<"size.. "<<DEM_Orbit_Info.size()<<endl;
				//	//Demname.push_back(*Iter_string);
				//}
					
		}
		vector<string> Pathwise_Final;
		vector<string> Pathwise_Final_temp;
		vector<Orbit>::iterator Iter_struct;
		vector<Orbit> DEM_Orbit_Info_temp;			
		vector<int> Orbit_Store;
			
		//Path Vs Noof Orbits;
		vector<string> Pathwise;
		vector<string> Path_Orbit_DEMfiles;//(PATHVECTOR.size(),vector<string> );
		vector<string> Demname;
		char med_file[300];
		cout<<"Sequence of Input DEM scenes for the mosaic process:"<<endl;
		//cout<<"Sequence of Input DEM scenes for the mosaic process (Convetnional feathering-based-blend method):"<<endl;
		cout<<"Doing vertical blending of the DEM scenes belong to:"<<endl;
		for (Iter1 = PATHVECTOR.begin() ; Iter1 != PATHVECTOR.end() ; Iter1++)
		{
			string t2=*Iter1;
			int  path1= atoi((t2).c_str());
				
			for ( Iter_struct = DEM_Orbit_Info.begin() ; Iter_struct != DEM_Orbit_Info.end() ; Iter_struct++ )
			{	
				if(path1==Iter_struct->path)
				{
					if(!(std::find(Orbit_Store.begin(),Orbit_Store.end(),Iter_struct->OrbitNo)!=Orbit_Store.end()))
					{
						Orbit_Store.push_back(Iter_struct->OrbitNo);
						Demname.push_back(Iter_struct->filename);
					}					
				}	
			}	
			//recent
			//cout<<"For Path="<<path1<<"==> Orbits="<<Orbit_Store.size()<<endl;
			for(int ii=0;ii<Orbit_Store.size();ii++)
			{//To do
				//include logic if only one DEM is avalabale for an orbit in a given path(total Orbits=3)
				//cout<<endl<<"For Orbit Number="<<Orbit_Store[ii];
				for ( Iter_struct = DEM_Orbit_Info.begin() ; Iter_struct != DEM_Orbit_Info.end() ; Iter_struct++ )
				{
					if(Orbit_Store[ii]==Iter_struct->OrbitNo)
					{
						Path_Orbit_DEMfiles.push_back(Iter_struct->filename);
					}

				}
				//Start Mosaic
				//Added 2017
					
					sprintf(dummy,"%s%sPath%dOrbit%d.txt",outfile,"\\",path1,Orbit_Store[ii]);	
					if( (err  = fopen_s( &fdrr, dummy, "w+" )) !=0 )
					{
						printf( "The output file: %s was not opened\n",dummy);
						//return -1;
					}
				sprintf(med_file,"%s%sPath%dOrbit%d.DEM",outfile,"\\",path1,Orbit_Store[ii]);			
				cout<<"\tOrbit:"<<Orbit_Store[ii]<<" of Path number:"<<path1<<endl;
				Mosaic_process(Path_Orbit_DEMfiles,outfile,'V',med_file,0,nn,e);//,0);//0 is a flag indicates (Final if 1)
				Pathwise.push_back(med_file);
				fclose(fdrr);
				/*cout<<endl<<"*For Path="<<path1<<endl;
				for(int jj=0;jj<Path_Orbit_DEMfiles.size();jj++)
					cout<<endl<<"*Files are="<<Path_Orbit_DEMfiles[jj]<<endl;*/
				Path_Orbit_DEMfiles.clear();
			}

			//cout<<endl<<"================="<<endl;				
			Demname.clear();
			Orbit_Store.clear();
			
			//Hanlde Pathwise TWO at a time and formulate the sequence thru which MOSAIC has to perform
			Pathwise_Final_temp=Mosaic_TwoAtaTime(outfile,Pathwise,path1,0,"",nn,e);//,0);
			
			Pathwise_Final.push_back(Pathwise_Final_temp[0]);
			//EOF Hanlde Pathwise TWO at a time 
			
			/*for(int jj=0;jj<Pathwise.size();jj++)
					cout<<"Files are="<<Pathwise[jj]<<endl;*/
			//Delete_TempFiles(Pathwise);//April2019
			Pathwise.clear();
			//Pathwise_Phases.clear();
			
		}//EOF PATHVECTOR
		Delete_TempFiles(AllDEMfiles);
		cout<<"Horizontal blending between the Paths is in progress. Please wait...(It may take few minutes)"<<endl;
		
		//To handle Across Path Mosaic
		
		Mosaic_TwoAtaTime(outfile,Pathwise_Final,0,1,(char *)MyVect.at(x).data(),nn,e);//,zeroflag);				
		/*for(int jj=0;jj<Pathwise_Final.size();jj++)
				cout<<"Final files are="<<Pathwise_Final[jj]<<endl;*/
	//Delete_TempFiles(Pathwise_Final);//April2019
		Pathwise_Final.clear();
		ORBITVECTOR.clear();
		PATHVECTOR.clear();
		DEM_Orbit_Info.clear();
		time2=time(NULL);
		//printf("Time taken:%lf min\n",(time2-time1)/60.0);
	}
	for(int x=2;x<MyVect.size();x++)
	{
		strcpy(outfile,"");
		strcpy(outfile,tmp3);
		strcat(outfile,"\\");	  		
		//strcat(outfile,MyVect.at(x).data());
		string _dir = outfile;	   
		strFolder = _dir.data();	
		strFolder += "\\*.DEM";
		bfnd = fnd.FindFile(strFolder);
		AllDEMfiles.clear();
		while(bfnd)
		{
			bfnd = fnd.FindNextFile();		  
			CString f=fnd.GetFilePath();
			tmp=f.operator LPCSTR();	

			AllDEMfiles.push_back((char *)f.operator LPCSTR());
		}
		
	}
	Delete_TempFiles(AllDEMfiles);
	AllDEMfiles.clear();
	for(int x=2;x<MyVect.size();x++)
	{
		strcpy(outfile,"");
		strcpy(outfile,tmp3);
		strcat(outfile,"\\");	  		
		//strcat(infile,MyVect.at(x).data());
		string _dir = outfile;	   
		strFolder = _dir.data();	
		strFolder += "\\*.txt";
		bfnd = fnd.FindFile(strFolder);
		AllDEMfiles.clear();
		while(bfnd)
		{
			bfnd = fnd.FindNextFile();		  
			CString f=fnd.GetFilePath();
			tmp=f.operator LPCSTR();	

			AllDEMfiles.push_back((char *)f.operator LPCSTR());
		}
		
	}
	Delete_TempFiles(AllDEMfiles);
	AllDEMfiles.clear();
	return 0;
}


int MyDEMFilter::Mosaic_process(vector<string> Vec_Path,char infile[300],char HorV,char inter_file[300],int cut,int North,int East)//,int zeroflag)
{	

	
	   /**********************************************/
		   CFileFind fnd;
			BOOL bfnd;
			CString strFolder;
			string tmp="";
		struct edge
		{
			double r_x1;
			double r_y1;
			double r_x2;
			double r_y2;//source rect edge			

			double s_x1;
			double s_y1;
			double s_x2;
			double s_y2;//target rect edge
			int src_imageno; 
			int trg_imageno; 
		};
		
	 struct input_dem *InDem;
	 struct Overlap_Info *Oinfo;
	   signed short int **h,**n,**temp,**outarr,***inarr,VAL,*arrscan,***inarr1;//,**Array1,**Array2;
	   errno_t err;		
		FILE *fin,*foutput;
		FILE *rrdfile1,*rrdfile2,*fbound;//,*rrdfile,*fdrr,*fout,*f_adres,*fgrid,*rrdfile1,*fA1,*fA2,*fH,*fvA1;
		int count=0,i,j=0,k,l,fresult;
		signed short int NoData=NoDataVal;
		int nocount,Xmx,Ymx,Xmx1,Ymx1,min,max;
		int sideno=0,windowsize=3;
		char *buffer;
		char outfile[300],overlap[300],overlap1[300],overlap2[300],outfile1[300];//,A1file[300],A2file[300],Hmfile[300],ValidA1file[300];
		FILE *f1,*f2,*f20;			
		int m;		
		int blend_freq=0;
		signed int **samples;	
		long position,end;
		double UpperLeft_Lat,UpperLeft_Lon,LowerRight_Lat,LowerRight_Lon,LowerLeft_Lat,LowerLeft_Lon,UpperRight_Lat,UpperRight_Lon;
		
		int n2,n3,qualify_count=0;
		//qualify_count<=>file_count
		signed short int  **in_address1,**out_address1;
		double min_x,min_y,max_x,max_y,output_minx,output_maxx,output_miny,output_maxy;
		min_x=99999999.0;
		max_x=-99999999.0;
		min_y=99999999.0;
		max_y=-99999999.0;
		output_minx=99999999.0;
		output_maxx=-99999999.0;
		output_miny=99999999.0;
		output_maxy=-99999999.0;
		int quad1_scans,quad1_pixels,output_scans,output_pixels,lines,pixels,array1_scans,array1_pixels,array2_scans,array2_pixels;
		int fno=0,temp_count=0,ver=0,valid=0,int_count,semi_count,intersect_count;
		short **Adj;
		double xspace=0.0, yspace=0.0;
		//int lines, pixels;
		float resolution;
		char LorR='L';
		int rajss=0;
		//float Alpha=0.0,Hermite=0.0;
		short *Sides,side_count;//holds distinct sides of two polygons that are intersected in current session.
		//int A1StPix,A1EndPix,A2StPix,A2EndPix,A1StScan,A1EndScan,A2StScan,A2EndScan;
	   /*if( (err  = fopen_s( &fdrr, "F:\\DEMmosa\\OverlapValues.txt", "w+" )) !=0 )
		{
			printf( "The output file: %s was not opened\n","OverlapValues.txt");
			return -1;
		}*/
	   /*if( (err  = fopen_s( &fgrid, "G:\\rajesh\\bba_sort\\check\\grid.txt", "w+" )) !=0 )
		{
			printf( "The output file: %s was not opened\n","grid.txt");
			return -1;
		}
	  */
	    
		 //total_dems=fno;
	  // bfnd = fnd.FindFile(strFolder);
	if(Vec_Path.size()<2)
	{
		CString cmd;
		stringstream exe, arglist;			
		exe << "Copy";	
		//arglist << Vec_Path[0] << " "<<infile<< "\\DemMosa" << it<<".DEM";
		arglist << Vec_Path[0] << " "<<inter_file;
		
		cmd.Format("%s %s",exe.str().c_str(), arglist.str().c_str());		
		system(cmd.operator LPCSTR());
	}
	else
	{
		fno=Vec_Path.size();
		InDem=(struct input_dem *)malloc(sizeof(struct input_dem)*fno);//to track pos
		for(int v=0;v<fno;v++)
		{
			strcpy(InDem[v].in_file, "");
			InDem[v].rows=0;
		    InDem[v].cols=0;			
			InDem[v].ul_y=0.00;
		    InDem[v].ul_x=0.00;		
			InDem[v].ur_y=0.00;
		    InDem[v].ur_x=0.00;
			InDem[v].lr_y=0.00;
		    InDem[v].lr_x=0.00;			
			InDem[v].ll_y=0.00;
		    InDem[v].ll_x=0.00;			
			InDem[v].delx=0.00;
			InDem[v].dely=0.00;
			InDem[v].year=0;
			InDem[v].qualify=false;//Falling in OP Extent
			//InDem[v].used=false;
		}
	  
	   fno=0;
	  
	   for(int jj=0;jj<Vec_Path.size();jj++)
		{
		   //bfnd = fnd.FindNextFile();
		   //CString f=Vec_Path[jj];//fnd.GetFilePath();
		   char *tmp=(char *)(Vec_Path[jj]).c_str();
		   //InDem[fno].fname=(LPCTSTR)fnd.GetFileName();//f.operator LPCSTR();
		  
		   //Aips header info
		    KT_HEAD* head = new KT_HEAD;
			KT_coord_scan_pix corner_info;
			head->initialization();
			//head->getheader((char*) f.operator LPCSTR());
			head->getheader(tmp);
			
			head->getvalues(KD_SCANS, &lines, KD_PIXELS, &pixels,KD_N_RESOLUTION,&resolution, NULL);	
			head->getvalue(KD_COORD_SCAN_LAT,corner_info);
		
			LowerLeft_Lat=corner_info.coord[3][0];
			LowerLeft_Lon=corner_info.coord[3][1];
			UpperRight_Lat=corner_info.coord[1][0];
			UpperRight_Lon=corner_info.coord[1][1];
			UpperLeft_Lat=corner_info.coord[0][0];
			UpperLeft_Lon=corner_info.coord[0][1];
			LowerRight_Lat=corner_info.coord[2][0];
			LowerRight_Lon=corner_info.coord[2][1];		

			strcpy(InDem[fno].in_file, tmp);
			//InDem[fno].fname=f;
			InDem[fno].rows=lines;
		    InDem[fno].cols=pixels;			
			InDem[fno].ul_y=UpperLeft_Lat;
		    InDem[fno].ul_x=UpperLeft_Lon;

			InDem[fno].ur_y=UpperRight_Lat;
		    InDem[fno].ur_x=UpperRight_Lon;

			InDem[fno].lr_y=LowerRight_Lat;
		    InDem[fno].lr_x=LowerRight_Lon;

			InDem[fno].ll_y=LowerLeft_Lat;
		    InDem[fno].ll_x=LowerLeft_Lon;

			InDem[fno].delx=((double)(LowerRight_Lon-UpperLeft_Lon)/(double)(pixels-1));
			InDem[fno].dely=(double)(UpperLeft_Lat - LowerRight_Lat)/(double)(lines-1);
			InDem[fno].qualify=false;//Falling in OP Extent
			//InDem[v].used=false;
		   //end of Aips

			////Path Row Extraction
			//char *temp=strrchr((char *)f.operator LPCSTR(),'\\');
		 //   temp++;
			//cout<<temp<<endl;
			//char *temp_pathrow=strrchr(temp,'_');
		 //   temp_pathrow++;
			//char path[7];			
			//strncpy(path, temp_pathrow, 3);
			///*path[3]='\0';*/
			//InDem[fno].PathNo = atoi(path);
		 //   cout<<temp_pathrow<<endl;
			//temp_pathrow += 3;
			//strncpy(path, temp_pathrow, 3);
			//InDem[fno].RowNo=atoi(path);
			/*if(fno==0)
				PATHVECTOR.push_back(InDem[fno].PathNo);*/
			 //vector <int>::iterator Iter;
			
			
			//Year Extraction
			/*char*ptr1=strstr(InDem[fno].in_file, "_1P_");
			char s1[5];
			ptr1 += 4;
			strncpy(s1, ptr1, 4);
			s1[4]='\0';
			int e = atoi(s1);
			InDem[fno].year=e;*/
			//printf("\nfile[%d]=%s\n",fno,InDem[fno].in_file);
			if(resolution<0.0)
			{
				printf("This has Resolution:%f\nKindly correct and submit again.\nExiting....",resolution);
				return -1;
			}

		   /*printf("delx[%d]=%f\t",fno,InDem[fno].delx);
		   printf("dely[%d]=%f\n",fno,InDem[fno].dely);*/
		   fno++;
		   delete head;
	   }	

	   Vec_Path.clear();		
	  

	   inarr1=(signed short int ***)malloc(sizeof(signed short int **)*fno);
		//temp_count=0;
		for(int i=0;i<fno;i++)
		{
			/*if(InDem[i].qualify)
			{*/
			if( (err  = fopen_s( &fin, InDem[i].in_file, "rb" )) !=0 )
			{
				printf( "The input file: %s was not opened\n",InDem[i].in_file);
				return -1;
			}
				//fin=fopen(InDem[i].in_file,"rb");
				//printf("Reading arrays from the infile with %s-----   %d %d\n",InDem[i].in_file,InDem[i].rows,InDem[i].cols);//getchar();
				
				fresult=fseek(fin, 2048, SEEK_SET);   
				lines=InDem[i].rows;
				pixels=InDem[i].cols;
				inarr1[i]=(signed short int **)malloc(sizeof(signed short int *)*lines);	
				arrscan=(signed short int *)malloc(sizeof(signed short int)*pixels);
							
				for(int j=0;j<lines;j++)
				{ 					
					fread(arrscan,sizeof(signed short int),pixels,fin);
					inarr1[i][j]=(signed short int *)malloc(sizeof(signed short int )*pixels);
					for(int k=0;k<pixels;k++)
					{
						VAL= arrscan[k];
						inarr1[i][j][k]=VAL;
						//fread((char*)&inarr1[temp_count][j][k],  sizeof(signed short int),1, fin);
						
					}
					
					//printf("\n");
				}
				
				fclose(fin);
				free(arrscan);
				//printf("Dooing file -- %d  \n",i);
				//temp_count++;
			//}
			

		}
		
		
		//Output EXTENTS FINDING.....
		
		/*output_minx=e;
		output_maxx=e+1;
		output_miny=nn;
		output_maxy=nn+1;*/
		for(int r=0;r<fno;r++)
	   {
		   if(output_minx >= InDem[r].ul_x)
			   output_minx=InDem[r].ul_x;
			if(output_miny >= InDem[r].lr_y)
				output_miny=InDem[r].lr_y;
			if(output_maxx <= InDem[r].lr_x)
				output_maxx=InDem[r].lr_x;
			if(output_maxy <= InDem[r].ul_y)
				output_maxy=InDem[r].ul_y;
	   }   


	
	   
	   //Computes DelX and DelY spacing for Output(Mosaicked DEM)
	   Compute_Delxy( output_minx, output_maxx, output_miny,output_maxy,resolution, xspace, yspace);
	   output_scans=(int)(((double)(output_maxy-output_miny)/(double)yspace)+0.5);
	  
	   output_pixels=(int)(((double)(output_maxx-output_minx)/(double)xspace)+0.5);


	   output_scans+=1;
	   output_pixels+=1;
		/*f_adres=fopen("G:\\drr\\ZZNewIn_Outdimentionsdrr.txt","w+");

		fprintf(f_adres," Extents    are   quad1_minx=%lf\tquad1_maxx=%lf\tquad1_miny=%lf\tquad1_maxy=%lf\n",output_minx,output_maxx,output_miny,output_maxy);
		fprintf(f_adres,"out dimentions are quad1_scans= %d \tquad1_pixels= %d\n",output_scans,output_pixels);
		*/
		in_address1=(signed short int **)malloc(sizeof(signed short int *)*fno);
	   for(int p1=0;p1<fno;p1++)
		{
			//n[i]=(signed short int *)malloc(sizeof(signed short int)*Ymx);
			in_address1[p1]=(signed short int *)malloc(sizeof(signed short int)*4);

		}
	   out_address1=(signed short int **)malloc(sizeof(signed short int *)*fno);
	   for(int p=0;p<fno;p++)
		{
			//n[i]=(signed short int *)malloc(sizeof(signed short int)*Ymx);
			out_address1[p]=(signed short int *)malloc(sizeof(signed short int)*4);

		}
	   //temp_count=0;
	   //Tagging InputDEM extents to Output Grid Extent
		for(int i=0;i<fno;i++)
		{
			in_address1[i][0]=0;
			in_address1[i][1]=0;
			in_address1[i][2]=InDem[i].rows-1;
			in_address1[i][3]=InDem[i].cols-1;		
				
			out_address1[i][0]=(int)(((double)(output_maxy-InDem[i].ul_y)/(double)yspace)+0.5);
			out_address1[i][1]=(int)(((double)(InDem[i].ul_x-output_minx)/(double)xspace)+0.5);
			out_address1[i][2]=(int)(((double)(output_maxy-InDem[i].ll_y)/(double)yspace)+0.5);
			out_address1[i][3]=(int)(((double)(InDem[i].lr_x-output_minx)/(double)xspace)+0.5);	
			
			
	}
		

	   KT_coord_scan_pix output_corner_details;
	   output_corner_details.scan_pix[0][0]=0;
		output_corner_details.scan_pix[0][1]=0;

		output_corner_details.scan_pix[1][0]=0;
		output_corner_details.scan_pix[1][1]=output_pixels-1;

		output_corner_details.scan_pix[2][0]=output_scans-1;
		output_corner_details.scan_pix[2][1]=output_pixels-1;

		output_corner_details.scan_pix[3][0]=output_scans-1;
		output_corner_details.scan_pix[3][1]=0;

					
		LowerLeft_Lat=output_corner_details.coord[3][0]=output_miny;
		LowerLeft_Lon=output_corner_details.coord[3][1]=output_minx;
		UpperRight_Lat=output_corner_details.coord[1][0]=output_maxy;
		UpperRight_Lon=output_corner_details.coord[1][1]=output_maxx;
		UpperLeft_Lat=output_corner_details.coord[0][0]=output_maxy;
		UpperLeft_Lon=output_corner_details.coord[0][1]=output_minx;
		LowerRight_Lat=output_corner_details.coord[2][0]=output_miny;
		LowerRight_Lon=output_corner_details.coord[2][1]=output_maxx;	
	   /*output_scans=((output_maxy-output_miny)/InDem[0].dely);
	   output_pixels=((output_maxx-output_minx)/InDem[0].delx);*/
	    strcpy(outfile,"");
		strcpy(overlap,"");
		strcpy(overlap1,"");
		//sprintf(outfile,"%s%s%d.DEM",infile,"\\DemMosa",it);
		if(cut==1){
			sprintf(outfile,"%s%d.DEM",inter_file,cut);
			sprintf(outfile1,"%s_proposed.tif",inter_file);}
		else
			sprintf(outfile,"%s",inter_file);
	   KT_HEAD* head = new KT_HEAD;
		head->initialization();
		head->getheader(InDem[0].in_file);
		head->setvalues(KD_SCANS, &output_scans, KD_PIXELS, &output_pixels, KD_COORD_SCAN_LAT, &output_corner_details, NULL);
		head->addheader(outfile);//adding AIPS header to outfile 
							
		
		//head->replaceheader(outfile);
					
		delete head;
		
		if( (err  = fopen_s( &foutput, outfile, "ab" )) !=0 )
		{
			printf( "The output file: %s was not opened\n",outfile);
			return -1;
		}

		

	   outarr=(signed short int **)malloc(sizeof(signed short int *)*output_scans);
	   for(int pr=0;pr<output_scans;pr++)
		{
			//n[i]=(signed short int *)malloc(sizeof(signed short int)*Ymx);
			outarr[pr]=(signed short int *)malloc(sizeof(signed short int)*output_pixels);

		}
		//Initialization of OP Grid
		for(int pr=0;pr<output_scans;pr++)
		{

			for(int qr=0;qr<output_pixels;qr++)
			{
				outarr[pr][qr]=NoData;
			}
		}
		
	   Adj=(short **)malloc(sizeof(short *)*fno);
	
		for(i=0;i<fno;i++)
		{
			//n[i]=(signed short int *)malloc(sizeof(signed short int)*Ymx);
			Adj[i]=(short *)malloc(sizeof(short)*fno);

		}
		for(int r=0;r<fno;r++)
	   {
		   for(int s=0;s<fno;s++)
		   {
			   Adj[r][s]=0;
		   }	  
	   }
	   Oinfo=(struct Overlap_Info *)malloc(sizeof(struct Overlap_Info)*(fno*(fno-1)/2.0));
	   //Recent

	   for(int r=0;r<fno;r++)
	   {
		   intersect_count=0;
		   struct edge *RectEdge;
		   RectEdge=(struct edge *)malloc(sizeof(struct edge)*2);//It stores points of sides that are intersected
		   Sides=(short *)malloc(sizeof(short)*4);
		   for(int s=r+1;s<fno;s++)
		   {
			   
			   valid=0;
			   sideno=0;
			   side_count=0;
			  /* printf("ul_x[%d]=%f\t",s,InDem[s].ul_x);
			   printf("lr_y[%d]=%f\n",s,InDem[s].lr_y);*/
			   //printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
			   //Case:First side of s			    
			   //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
			   
				  
				  
				   if(isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y))//side 1 of rectangle r
				   {
					   //one edge of source
					    RectEdge[valid].r_x1=InDem[r].ul_x;
						RectEdge[valid].r_y1=InDem[r].ul_y;
						RectEdge[valid].r_x2=InDem[r].ur_x;
						RectEdge[valid].r_y2=InDem[r].ur_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ul_x;
						RectEdge[valid].s_y1=InDem[s].ul_y;						
						RectEdge[valid].s_x2=InDem[s].ur_x;
						RectEdge[valid].s_y2=InDem[s].ur_y;
						//find intersection point
						//computeInters_point(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
						valid++;

						//Sides updation
						Sides[side_count++]=1;//side of r
						Sides[side_count++]=1;//side of s
						 Adj[r][s]=1;

				   }
				   if(isIntersected(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y))
				   {
					    RectEdge[valid].r_x1=InDem[r].ur_x;
						RectEdge[valid].r_y1=InDem[r].ur_y;
						RectEdge[valid].r_x2=InDem[r].lr_x;
						RectEdge[valid].r_y2=InDem[r].lr_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ul_x;
						RectEdge[valid].s_y1=InDem[s].ul_y;						
						RectEdge[valid].s_x2=InDem[s].ur_x;
						RectEdge[valid].s_y2=InDem[s].ur_y;
					   //find intersection point
						//computeInters_point(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
						valid++;
						//Sides updation
						Sides[side_count++]=2;//side of r
						Sides[side_count++]=1;//side of s
						 Adj[r][s]=1;
				   }
			   	   if(isIntersected(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y))//sideno is for rectangle r
				   {
					   RectEdge[valid].r_x1=InDem[r].lr_x;
						RectEdge[valid].r_y1=InDem[r].lr_y;
						RectEdge[valid].r_x2=InDem[r].ll_x;
						RectEdge[valid].r_y2=InDem[r].ll_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ul_x;
						RectEdge[valid].s_y1=InDem[s].ul_y;						
						RectEdge[valid].s_x2=InDem[s].ur_x;
						RectEdge[valid].s_y2=InDem[s].ur_y;
					   //find intersection point
						//computeInters_point(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
						valid++;
						//Sides updation
						Sides[side_count++]=3;//side of r
						Sides[side_count++]=1;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y))//sideno is for rectangle r
				   {///found here
					   RectEdge[valid].r_x1=InDem[r].ll_x;
						RectEdge[valid].r_y1=InDem[r].ll_y;
						RectEdge[valid].r_x2=InDem[r].ul_x;
						RectEdge[valid].r_y2=InDem[r].ul_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ul_x;
						RectEdge[valid].s_y1=InDem[s].ul_y;						
						RectEdge[valid].s_x2=InDem[s].ur_x;
						RectEdge[valid].s_y2=InDem[s].ur_y;
					   //find intersection point
						//computeInters_point(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
						valid++;
						//Sides updation
						Sides[side_count++]=4;//side of r
						Sides[side_count++]=1;//side of s
						Adj[r][s]=1;
				   }
				
				   
			  //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y);
			  //Case:second side of s			  
			  //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
			  
					
				   if(isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y))//side 1 of r
				   {
					   //one edge of source
					    RectEdge[valid].r_x1=InDem[r].ul_x;
						RectEdge[valid].r_y1=InDem[r].ul_y;
						RectEdge[valid].r_x2=InDem[r].ur_x;
						RectEdge[valid].r_y2=InDem[r].ur_y;
												
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].ur_x;
						RectEdge[valid].s_y1=InDem[s].ur_y;
						RectEdge[valid].s_x2=InDem[s].lr_x;
						RectEdge[valid].s_y2=InDem[s].lr_y;					
					   //find intersection point
						//computeInters_point(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
						valid++;
						//Sides updation
						Sides[side_count++]=1;//side of r
						Sides[side_count++]=2;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y))//side 2 of r
				   {
					   RectEdge[valid].r_x1=InDem[r].ur_x;
						RectEdge[valid].r_y1=InDem[r].ur_y;
						RectEdge[valid].r_x2=InDem[r].lr_x;
						RectEdge[valid].r_y2=InDem[r].lr_y;
					   //one edge of target
						RectEdge[valid].s_x1=InDem[s].ur_x;
						RectEdge[valid].s_y1=InDem[s].ur_y;
						RectEdge[valid].s_x2=InDem[s].lr_x;
						RectEdge[valid].s_y2=InDem[s].lr_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
						valid++;
						//Sides updation
						Sides[side_count++]=2;//side of r
						Sides[side_count++]=2;//side of s
						Adj[r][s]=1;
				   }
			   	   if(isIntersected(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y))
				   {//
					   RectEdge[valid].r_x1=InDem[r].lr_x;
						RectEdge[valid].r_y1=InDem[r].lr_y;
						RectEdge[valid].r_x2=InDem[r].ll_x;
						RectEdge[valid].r_y2=InDem[r].ll_y;
					   //one edge of target
						RectEdge[valid].s_x1=InDem[s].ur_x;
						RectEdge[valid].s_y1=InDem[s].ur_y;
						RectEdge[valid].s_x2=InDem[s].lr_x;
						RectEdge[valid].s_y2=InDem[s].lr_y;	
					   //find intersection point
						//computeInters_point(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
						valid++;
						//Sides updation
						Sides[side_count++]=3;//side of r
						Sides[side_count++]=2;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y))
				   {
					    RectEdge[valid].r_x1=InDem[r].ll_x;
						RectEdge[valid].r_y1=InDem[r].ll_y;
						RectEdge[valid].r_x2=InDem[r].ul_x;
						RectEdge[valid].r_y2=InDem[r].ul_y;
					   //one edge of target
						RectEdge[valid].s_x1=InDem[s].ur_x;
						RectEdge[valid].s_y1=InDem[s].ur_y;
						RectEdge[valid].s_x2=InDem[s].lr_x;
						RectEdge[valid].s_y2=InDem[s].lr_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y);
						valid++;
						//Sides updation
						Sides[side_count++]=4;//side of r
						Sides[side_count++]=2;//side of s
						Adj[r][s]=1;
				   }
			
			   
			  //Case:Third side of s			  
			  //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
			  
				  
				   if(isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y))
				   {
					   //one edge of source
					    RectEdge[valid].r_x1=InDem[r].ul_x;
						RectEdge[valid].r_y1=InDem[r].ul_y;
						RectEdge[valid].r_x2=InDem[r].ur_x;
						RectEdge[valid].r_y2=InDem[r].ur_y;
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].lr_x;
						RectEdge[valid].s_y1=InDem[s].lr_y;
						RectEdge[valid].s_x2=InDem[s].ll_x;
						RectEdge[valid].s_y2=InDem[s].ll_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
						valid++;
						//Sides updation
						Sides[side_count++]=1;//side of r
						Sides[side_count++]=3;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y))
				   {
					   //one edge of source
					     RectEdge[valid].r_x1=InDem[r].ur_x;
						RectEdge[valid].r_y1=InDem[r].ur_y;
						RectEdge[valid].r_x2=InDem[r].lr_x;
						RectEdge[valid].r_y2=InDem[r].lr_y;
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].lr_x;
						RectEdge[valid].s_y1=InDem[s].lr_y;
						RectEdge[valid].s_x2=InDem[s].ll_x;
						RectEdge[valid].s_y2=InDem[s].ll_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
						valid++;
						//Sides updation
						Sides[side_count++]=2;//side of r
						Sides[side_count++]=3;//side of s
						Adj[r][s]=1;
				   }
			   	  if(isIntersected(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y))
				   {
					   //one edge of source
					   RectEdge[valid].r_x1=InDem[r].lr_x;
						RectEdge[valid].r_y1=InDem[r].lr_y;
						RectEdge[valid].r_x2=InDem[r].ll_x;
						RectEdge[valid].r_y2=InDem[r].ll_y;
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].lr_x;
						RectEdge[valid].s_y1=InDem[s].lr_y;
						RectEdge[valid].s_x2=InDem[s].ll_x;
						RectEdge[valid].s_y2=InDem[s].ll_y	;
					   //find intersection point
						//computeInters_point(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
						valid++;
						//Sides updation
						Sides[side_count++]=3;//side of r
						Sides[side_count++]=3;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y))
				   { 
					   //one edge of source
					   RectEdge[valid].r_x1=InDem[r].ll_x;
						RectEdge[valid].r_y1=InDem[r].ll_y;
						RectEdge[valid].r_x2=InDem[r].ul_x;
						RectEdge[valid].r_y2=InDem[r].ul_y;
						//one edge of target
						RectEdge[valid].s_x1=InDem[s].lr_x;
						RectEdge[valid].s_y1=InDem[s].lr_y;
						RectEdge[valid].s_x2=InDem[s].ll_x;
						RectEdge[valid].s_y2=InDem[s].ll_y;	
					   //find intersection point
						//computeInters_point(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y);
						valid++;
						//Sides updation
						Sides[side_count++]=4;//side of r
						Sides[side_count++]=3;//side of s
						Adj[r][s]=1;
				   }
			  
			  //Case:Fourth side of s
			   //sideno=isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
			   
				  
				   if(isIntersected(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y))
				   {
					    //one edge of source
					    RectEdge[valid].r_x1=InDem[r].ul_x;
						RectEdge[valid].r_y1=InDem[r].ul_y;
						RectEdge[valid].r_x2=InDem[r].ur_x;
						RectEdge[valid].r_y2=InDem[r].ur_y;
						//one edge of target
						RectEdge[valid].s_x1= InDem[s].ll_x;
						RectEdge[valid].s_y1=InDem[s].ll_y;
						RectEdge[valid].s_x2=InDem[s].ul_x;
						RectEdge[valid].s_y2=InDem[s].ul_y;
					   //find intersection point
						//computeInters_point(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,  InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
						valid++;
						//Sides updation
						Sides[side_count++]=1;//side of r
						Sides[side_count++]=4;//side of s
						Adj[r][s]=1;
				   }
				   if(isIntersected(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y))
				   {
					   //one edge of source
					     RectEdge[valid].r_x1=InDem[r].ur_x;
						RectEdge[valid].r_y1=InDem[r].ur_y;
						RectEdge[valid].r_x2=InDem[r].lr_x;
						RectEdge[valid].r_y2=InDem[r].lr_y;
						//one edge of target
						RectEdge[valid].s_x1= InDem[s].ll_x;
						RectEdge[valid].s_y1=InDem[s].ll_y;
						RectEdge[valid].s_x2=InDem[s].ul_x;
						RectEdge[valid].s_y2=InDem[s].ul_y;
					   //find intersection point
						//computeInters_point(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,  InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
						valid++;
						//Sides updation
						Sides[side_count++]=2;//side of r
						Sides[side_count++]=4;//side of s
						Adj[r][s]=1;
				   }
			   	  if(isIntersected(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y))
				   {
					    //one edge of source
					   RectEdge[valid].r_x1=InDem[r].lr_x;
						RectEdge[valid].r_y1=InDem[r].lr_y;
						RectEdge[valid].r_x2=InDem[r].ll_x;
						RectEdge[valid].r_y2=InDem[r].ll_y;
						//one edge of target
						RectEdge[valid].s_x1= InDem[s].ll_x;
						RectEdge[valid].s_y1=InDem[s].ll_y;
						RectEdge[valid].s_x2=InDem[s].ul_x;
						RectEdge[valid].s_y2=InDem[s].ul_y;
					   //find intersection point
						//computeInters_point(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y,  InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
						valid++;
						//Sides updation
						Sides[side_count++]=3;//side of r
						Sides[side_count++]=4;//side of s
						Adj[r][s]=1;
				   }
				  if(isIntersected(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y))
				   {
					   //one edge of source
					   RectEdge[valid].r_x1=InDem[r].ll_x;
						RectEdge[valid].r_y1=InDem[r].ll_y;
						RectEdge[valid].r_x2=InDem[r].ul_x;
						RectEdge[valid].r_y2=InDem[r].ul_y;
						//one edge of target
						RectEdge[valid].s_x1= InDem[s].ll_x;
						RectEdge[valid].s_y1=InDem[s].ll_y;
						RectEdge[valid].s_x2=InDem[s].ul_x;
						RectEdge[valid].s_y2=InDem[s].ul_y;
					   //find intersection point
						//computeInters_point(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y, InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y);
						valid++;
						//Sides updation
						Sides[side_count++]=4;//side of r
						Sides[side_count++]=4;//side of s
						Adj[r][s]=1;
				   }
			  
			   /*if(InDem[r].ul_x < InDem[s].ul_x  || InDem[r].lr_y > InDem[s].lr_y || InDem[r].ul_x > InDem[s].ul_x || InDem[r].lr_x < InDem[s].lr_x)
   					Adj[r][s]=0;
			   else
				   Adj[r][s]=1;*/

			   if(valid==2)
			   {//gather the edges and compute intersection and extents of overlap
					 //struct overlap_struct OverlapDEM;
					 double dx=0.0,dy=0.0,c1=0.0,m1=0.0,c2=0.0,m2=0.0,tempc1=0.0,tempc2=0.0,tempm1=0.0,tempm2=0.0;
					 double **inter1,**inter2;

					 int g=0;
					 min_x=99999999.0;
					 max_x=-99999999.0;
					 min_y=99999999.0;
					 max_y=-99999999.0;
					 inter1=(double **)malloc(sizeof(double*)*2);
					  inter2=(double **)malloc(sizeof(double*)*2);
					 
					
					for(int t=0;t<2;t++)
					{
						
						inter1[t]=(double *)malloc(sizeof(double)*2);
						inter2[t]=(double *)malloc(sizeof(double)*2);
					}
					RectEdge[0].src_imageno=r;
					RectEdge[0].trg_imageno=s;
					RectEdge[1].src_imageno=r;
					RectEdge[1].trg_imageno=s;
					// struct overlap_struct OverlapDEM;
					 //OverlapDEM=(struct overlap_struct *)malloc(sizeof(struct overlap_struct));
					 for(g=0;g<valid;g++)
					 {

						 
						  //Intersection
						/* printf("***********SOURCE****************\n");
						
						printf("RectEdge[%d].r_x1=%f\n",g,RectEdge[g].r_x1);
						 printf("RectEdge[%d].r_y1=%f\n",g,RectEdge[g].r_y1);
						 
						printf("RectEdge[%d].r_x2=%f\n",g,RectEdge[g].r_x2);
						printf("RectEdge[%d].r_y2=%f\n",g,RectEdge[g].r_y2);
						printf("***********Target****************\n");
						printf("RectEdge[%d].s_x1=%f\n",g,RectEdge[g].s_x1);
						
						 printf("RectEdge[%d].s_y1=%f\n",g,RectEdge[g].s_y1);
						 
						printf("RectEdge[%d].s_x2=%f\n",g,RectEdge[g].s_x2);
						printf("RectEdge[%d].s_y2=%f\n",g,RectEdge[g].s_y2);
						
						*/
						if(RectEdge[g].r_y2==RectEdge[g].r_y1)
						 {
							 inter1[g][1]=RectEdge[g].r_y1;
						 }

						 if(RectEdge[g].s_y2==RectEdge[g].s_y1)
						 {
							 inter1[g][1]=RectEdge[g].s_y1;
						 }
						 if(RectEdge[g].r_x2==RectEdge[g].r_x1)
						 {
							 inter1[g][0]=RectEdge[g].r_x1;
						 }
						 if(RectEdge[g].s_x2==RectEdge[g].s_x1)
						 {
							 inter1[g][0]=RectEdge[g].s_x1;
						 }

						/*(RectEdge[g].r_x1,RectEdge[g].r_y1);(RectEdge[g].r_x2,RectEdge[g].r_y2);
						(RectEdge[g].s_x1,RectEdge[g].s_y1);(RectEdge[g].s_x2),RectEdge[g].s_y2);

						dx=RectEdge[g].r_x2-RectEdge[g].r_x1;
						dy=RectEdge[g].r_y2-RectEdge[g].r_y1;
						if(dx!=0)
							m1==(float)(double)dy/(double)dx;
						else
							m1=0;
						c1=RectEdge[g].r_y1-(m1*RectEdge[g].r_x1);

						dx=RectEdge[g].s_x2-RectEdge[g].s_x1;
						dy=RectEdge[g].s_y2-RectEdge[g].s_y1;
						if(dx!=0)
							m2=(float)(double)dy/(double)dx;
						else
							m2=0;
						c2=RectEdge[g].s_y1-(m2*RectEdge[g].s_x1);

						if((m1-m2)==0)
							printf("NO\n");
						else
						{
							inter1[g][0]=(float)(double)(c2-c1)/(double)(m1-m2);
							inter1[g][1]=m1*inter1[g][0]+c1;
						}*/
/*
						printf("P%d(%f,%f)\n",g+1,inter1[g][0],inter1[g][1]);
						printf("srcimageno=%d\n",RectEdge[g].src_imageno);
						printf("trgimageno=%d\n",RectEdge[g].trg_imageno);
						printf("*******88888888888888888888888888888888*******\n");
						printf("ulx1=%f\tuly1=%f\n",InDem[RectEdge[0].trg_imageno].ul_x,InDem[RectEdge[0].trg_imageno].ul_y);
						*///if(RectEdge[g].r_x1==
						
						
					 }
					//In addition to intersection points,Common points computation to form a polygon has TWO cases;
					 //e.g., r2-->s1;r2-->s3,(side r2 is common), 
								//then common points are points of Inclusion(s1,s3) in Polygon R
					 //e.g., r2-->s1;r3-->s4, (All are distinct sides),
								//then common points are A=Intersection{r2,r3};B={s1,s4}
					 int_count=0;
					 semi_count=0;
					 if(Sides[0]==Sides[2])
					 {//check points of sides of Polygon S(s1,s3) in polygon R
						 //doIntersect()//internal count
						 for(int h=0;h<2;h++)
						 {
							 int_count=0;
							 if(doIntersect(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,RectEdge[h].s_x1,RectEdge[h].s_y1,9999999.0,RectEdge[h].s_y1))
							 int_count++;
							 if(doIntersect(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,RectEdge[h].s_x1,RectEdge[h].s_y1,9999999.0,RectEdge[h].s_y1))
								 int_count++;
							if(doIntersect(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y,RectEdge[h].s_x1,RectEdge[h].s_y1,9999999.0,RectEdge[h].s_y1))
								 int_count++;
							if(doIntersect(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,RectEdge[h].s_x1,RectEdge[h].s_y1,9999999.0,RectEdge[h].s_y1))
								 int_count++;
							if(int_count%2==1)
							{

								inter2[semi_count][0]=RectEdge[h].s_x1;
								inter2[semi_count][1]=RectEdge[h].s_y1;
								semi_count++;
							}
						 }

						 for(int h=0;h<2;h++)
						 {
							 int_count=0;
							 if(doIntersect(InDem[r].ul_x,InDem[r].ul_y,InDem[r].ur_x,InDem[r].ur_y,RectEdge[h].s_x2,RectEdge[h].s_y2,9999999.0,RectEdge[h].s_y2))
							 int_count++;
							 if(doIntersect(InDem[r].ur_x,InDem[r].ur_y,InDem[r].lr_x,InDem[r].lr_y,RectEdge[h].s_x2,RectEdge[h].s_y2,9999999.0,RectEdge[h].s_y2))
								 int_count++;
							if(doIntersect(InDem[r].lr_x,InDem[r].lr_y,InDem[r].ll_x,InDem[r].ll_y,RectEdge[h].s_x2,RectEdge[h].s_y2,9999999.0,RectEdge[h].s_y2))
								 int_count++;
							if(doIntersect(InDem[r].ll_x,InDem[r].ll_y,InDem[r].ul_x,InDem[r].ul_y,RectEdge[h].s_x2,RectEdge[h].s_y2,9999999.0,RectEdge[h].s_y2))
								 int_count++;
							if(int_count%2==1)
							{

								inter2[semi_count][0]=RectEdge[h].s_x2;
								inter2[semi_count][1]=RectEdge[h].s_y2;
								semi_count++;
							}
						 }
						

						 					
					 }
					 else if (Sides[1]==Sides[3])
					 {//check points of sides of Polygon R in Ploygon S
						 
						 
						for(int h=0;h<2;h++)
						 {
							 int_count=0;
							 if(doIntersect(InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y,RectEdge[h].r_x1,RectEdge[h].r_y1,9999999.0,RectEdge[h].r_y1))
							 int_count++;
							 if(doIntersect(InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y,RectEdge[h].r_x1,RectEdge[h].r_y1,9999999.0,RectEdge[h].r_y1))
								 int_count++;
							if(doIntersect(InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y,RectEdge[h].r_x1,RectEdge[h].r_y1,9999999.0,RectEdge[h].r_y1))
								 int_count++;
							if(doIntersect(InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y,RectEdge[h].r_x1,RectEdge[h].r_y1,9999999.0,RectEdge[h].r_y1))
								 int_count++;
							if(int_count%2==1)
							{

								inter2[semi_count][0]=RectEdge[h].r_x1;
								inter2[semi_count][1]=RectEdge[h].r_y1;
								semi_count++;
							}
						 }

						 for(int h=0;h<2;h++)
						 {
							 int_count=0;
							 if(doIntersect(InDem[s].ul_x,InDem[s].ul_y,InDem[s].ur_x,InDem[s].ur_y,RectEdge[h].r_x2,RectEdge[h].r_y2,9999999.0,RectEdge[h].r_y2))
							 int_count++;
							 if(doIntersect(InDem[s].ur_x,InDem[s].ur_y,InDem[s].lr_x,InDem[s].lr_y,RectEdge[h].r_x2,RectEdge[h].r_y2,9999999.0,RectEdge[h].r_y2))
								 int_count++;
							if(doIntersect(InDem[s].lr_x,InDem[s].lr_y,InDem[s].ll_x,InDem[s].ll_y,RectEdge[h].r_x2,RectEdge[h].r_y2,9999999.0,RectEdge[h].r_y2))
								 int_count++;
							if(doIntersect(InDem[s].ll_x,InDem[s].ll_y,InDem[s].ul_x,InDem[s].ul_y,RectEdge[h].r_x2,RectEdge[h].r_y2,9999999.0,RectEdge[h].r_y2))
								 int_count++;
							if(int_count%2==1)
							{

								inter2[semi_count][0]=RectEdge[h].r_x2;
								inter2[semi_count][1]=RectEdge[h].r_y2;
								semi_count++;
							}
						 }		
					 }
					 else
					 {
						 g=0;
						 if(RectEdge[g].r_x1==RectEdge[g+1].r_x1) 
						 {
							 if(RectEdge[g].r_y1==RectEdge[g+1].r_y1) 
							 {
								 inter2[0][0]=RectEdge[g].r_x1;
								 inter2[0][1]=RectEdge[g].r_y1;

							 }
						 }
						 if(RectEdge[g].r_x1==RectEdge[g+1].r_x2)
						 {
							 if(RectEdge[g].r_y1==RectEdge[g+1].r_y2) 
							 {
								 inter2[0][0]=RectEdge[g].r_x1;
								 inter2[0][1]=RectEdge[g].r_y1;

							 }
						 }
						 if(RectEdge[g].r_x2==RectEdge[g+1].r_x1) 
						 {
							 if(RectEdge[g].r_y2==RectEdge[g+1].r_y1) 
							 {
								 inter2[0][0]=RectEdge[g].r_x2;
								 inter2[0][1]=RectEdge[g].r_y2;

							 }
						 }
						 if(RectEdge[g].r_x2==RectEdge[g+1].r_x2)
						 {
							 if(RectEdge[g].r_y2==RectEdge[g+1].r_y2) 
							 {
								 inter2[0][0]=RectEdge[g].r_x2;
								 inter2[0][1]=RectEdge[g].r_y2;

							 }
						 }
						  if(RectEdge[g].s_x1==RectEdge[g+1].s_x1) 
						 {
							 if(RectEdge[g].s_y1==RectEdge[g+1].s_y1) 
							 {
								 inter2[1][0]=RectEdge[g].s_x1;
								 inter2[1][1]=RectEdge[g].s_y1;

							 }
						 }
						 if(RectEdge[g].s_x1==RectEdge[g+1].s_x2)
						 {
							 if(RectEdge[g].s_y1==RectEdge[g+1].s_y2) 
							 {
								 inter2[1][0]=RectEdge[g].s_x1;
								 inter2[1][1]=RectEdge[g].s_y1;

							 }
						 }
						 if(RectEdge[g].s_x2==RectEdge[g+1].s_x1) 
						 {
							 if(RectEdge[g].s_y2==RectEdge[g+1].s_y1) 
							 {
								 inter2[1][0]=RectEdge[g].s_x2;
								 inter2[1][1]=RectEdge[g].s_y2;

							 }
						 }
						 
						 if(RectEdge[g].s_x2==RectEdge[g+1].s_x2)
						 {
							 if(RectEdge[g].s_y2==RectEdge[g+1].s_y2) 
							 {
								 inter2[1][0]=RectEdge[g].s_x2;
								 inter2[1][1]=RectEdge[g].s_y2;

							 }
						 }
					 }
					 
					/* printf("A=(%f,%f)\n",inter2[0][0],inter2[0][1]);
					 printf("B=(%f,%f)\n",inter2[1][0],inter2[1][1]);

*/
					 //Finding out Overlapped region and its UL,UR,LR,LL

					for(int w=0;w<2;w++)
					{
						if(min_x >= inter1[w][0])
							min_x=inter1[w][0];
						if(min_x >= inter2[w][0])
							min_x=inter2[w][0];
						if(min_y >= inter1[w][1])
							min_y=inter1[w][1];
						if(min_y >= inter2[w][1])
							min_y=inter2[w][1];

						if(max_x <= inter1[w][0])
							max_x=inter1[w][0];
						if(max_x <= inter2[w][0])
							max_x=inter2[w][0];
						if(max_y <= inter1[w][1])
							max_y=inter1[w][1];
						if(max_y <= inter2[w][1])
							max_y=inter2[w][1];
					}
					//printf("********Overlap********\nUL=(%f,%f)\tUR=(%f,%f)\nLL=(%f,%f)\tLR=(%f,%f)\n",min_x,max_y,max_x,max_y,min_x,min_y,max_x,min_y);
					

					 
					/* if(min_x >= InDem[s].ul_x)
					   min_x=InDem[s].ul_x;
					if(min_y >= InDem[s].lr_y)
						min_y=InDem[s].lr_y;
					if(max_x <= InDem[s].lr_x)
						max_x=InDem[s].lr_x;
					if(max_y <= InDem[s].ul_y)
						max_y=InDem[s].ul_y;*/
					
					//printf("delyka=%.8f\n",InDem[0].dely);
					
					quad1_scans=(int)(((double)(max_y-min_y)/(double)yspace)+0.5);
					quad1_pixels=(int)(((double)(max_x-min_x)/(double)xspace)+0.5);
					
					
					////Pinning data
					/*
					sprintf(overlap,"%s%s%d%s%d.txt",infile,"\\overlapof",r,"with",s);
					if( (err  = fopen_s( &rrdfile,overlap, "w+" )) !=0 )
					{
						printf( "The input file: DEM Overplap analysis.txt was not opened\n");
						return -1;
					}
					fprintf(rrdfile,"xloc=%f\nyloc=%f\n",min_x,max_y);
					printf("file1:%s\tfile2:%s\n",InDem[RectEdge[0].src_imageno].in_file,InDem[RectEdge[0].trg_imageno].in_file);
*/
					//Newly added for src(st,endscan,pix) trg(st,endscan,pix)
					////////////////////////////////////////////////////////
					//sprintf(overlap1,"%s%s%d%s%d.txt",infile,"\\pixelinfo_",r,"with",s);//L2R
					//if( (err  = fopen_s( &rrdfile1,overlap1, "w+" )) !=0 )
					//{
					//	printf( "The input file: DEM Overplap analysisdrr.txt was not opened\n");
					//	return -1;
					//}
					//fprintf(rrdfile1,"%s\n%s\n",InDem[r].in_file,InDem[s].in_file);
					//sprintf(overlap2,"%s%s%d%s%d.txt",infile,"\\scaninfo_",r,"with",s);//T2B
					//if( (err  = fopen_s( &rrdfile2,overlap2, "w+" )) !=0 )
					//{
					//	printf( "The input file: DEM Overplap analysisdrr.txt was not opened\n");
					//	return -1;
					//}
					//fprintf(rrdfile2,"%s\n%s\n",InDem[r].in_file,InDem[s].in_file);
					/*InDem[RectEdge[0].src_imageno].used=true;
					InDem[RectEdge[0].trg_imageno].used=true;*/
					Oinfo[intersect_count].src_demno=RectEdge[0].src_imageno;
					Oinfo[intersect_count].trg_demno=RectEdge[0].trg_imageno;	
					//min_x,max_y,max_x,max_y,min_x,min_y,max_x,min_y);
					Oinfo[intersect_count].ul_x=min_x;
					Oinfo[intersect_count].ul_y=max_y;
					Oinfo[intersect_count].ur_x=max_x;
					Oinfo[intersect_count].ur_y=max_y;
					Oinfo[intersect_count].lr_x=max_x;
					Oinfo[intersect_count].lr_y=min_y;
					Oinfo[intersect_count].ll_x=min_x;
					Oinfo[intersect_count].ll_y=min_y;

					

					Oinfo[intersect_count].src_st_scan=(int)(((double)(InDem[RectEdge[0].src_imageno].ul_y-Oinfo[intersect_count].ul_y)/(double)InDem[RectEdge[0].src_imageno].dely)+0.5);					
					Oinfo[intersect_count].src_st_pixel=(int)(((double)(Oinfo[intersect_count].ul_x-InDem[RectEdge[0].src_imageno].ul_x)/(double)InDem[RectEdge[0].src_imageno].delx)+0.5);					
					Oinfo[intersect_count].src_end_scan=(int)(((double)(InDem[RectEdge[0].src_imageno].ul_y-Oinfo[intersect_count].ll_y)/(double)InDem[RectEdge[0].src_imageno].dely)+0.5);
					Oinfo[intersect_count].src_end_pixel=(int)(((double)(Oinfo[intersect_count].lr_x-InDem[RectEdge[0].src_imageno].ul_x)/(double)InDem[RectEdge[0].src_imageno].delx)+0.5);
					//Oinfo[intersect_count].src_end_scan=Oinfo[intersect_count].src_st_scan+(int)((double)(Oinfo[intersect_count].ul_y-Oinfo[intersect_count].ll_y)/(double)InDem[RectEdge[0].src_imageno].dely);
					//Oinfo[intersect_count].src_end_pixel=Oinfo[intersect_count].src_st_pixel+(int)((double)(Oinfo[intersect_count].lr_x-Oinfo[intersect_count].ll_x)/(double)InDem[RectEdge[0].src_imageno].delx);
					
					Oinfo[intersect_count].trg_st_scan=(int)(((double)(InDem[RectEdge[0].trg_imageno].ul_y-Oinfo[intersect_count].ul_y)/(double)InDem[RectEdge[0].trg_imageno].dely)+0.5);					
					Oinfo[intersect_count].trg_st_pixel=(int)(((double)(Oinfo[intersect_count].ul_x-InDem[RectEdge[0].trg_imageno].ul_x)/(double)InDem[RectEdge[0].trg_imageno].delx)+0.5);					
					Oinfo[intersect_count].trg_end_scan=(int)(((double)(InDem[RectEdge[0].trg_imageno].ul_y-Oinfo[intersect_count].ll_y)/(double)InDem[RectEdge[0].trg_imageno].dely)+0.5);
					Oinfo[intersect_count].trg_end_pixel=(int)(((double)(Oinfo[intersect_count].lr_x-InDem[RectEdge[0].trg_imageno].ul_x)/(double)InDem[RectEdge[0].trg_imageno].delx)+0.5);

					
					Oinfo[intersect_count].output_st_scan=(int)(((double)(output_maxy-Oinfo[intersect_count].ul_y)/(double)yspace)+0.5);					
					Oinfo[intersect_count].output_st_pixel=(int)(((double)(Oinfo[intersect_count].ul_x-output_minx)/(double)xspace)+0.5);					
					Oinfo[intersect_count].output_end_scan=(int)(((double)(output_maxy-Oinfo[intersect_count].ll_y)/(double)yspace)+0.5);
					Oinfo[intersect_count].output_end_pixel=(int)(((double)(Oinfo[intersect_count].lr_x-output_minx)/(double)xspace)+0.5);

					//Naga sir affine transformation

					/*double **image_corner1,**image_corner2;

					image_corner1=Alloc<double>(4,2);
					image_corner2=Alloc<double>(4,2);

					image_corner1[0][0]=Oinfo[intersect_count].src_st_scan-Oinfo[intersect_count].src_st_scan;
					image_corner1[0][1]=Oinfo[intersect_count].src_st_pixel-Oinfo[intersect_count].src_st_pixel;
					image_corner1[1][0]=Oinfo[intersect_count].src_st_scan-Oinfo[intersect_count].src_st_scan;
					image_corner1[1][1]=Oinfo[intersect_count].src_end_pixel-Oinfo[intersect_count].src_st_pixel;
					image_corner1[2][0]=Oinfo[intersect_count].src_end_scan-Oinfo[intersect_count].src_st_scan;
					image_corner1[2][1]=Oinfo[intersect_count].src_end_pixel-Oinfo[intersect_count].src_st_pixel;
					image_corner1[3][0]=Oinfo[intersect_count].src_end_scan-Oinfo[intersect_count].src_st_scan;
					image_corner1[3][1]=Oinfo[intersect_count].src_st_pixel-Oinfo[intersect_count].src_st_pixel;

					image_corner2[0][0]=Oinfo[intersect_count].trg_st_scan-Oinfo[intersect_count].trg_st_scan;
					image_corner2[0][1]=Oinfo[intersect_count].trg_st_pixel-Oinfo[intersect_count].trg_st_pixel;
					image_corner2[1][0]=Oinfo[intersect_count].trg_st_scan-Oinfo[intersect_count].trg_st_scan;
					image_corner2[1][1]=Oinfo[intersect_count].trg_end_pixel-Oinfo[intersect_count].trg_st_pixel;
					image_corner2[2][0]=Oinfo[intersect_count].trg_end_scan-Oinfo[intersect_count].trg_st_scan;
					image_corner2[2][1]=Oinfo[intersect_count].trg_end_pixel-Oinfo[intersect_count].trg_st_pixel;
					image_corner2[3][0]=Oinfo[intersect_count].trg_end_scan-Oinfo[intersect_count].trg_st_scan;
					image_corner2[3][1]=Oinfo[intersect_count].trg_st_pixel-Oinfo[intersect_count].trg_st_pixel;

					TRAN_MATION *Whole_Image_Trans=new TRAN_MATION(4,image_corner1,image_corner2,"AFFINE");
					Whole_Image_Trans->normalize();
					Whole_Image_Trans->Form_Matrices();
					Whole_Image_Trans->Least_Square_Fit();

					Free_Variable<double>(image_corner1,4);
					Free_Variable<double>(image_corner2,4);*/
					//EOF Affine
					//Blending procedure Starts here				
					
					/*array1_scans=(Oinfo[intersect_count].output_end_scan-Oinfo[intersect_count].output_st_scan)+1;
					array1_pixels=(Oinfo[intersect_count].output_end_pixel-Oinfo[intersect_count].output_st_pixel)+1;*/

					array1_scans=(int)(((double)(Oinfo[intersect_count].ul_y-Oinfo[intersect_count].ll_y)/(double)yspace)+0.5);
					array1_pixels=(int)(((double)(Oinfo[intersect_count].lr_x-Oinfo[intersect_count].ul_x)/(double)xspace)+0.5);
					//These represent overlapped grid Extent in terms of no.of Scans & Pixels w.r.to Output Grid
					array1_scans+=1;
					array1_pixels+1;
					//Calling to Blending
					blend_freq=1;
					//double epsi=0.000000000000000222045;
					if(HorV=='C')
					{//check the extents of polys and decide either L2R/T2B
						/*int v1=0;
						int v2=0;*/
						if(array1_pixels<(array1_scans/2))
						{
							HorV='H';
							/*v1=InDem[r].ul_x*10000000;
							v2=InDem[s].ul_x*10000000;*/
							if(InDem[r].ul_x<InDem[s].ul_x)
								LorR='L';
							else
								LorR='R';

						}
						else//array1_scans<array1_pixels
						{
							HorV='V';	
								/*v1=InDem[r].ul_y*10000000;
								v2=InDem[s].ul_y*10000000;*/
								if(InDem[r].ul_y>InDem[s].ul_y)
									LorR='L';
								else
									LorR='R';
						}
						//preference has to be given to L image or R image				
						
										
					}
					//int blend_freq,int fifty,
					//T2B_Blend(blend_freq,1,InDem,Oinfo,array1_scans,array1_pixels,intersect_count,output_maxy,output_minx,r,s,outarr,inarr1);
				
					//L2R_Blend(rrdfile1,blend_freq,0,InDem,Oinfo,array1_scans,array1_pixels,intersect_count,output_maxy,output_minx,r,s,outarr,inarr1);
					if(HorV=='V')
						T2B_Blend(rrdfile2,1,0,LorR,InDem,Oinfo,array1_scans,array1_pixels,intersect_count,output_maxy,output_minx,r,s,outarr,inarr1,xspace,yspace);
					else if(HorV=='H')
						L2R_Blend(rrdfile1,1,0,LorR,InDem,Oinfo,array1_scans,array1_pixels,intersect_count,output_maxy,output_minx,r,s,outarr,inarr1,xspace,yspace);
					
					//getchar();
					/*fclose(rrdfile1);*/
					//fclose(rrdfile2);
//******************************************************************************************************/				
					
//*****************************************************************************************************/					
					
					intersect_count++;
					
					for(int pr=0;pr<2;pr++)
					{													
						free(inter1[pr]);
						free(inter2[pr]);						
					}
					free(inter1);
					free(inter2);
					
					/*for(int pr=0;pr<4;pr++)
					{													
						free(image_corner1[pr]);
						free(image_corner2[pr]);						
					}
					free(image_corner1);
					free(image_corner2);*/
					//image_corner1
			}//if(valid==2)
		
		
		
		}
	  	   
	   free(Sides);
	   free(RectEdge);
	  
	   
	   }//**********************************EOF of r*******************
	   //fclose(fdrr);
		int a1=0,s_out=0,p_out=0,s_in=0,p_in=0,pr=0,qr=0,k1,l1;
		double Out_lat,Out_lon;
		//Out-of-overlapped region filling		
//As inarr1 values are assigned to outgrid, loop as per inarr1(available scan pix only)	
		//This is declaration section for CC interpolation
	signed short int Ht_val=0,Right_Ht=0;
	double X_Residual=0.0,Y_Residual=0.0;
	bool Bil_Flag=false;
	signed short int **cc_adj;
	cc_adj=(signed short int **)malloc(sizeof(signed short int *)*2);
	for(pr=0;pr<2;pr++)
		cc_adj[pr]=(signed short int *)malloc(sizeof(signed short int)*2);	
	for(pr=0;pr<2;pr++)	
		for(qr=0;qr<2;qr++)
			cc_adj[pr][qr]=NoData;
	//EOF CC initialization	
		for(a1=0;a1<fno;a1++)
		{
			//printf("For %s\n",InDem[a1].in_file);
			for(s_out=out_address1[a1][0];s_out<=out_address1[a1][2];s_out++)
			{	
				for(p_out=out_address1[a1][1];p_out<=out_address1[a1][3];p_out++)
				{	
					Bil_Flag=false;
					Out_lat=output_maxy-(s_out*yspace);
					Out_lon=output_minx+(p_out*xspace);					

					//s_in=(int)((double)(InDem[a1].ul_y-Out_lat)/(double)InDem[a1].dely);
					//p_in=(int)((double)(Out_lon-InDem[a1].ul_x)/(double)InDem[a1].delx);
					//For CC
					X_Residual=((double)(Out_lon-InDem[a1].ul_x)/(double)InDem[a1].delx);
					Y_Residual=((double)(InDem[a1].ul_y-Out_lat)/(double)InDem[a1].dely);
					s_in=(int)Y_Residual;
					p_in=(int)X_Residual;					

					if(s_in >= 0 && s_in+1 <= InDem[a1].rows-1 && p_in >= 0 && p_in+1 <= InDem[a1].cols-1)
					{
						for(k1=0;k1<=1;k1++)
						{
							for(l1=0;l1<=1;l1++)
							{	
								//printf("kval=%d\tl val=%d\n",k1,l1);
								cc_adj[k1][l1]=inarr1[a1][s_in+k1][p_in+l1];
								if(cc_adj[k1][l1]==NoData && Bil_Flag==false)
								{
									Bil_Flag=true;
									k1=2;
									break;
								}
							}
						}	
						if(Bil_Flag==true)
						{
							s_in=(int)((double)(InDem[a1].ul_y-Out_lat)/(double)InDem[a1].dely);
							p_in=(int)((double)(Out_lon-InDem[a1].ul_x)/(double)InDem[a1].delx);
							if(s_in < InDem[a1].rows && p_in < InDem[a1].cols)
								Ht_val=inarr1[a1][s_in][p_in];
						}
						else
						{
							Ht_val=Bilinear(X_Residual,Y_Residual,cc_adj);
						}
						
						//Left_Ht=cubic_conv(X_Residual,Y_Residual,cc_adj);
					}
					else
					{
						s_in=(int)((double)(InDem[a1].ul_y-Out_lat)/(double)InDem[a1].dely);
						p_in=(int)((double)(Out_lon-InDem[a1].ul_x)/(double)InDem[a1].delx);
						if(s_in < InDem[a1].rows && p_in < InDem[a1].cols)
							Ht_val=inarr1[a1][s_in][p_in];
					}			
							
					//EOF CC

					if(outarr[s_out][p_out]==NoData)
						outarr[s_out][p_out]=Ht_val;//inarr1[a1][s_in][p_in];			
					
				}
			}
			
		}
		//Filling zero's window size
		/*if(zeroflag==1)
		{
			int comp_val;
			printf("zero filling..\n");
			for(i=(windowsize/2);i<=(output_scans-((windowsize/2)+1));i++)
			{		
				for(j=(windowsize/2);j<=(output_pixels-((windowsize/2)+1));j++)
				{
					count=0;
					comp_val=0;
					if(outarr[i][j]==0)
					{
						for(k=-(windowsize/2);k<=(windowsize/2);k++)
						{
							for(l=-(windowsize/2);l<=(windowsize/2);l++)
							{
									if(outarr[i+k][j+l]!=0)
									{
										comp_val+=outarr[i+k][j+l];
										count++;									
									}
							}
						}
						if(count>4)
							outarr[i][j]=comp_val/count;
					
					}
				}

			}
		

		}*/

		//EOF Filling Zeros
		
		//EOF Out-of-overlapped region filling
		for(int r1=0;r1<output_scans;r1++)
		{
			fwrite(outarr[r1], sizeof(signed short int),output_pixels, foutput);		
		}
		
		fclose(foutput);
		
		//Cutting
		if(cut==1)
		{
			char*ptr=strstr(inter_file, "_E");
			char s[5];
			ptr += 2;
			strncpy(s, ptr, 2);
			s[2]='\0';
			int e = atof(s);

			ptr +=4;
			strncpy(s, ptr, 2);
			s[2]='\0';
			int nn = atof(s);

			stringstream corner;	
			corner << e << " ";
			corner << Math::Round(nn+1.0) << " ";
			corner << Math::Round(e+1.0) << " ";
			corner << nn << " ";
			string arg;
			string exe = "gdal_translate.exe";
			arg = "-of AIPS ";
			if(NoData==0)
				arg += "-a_nodata 0";
			else
				arg += "-a_nodata 55537";
			//arg += NoData.str();
			arg += " -a_ullr ";
			arg += corner.str();
			arg += " -projwin ";
			arg += corner.str() + " ";
			arg += outfile;
			arg += " ";
			arg += inter_file;
			arg += ".DEM";
			/*arg += infile;
			arg += "\\DEMMosa.DEM";
			arg += " ";
			arg += infile;
			arg += "\\";
			arg += MyVect.at(x).data();
			arg += ".DEM";*/
			CString cmd;
			cmd.Format("%s %s",exe.c_str(), arg.c_str());
			STARTUPINFO stat;
			PROCESS_INFORMATION process;

			ZeroMemory( &stat, sizeof(stat) );
			stat.cb = sizeof(stat);
			ZeroMemory( &process, sizeof(process) );

			int pret=CreateProcess((char*)exe.c_str(),(char*)cmd.operator LPCTSTR(),NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&stat,&process);
			WaitForSingleObject(process.hProcess,INFINITE);
			CloseHandle( process.hProcess );
			CloseHandle( process.hThread );
			//Updating mode 2 to 8 in AIPS HEADER
			strcpy(overlap1,"");
			sprintf(overlap1,"%s",inter_file);
			
			head = new KT_HEAD;
			head->initialization();
			head->getheader(overlap1);
		
			//head->addheader(outfile);//adding AIPS header to outfile 
			char mod1='8';
			
			head->setvalues(KD_MODE,&mod1, NULL);
			head->replaceheader(overlap1);
					
			delete head;
			string arg1;
			//string outfile1=outfile
			string exe1 = "gdal_translate.exe";
			arg1 = "-of GTIFF ";			
			arg1 += inter_file;
			arg1 +=  ".DEM";
			arg1 += " ";
			arg1 += outfile1;
			/*arg += infile;
			arg += "\\DEMMosa.DEM";
			arg += " ";
			arg += infile;
			arg += "\\";
			arg += MyVect.at(x).data();
			arg += ".DEM";*/
			//CString cmd;
			cmd.Format("%s %s",exe1.c_str(), arg1.c_str());
			//STARTUPINFO stat;
			//PROCESS_INFORMATION process;

			ZeroMemory( &stat, sizeof(stat) );
			stat.cb = sizeof(stat);
			ZeroMemory( &process, sizeof(process) );

			pret=CreateProcess((char*)exe.c_str(),(char*)cmd.operator LPCTSTR(),NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&stat,&process);
			WaitForSingleObject(process.hProcess,INFINITE);
			CloseHandle( process.hProcess );
			CloseHandle( process.hThread );
			printf("Mosaic process has been completed.\nDEM mosaic output is saved in %s\n",outfile1);
		}
		//fclose(foutput);
		
	   //printf("FINISHED........\n");
	   for(int i=0;i<fno;i++)
		{
			free(in_address1[i]);
		}
		free(in_address1);
		for(int i=0;i<fno;i++)
		{
			free(out_address1[i]);
		}
		free(out_address1);
		for(int i=0;i<fno;i++)
		{
			free(Adj[i]);
		}
		free(Adj);
	   for(int i=0;i<fno;i++)
		{
			lines=InDem[i].rows;
			pixels=InDem[i].cols;
			for(int j=0;j<lines;j++)
			{				
				free(inarr1[i][j]);
			}

			free(inarr1[i]);
		}
		free(inarr1);
		for(int i=0;i<output_scans;i++)
		{
			free(outarr[i]);
		}
		free(outarr);		

		free(InDem);
		free(Oinfo);


	   }
	   //free(InDem);
return 0;
}
signed short int MyDEMFilter::Bilinear(double x,double y,signed short int **neighb)
{
	double grey_value;
	double int_x,int_y;
	signed short int res;
	int_x=(int)x;   

	int_y=(int)y;	   
	/*(int_x,int_y) Length of breath of rectangle asssued to be one
	-------------
	|           |
	|           |
	-------------
	whatever the value maybe corner values are shifted between 0 and1*/

	//int_x =0.0;int_y=0.0;

	grey_value=(double)(neighb[0][0]*(int_x+1-x)*(int_y+1-y)+neighb[0][1]*(x-int_x)*(int_y+1-y) + neighb[1][0]*(int_x+1-x)*(y-int_y) + neighb[1][1]*(x-int_x)*(y-int_y));
	//grey_value=(double)(neighb[0][0]*(int_x+1-x)*(int_y+1-y)+neighb[0][1]*(int_x+1-x)*(y-int_y) + neighb[1][0]*(x-int_x)*(int_y+1-y) + neighb[1][1]*(x-int_x)*(y-int_y));
	res=(signed short int)(grey_value+0.5);
	return res;
}
signed short int MyDEMFilter::cubic_conv(float x,float y,signed short int **neighb)
{
	for(int i=0;i<4;i++) {
		for(int j=0;j<4;j++) {
			if(neighb[i][j] == 0) return 0;
		}
	}

	int curtx,curty;
	float temp1,temp2,cob,coa;
	float coeff[2][4],coxy,prods[4];
	signed short int res_value;
	float f_res_value;
	curtx=(int)x;curty=(int)y;
	cob=(float)(y-curty);
	coa=(float)(x-curtx);
	coxy=cob;
	for(int i=0;i<2;i++){
		if(i==1)coxy=coa;
		temp1=1-coxy;temp2=1+coxy*temp1;
		coeff[i][0]=temp1*temp1*coxy;
		coeff[i][1]=temp1*temp2;
		coeff[i][2]=coxy*temp2;
		coeff[i][3]=coxy*coxy*temp1;
	}
	int i;
	//#pragma omp parallel for
	for(i=0;i<4;i++)
		prods[i]=(float)(-1.0*coeff[0][0]*(float)neighb[i][0]+coeff[0][1]*(float)neighb[i][1]+coeff[0][2]*(float)neighb[i][2]-coeff[0][3]*(float)neighb[i][3]);

	f_res_value=(-1.0*coeff[1][0]*prods[0]+coeff[1][1]*prods[1]+coeff[1][2]*prods[2]-coeff[1][3]*prods[3]+0.5);

	/*
	printf("GRAY LEVEL IS %d *****\n",greyl);*/
	if (f_res_value < 0)
		res_value=0;
		
	if (f_res_value > 32767)//signed short int Range:-32768 to 32767
		res_value=32767;
	if (f_res_value < -32768)
		res_value=-32768; 
	else res_value=(signed short int)f_res_value;
	
	//if (sizeof(TYPE) == 1)
	//{
	//	if (f_res_value > 256)
	//		res_value=255;
	//	else 
	//		res_value=(TYPE)f_res_value;
	//}
	//else
	//{
	//	if (f_res_value > 32767)//signed short int Range:-32768 to 32767
	//		res_value=32767;
	//	if (f_res_value < -32768)
	//		res_alue=-32768; 
	//	else res_value=(TYPE)f_res_value;
	//}
	printf("neig values\n"); 
	for(int i=0;i<4;i++) {
		for(int j=0;j<4;j++) {
			printf("%d\t",neighb[i][j]); 
		}
		printf("\n");
	}
	printf("After CC Value=%d\n",res_value);
	getchar();
	return(res_value);
}

int MyDEMFilter::T2B_Blend(FILE *rrdfile2,int blend_freq,int fifty,char LorR,struct input_dem *InDem,struct Overlap_Info *Oinfo,int array1_scans,int array1_pixels,int intersect_count,double output_maxy,double output_minx,int r,int s,signed short int **outarr,signed short int ***inarr1, double &xspace,double &yspace)
{		
	/*for(int i=0;i<2;i++)	{
		printf("%s %d %d %lf %lf %lf %lf %lf %lf\n",InDem1[i].in_file,InDem1[i].rows,InDem1[i].cols,InDem1[i].ul_y,InDem1[i].ul_x,InDem1[i].lr_y,InDem1[i].lr_x,InDem1[i].delx,InDem1[i].dely);
	}	
	printf("Overlap\n%lf %lf %lf %lf %lf %lf %lf %lf\n",Oinfo1[0].ul_x,Oinfo1[0].ul_y,Oinfo1[0].ur_x,Oinfo1[0].ur_y,Oinfo1[0].lr_x,Oinfo1[0].lr_y,Oinfo1[0].ll_x,Oinfo1[0].ll_y);*/
	//printf("Overlap SCans=%d\nOverlap Pixels=%d\n",Overlap_scans,Overlap_pixels);
	//**********************Top 2 bottom*********************************************/				
	int A1StPix,A1EndPix,A2StPix,A2EndPix;
	int A1StScan,A1EndScan,A2StScan,A2EndScan;
	int rd=0,blscan,blpix,le_s_in,le_p_in,ri_s_in,ri_p_in;
	int firstBlend[2],SecondBlend[2];
	int scan_size,start_scan,end_scan;
	float Alpha=0.0,Hermite=0.0;
	double Out_lat1,Out_lon1;
	int pr=0,qr=0,t,k,l;
	bool Bil_Flag=false;
	//This is declaration section for CC interpolation
	signed short int Left_Ht=0,Right_Ht=0,NoData=NoDataVal;
	double X_Residual=0.0,Y_Residual=0.0;
	signed short int **cc_adj;
	cc_adj=(signed short int **)malloc(sizeof(signed short int *)*2);
	for(pr=0;pr<2;pr++)
		cc_adj[pr]=(signed short int *)malloc(sizeof(signed short int)*2);	
	for(pr=0;pr<2;pr++)	
		for(qr=0;qr<2;qr++)
			cc_adj[pr][qr]=NoData;
	//EOF CC initialization	
	fprintf(fdrr,"T2B\n");
	for(qr=0;qr<array1_pixels;qr++)
	{
		int flag1=0;
		int Fflag=0,Sflag=0,CohFlag=0;						
		A1StScan=-1;A1EndScan=-1,A2StScan=-1,A2EndScan=-1;
		for(rd=0;rd<2;rd++)
		{
			firstBlend[rd]=-1;								
			SecondBlend[rd]=-1;								
		}
		for(pr=0;pr<array1_scans;pr++)
		{
			blscan =Oinfo[intersect_count].output_st_scan+pr;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
			blpix= Oinfo[intersect_count].output_st_pixel+qr;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
								
			Out_lat1=output_maxy-((blscan)*yspace);//check by giving 0 inplace of r
			Out_lon1=output_minx+((blpix)*xspace);
									
			le_s_in=(int)((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely);
			le_p_in=(int)((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx);

			ri_s_in=(int)((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely);
			ri_p_in=(int)((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx);
								
			//Whole_Image_Trans->Apply(pr,qr,pr1,qr1);
							
			if((inarr1[r][le_s_in][le_p_in]!=NoData && inarr1[s][ri_s_in][ri_p_in]!=NoData) &&flag1==0)
			{
				A1StScan=blscan;
				A2StScan=blscan;
				flag1=1;
			}
			if((inarr1[r][le_s_in][le_p_in]==NoData || inarr1[s][ri_s_in][ri_p_in]==NoData) && flag1==1)
			{
				A1EndScan=blscan-1;
				A2EndScan=blscan-1;
				break;
				//flag=1;
			}							
							
		}							
							
		if(A1StScan!=-1 && A1EndScan!=-1 )
		{
			//fprintf(rrdfile2,"***********************For pixel=%d**************\n",qr);
			
			if(blend_freq==2)
			{
				for(t=A1StScan;t<=A1EndScan;t++)
				{
					blscan =t;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
					blpix= Oinfo[intersect_count].output_st_pixel+qr;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
					//Keep track positions
					//Keep track positions
				
					if(outarr[blscan][blpix]!=NoData && Sflag==0)
					{//firstBlend[2],SecondBlend[2];
						SecondBlend[0]=t;
						Sflag=1;
					}
					else if(outarr[blscan][blpix]==NoData && Sflag==1)
					{
						SecondBlend[1]=t-1;										
						break;
					}						
					else
					{
						SecondBlend[1]=t;
					}
				
				}
				//blending if SECOND time
				if(SecondBlend[0]>=0 &&SecondBlend[1]>=0 )//&&(SecondBlend[1]-SecondBlend[0])>=5)
				{
					int scan_size=SecondBlend[1]-SecondBlend[0];
					int start_scan,end_scan;
					int times=1,Alpha_temp=0,part;					
					if(fifty==1)
					{						
						times=2;						
					}					
					for(part=0;part<times;part++)
					{
						start_scan=SecondBlend[0]+((scan_size/2)+1)*part;
						if(fifty==0)
							end_scan=SecondBlend[1];
						else
							end_scan=(SecondBlend[0]+(scan_size/2)*(1+part));
						if(part==0)
							Alpha_temp=1;
						else
							Alpha_temp=0;

						for(rd=start_scan;rd<=end_scan;rd++)
						{
							blscan =rd;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
							blpix= Oinfo[intersect_count].output_st_pixel+qr;;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
			
							Out_lat1=output_maxy-((blscan)*yspace);//check by giving 0 inplace of r
							Out_lon1=output_minx+((blpix)*xspace);
				
							le_s_in=(int)(((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely)+0.5);
							le_p_in=(int)(((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx)+0.5);

							ri_s_in=(int)(((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely)+0.5);
							ri_p_in=(int)(((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx)+0.5);
			
							//fprintf(rrdfile2,"#L(%d,%d)\t\t\tR(%d,%d)\n",le_s_in,le_p_in,ri_s_in,ri_p_in);
					
							//Actual Blend
						   if(end_scan!=start_scan)
								Alpha=(float)(rd-start_scan)/(end_scan-start_scan);
							else
								Alpha=0.5;
							if(Alpha_temp==1)
								Alpha=1-Alpha;
							//fprintf(rrdfile2,"2L(%d)\t\t\tR(%d)\tAlpha=%f\t(1-Alpha)=%f\tOldB(%d)\t",inarr1[r][le_s_in][le_p_in],inarr1[s][(int)ri_s_in][(int)ri_p_in],Alpha,1-Alpha,outarr[blscan][blpix]);
					
							
							//outarr[blscan][blpix]=(int)((double)(outarr[blscan][blpix]*(Alpha))+(double)(((inarr1[r][le_s_in][le_p_in]+inarr1[s][(int)ri_s_in][(int)ri_p_in])/2.0)*(1-Alpha)));
							//outarr[blscan][blpix]=(int)((double)(outarr[blscan][blpix]*(1-Alpha))+(double)(inarr1[r][le_s_in][le_p_in]*Alpha));
							if(le_s_in < InDem[r].rows && le_p_in < InDem[r].cols && ri_s_in < InDem[s].rows && ri_p_in < InDem[s].cols)
								outarr[blscan][blpix]=(int)(outarr[blscan][blpix]+(int)((double)(inarr1[r][le_s_in][le_p_in]*Alpha)+(double)(inarr1[s][ri_s_in][ri_p_in]*(1-Alpha))))/2.0;
							//outarr[blscan][blpix]=(int)((double)(outarr[blscan][blpix]*(1-Alpha))+(double)(inarr1[s][(int)ri_s_in][(int)ri_p_in]*Alpha));
							//outarr[blscan][blpix]=(int)(outarr[blscan][blpix]+(int)((double)(inarr1[r][le_s_in][le_p_in]*Alpha)+(double)(inarr1[s][(int)ri_s_in][(int)ri_p_in]*(1-Alpha))))/2.0;
							//fprintf(rrdfile2,"usedB(%d)\n",outarr[blscan][blpix]);
							
						}
					}
					
				}
			}
			if(blend_freq==1)
			{
				for(t=A1StScan;t<=A1EndScan;t++)
				{
					blscan =t;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
					blpix= Oinfo[intersect_count].output_st_pixel+qr;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
					//Keep track positions
									
					if(outarr[blscan][blpix]==NoData && Fflag==0)
					{
						//firstBlend[2],SecondBlend[2];
						firstBlend[0]=t;
						Fflag=1;
					}
					else if(outarr[blscan][blpix]!=NoData && Fflag==1)
					{
						firstBlend[1]=t-1;
						break;
					}	
					else
					{
						firstBlend[1]=t;
					}
									
				}
								
				//blending if first time
				if(firstBlend[0]>=0 &&firstBlend[1]>=0)// &&(firstBlend[1]-firstBlend[0])>=50)
				{
					int scan_size=firstBlend[1]-firstBlend[0];
					
					int times=1,Alpha_temp=0;					
					if(fifty==1)
					{						
						times=2;						
					}					
					for(int part=0;part<times;part++)
					{
						start_scan=firstBlend[0]+((scan_size/2)+1)*part;
						if(fifty==0)
							end_scan=firstBlend[1];
						else
							end_scan=(firstBlend[0]+(scan_size/2)*(1+part));
						if(part==0)
							Alpha_temp=1;
						else
							Alpha_temp=0;
						fprintf(fdrr,"(StScan,EnScan)=(%d,%d)\n",start_scan,end_scan);
						for(rd=start_scan;rd<=end_scan;rd++)
						{
							Bil_Flag=false;
							blscan =rd;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
							blpix= Oinfo[intersect_count].output_st_pixel+qr;;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
								
							
							Out_lat1=output_maxy-((blscan)*yspace);//check by giving 0 inplace of r
							Out_lon1=output_minx+((blpix)*xspace);
									
							//le_s_in=(int)((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely);
							//le_p_in=(int)((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx);
							//For CC
							X_Residual=((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx);
							Y_Residual=((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely);
							le_s_in=(int)Y_Residual;
							le_p_in=(int)X_Residual;							
							if(le_s_in >= 0 && le_s_in+1 <= InDem[r].rows-1 && le_p_in >= 0 && le_p_in+1 <= InDem[r].cols-1)
							{
								for(k=0;k<=1;k++)
								{
									for(l=0;l<=1;l++)
									{
										//printf("\n%d\t%d\n",k,l);
										cc_adj[k][l]=inarr1[r][le_s_in+k][le_p_in+l];
										if(cc_adj[k][l]==NoData && Bil_Flag==false)
										{
											Bil_Flag=true;
											k=2;
											break;
										}
										//printf("inarr1[%d][%d][%d]=%d\n",r,le_s_in+k,le_p_in+l,inarr1[r][le_s_in+k][le_p_in+l]);
										//printf("cc_adj[%d][%d]=%d\n",k,l,cc_adj[k][l]);
									}
								}	
								if(Bil_Flag==true)
								{
									le_s_in=(int)(((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely)+0.5);
									le_p_in=(int)(((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx)+0.5);
									if(le_s_in < InDem[r].rows && le_p_in < InDem[r].cols)
										Left_Ht=inarr1[r][le_s_in][le_p_in];
								}
								else
								{
									Left_Ht=Bilinear(X_Residual,Y_Residual,cc_adj);
								}
								
								//printf("Left_Ht=%d\n",Left_Ht);
								//Left_Ht=cubic_conv(X_Residual,Y_Residual,cc_adj);
							}
							else
							{
								le_s_in=(int)(((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely)+0.5);
								le_p_in=(int)(((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx)+0.5);
								if(le_s_in < InDem[r].rows && le_p_in < InDem[r].cols)
									Left_Ht=inarr1[r][le_s_in][le_p_in];
							}
							//Added in 2017
							fprintf(fdrr,"T=%d\t",Left_Ht);
							//Left_Ht=0.0,Right_Ht=0.0;
							
							//EOF CC
							//ri_s_in=(int)((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely);
							//ri_p_in=(int)((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx);

							Bil_Flag=false;
							X_Residual=((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx);
							Y_Residual=((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely);
							ri_s_in=(int)Y_Residual;
							ri_p_in=(int)X_Residual;
							if(ri_s_in >= 0 && ri_s_in+1 <= InDem[s].rows-1 && ri_p_in >= 0 && ri_p_in+1 <= InDem[s].cols-1)
							{
								for(k=0;k<=1;k++)
								{
									for(l=0;l<=1;l++)
									{								
										cc_adj[k][l]=inarr1[s][ri_s_in+k][ri_p_in+l];	
										if(cc_adj[k][l]==NoData && Bil_Flag==false)
										{
											Bil_Flag=true;
											k=2;
											break;
										}
										//printf("\nRight\ninarr1[%d][%d][%d]=%d\n",r,ri_s_in+k,ri_p_in+l,inarr1[s][ri_s_in+k][ri_p_in+l]);
										//printf("cc_adj[%d][%d]=%d\n",k,l,cc_adj[k][l]);
									}
								}	
								if(Bil_Flag==true)
								{
									ri_s_in=(int)(((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely)+0.5);
									ri_p_in=(int)(((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx)+0.5);
									if(ri_s_in < InDem[s].rows && ri_p_in < InDem[s].cols)
										Right_Ht=inarr1[s][ri_s_in][ri_p_in];
								}
								else
								{
									Right_Ht=Bilinear(X_Residual,Y_Residual,cc_adj);
								}
								//Right_Ht=cubic_conv(X_Residual,Y_Residual,cc_adj);
								
								//printf("Right_Ht=%d\n",Right_Ht);
							}
							else
							{
								ri_s_in=(int)(((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely)+0.5);
								ri_p_in=(int)(((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx)+0.5);
								if(ri_s_in < InDem[s].rows && ri_p_in < InDem[s].cols)
									Right_Ht=inarr1[s][ri_s_in][ri_p_in];
							}
							fprintf(fdrr,"B=%d\t",Right_Ht);
							//Actual Blend
							if(start_scan!=end_scan)
								Alpha=(float)(rd-start_scan)/(end_scan-start_scan);
							else
								Alpha=0.5;

							if(Alpha_temp==1)
								Alpha=1-Alpha;
							if((le_s_in < InDem[r].rows && le_p_in < InDem[r].cols) && (ri_s_in < InDem[s].rows && ri_p_in < InDem[s].cols))
							{
								if(inarr1[r][le_s_in][le_p_in]!=NoData && inarr1[s][ri_s_in][ri_p_in]==NoData)
								{								
									outarr[blscan][blpix]=Left_Ht;
								}
								else if(inarr1[r][le_s_in][le_p_in]==NoData && inarr1[s][ri_s_in][ri_p_in]!=NoData)
								{								
									outarr[blscan][blpix]=Right_Ht;
								}
								else if(inarr1[r][le_s_in][le_p_in]==NoData || inarr1[s][ri_s_in][ri_p_in]==NoData)
								{
									outarr[blscan][blpix]=NoData;
								}
								else//case A & caseB
								{
									if(LorR=='L')
										outarr[blscan][blpix]=(int)(((double)(Left_Ht*(Alpha))+(double)(Right_Ht*(1-Alpha)))+0.5);	
									else if(LorR=='R')
										outarr[blscan][blpix]=(int)(((double)(Left_Ht*(1-Alpha))+(double)(Right_Ht*(Alpha)))+0.5);	
									else
										outarr[blscan][blpix]=(int)(((double)(Left_Ht*(Alpha))+(double)(Right_Ht*(1-Alpha)))+0.5);	
								}
								fprintf(fdrr,"A[%d][%d]=%d\tAlpha=%f\n",blscan,blpix,outarr[blscan][blpix],Alpha);
								
								//if(inarr1[r][le_s_in][l-e_p_in]<0 || inarr1[s][(int)ri_s_in][(int)ri_p_in]<0)
								//{
								//	outarr[blscan][blpix]=(inarr1[r][le_s_in][le_p_in]+inarr1[s][(int)ri_s_in][(int)ri_p_in])/2.0;
								//	//printf("T2BLeft=%d\tRight=%d\n",inarr1[r][le_s_in][le_p_in],inarr1[s][(int)ri_s_in][(int)ri_p_in]);
								//	//printf("Blend=%d\n",outarr[blscan][blpix]);
								//}
									//outarr[blscan][blpix]=(int)((double)(outarr[blscan][blpix]*(1-Alpha))+(double)(inarr1[r][le_s_in][le_p_in]*Alpha));
									//outarr[blscan][blpix]=(int)((double)(outarr[blscan][blpix]*(1-Alpha))+(double)(inarr1[s][(int)ri_s_in][(int)ri_p_in]*Alpha));
									//outarr[blscan][blpix]=(int)((double)(inarr1[r][le_s_in][le_p_in]*(1-Alpha))+(double)(inarr1[s][(int)ri_s_in][(int)ri_p_in]*(Alpha)));	
									//outarr[blscan][blpix]=(int)((double)(inarr1[r][le_s_in][le_p_in]*(Alpha))+(double)(inarr1[s][(int)ri_s_in][(int)ri_p_in]*(1-Alpha)));	

							}
							

							/*if((A1EndPix-A1StPix)-(firstBlend[1]-firstBlend[0])>1)
								CohFlag=1;*/
									
						}
					}		
					

				}
			}//EOF First time blending
			
		}
							
								
								
		}
return 0;
}
int MyDEMFilter::L2R_Blend(FILE *rrdfile1,int blend_freq,int fifty,char LorR,struct input_dem *InDem,struct Overlap_Info *Oinfo,int array1_scans,int array1_pixels,int intersect_count,double output_maxy,double output_minx,int r,int s,signed short int **outarr,signed short int ***inarr1, double &xspace,double &yspace)
{	/****************************LEFT 2 RIGHT******************************/					   
	
	int A1StPix,A1EndPix,A2StPix,A2EndPix;
	int A1StScan,A1EndScan,A2StScan,A2EndScan;
	int rd,blscan,blpix,le_s_in,le_p_in,ri_s_in,ri_p_in;
	int firstBlend[2],SecondBlend[2];
	int scan_size,start_scan,end_scan;
	float Alpha=0.0,Hermite=0.0;
	double Out_lat1,Out_lon1;
	int pr=0,qr=0,t,k,l;
	bool Bil_Flag=false;
	//This is declaration section for CC interpolation
	signed short int Left_Ht=0,Right_Ht=0,NoData=NoDataVal;
	double X_Residual=0.0,Y_Residual=0.0;
	signed short int **cc_adj;
	cc_adj=(signed short int **)malloc(sizeof(signed short int *)*2);
	for(pr=0;pr<2;pr++)
		cc_adj[pr]=(signed short int *)malloc(sizeof(signed short int)*2);	
	for(pr=0;pr<2;pr++)	
		for(qr=0;qr<2;qr++)
			cc_adj[pr][qr]=NoData;
	fprintf(fdrr,"L2R\n");
	//EOF CC initialization	
	for(pr=0;pr<array1_scans;pr++)
	{
		int flag1=0;
		int Fflag=0,Sflag=0,CohFlag=0;							
		A1StPix=-1;A1EndPix=-1,A2StPix=-1,A2EndPix=-1;
		for(rd=0;rd<2;rd++)
		{
			firstBlend[rd]=-1;								
			SecondBlend[rd]=-1;								
		}
		for(qr=0;qr<array1_pixels;qr++)
		{
			
			blscan =Oinfo[intersect_count].output_st_scan+pr;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
			blpix= Oinfo[intersect_count].output_st_pixel+qr;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
								
			Out_lat1=output_maxy-((blscan)*yspace);//check by giving 0 inplace of r
			Out_lon1=output_minx+((blpix)*xspace);							
			le_s_in=(int)((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely);
			le_p_in=(int)((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx);

			ri_s_in=(int)((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely);
			ri_p_in=(int)((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx);

								
			/*le_s_in=(int)((double)(InDem[r].ul_y-Oinfo[intersect_count].ul_y+pr*InDem[0].dely)/(double)InDem[r].dely);
			le_p_in=(int)((double)(Oinfo[intersect_count].ul_x+qr*InDem[0].delx-InDem[r].ul_x)/(double)InDem[r].delx);

			ri_s_in=(int)((double)(InDem[s].ul_y-Oinfo[intersect_count].ul_y+pr*InDem[0].dely)/(double)InDem[s].dely);
			ri_p_in=(int)((double)(Oinfo[intersect_count].ul_x+qr*InDem[0].delx-InDem[s].ul_x)/(double)InDem[s].delx);
			*///Whole_Image_Trans->Apply(pr,qr,pr1,qr1);
							
			if((inarr1[r][le_s_in][le_p_in]!=NoData && inarr1[s][ri_s_in][ri_p_in]!=NoData) &&flag1==0)
			{
				A1StPix=blpix;
				A2StPix=blpix;
				flag1=1;
			}
			if((inarr1[r][le_s_in][le_p_in]==NoData || inarr1[s][ri_s_in][ri_p_in]==NoData) && flag1==1)
			{
				A1EndPix=blpix-1;
				A2EndPix=blpix-1;
				break;
				//flag=1;
			}							
							
		}
							
		//Handle for each scan at a time
		if(A1StPix!=-1 && A1EndPix!=-1 )
		{
			//fprintf(rrdfile1,"***********************For Scan=%d**************\n",pr);
			if(blend_freq==2)
			{
				for(t=A1StPix;t<=A1EndPix;t++)
				{
					blscan =Oinfo[intersect_count].output_st_scan+pr;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
					blpix= t;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
					//Keep track positions
					//Keep track positions
									
					if(outarr[blscan][blpix]!=NoData && Sflag==0)
					{//firstBlend[2],SecondBlend[2];
						SecondBlend[0]=t;
						Sflag=1;
					}
					else if(outarr[blscan][blpix]==NoData && Sflag==1)
					{
						SecondBlend[1]=t-1;										
						break;
					}						
					else
					{
						SecondBlend[1]=t;
					}
									
				}
				//blending if SECOND time
				if(SecondBlend[0]>=0 &&SecondBlend[1]>=0)
				{
					int pixel_size=SecondBlend[1]-SecondBlend[0];
					int start_pix,end_pix;
					int times=1,Alpha_temp=0,part;					
					if(fifty==1)
					{						
						times=2;						
					}					
					for(part=0;part<times;part++)
					{
						start_pix=SecondBlend[0]+((pixel_size/2)+1)*part;
						if(fifty==0)
							end_pix=SecondBlend[1];
						else
							end_pix=(SecondBlend[0]+(pixel_size/2)*(1+part));
						if(part==0)
							Alpha_temp=1;
						else
							Alpha_temp=0;
						for(rd=start_pix;rd<=end_pix;rd++)
						{
							blscan =Oinfo[intersect_count].output_st_scan+pr;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
							blpix= rd;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
								
							Out_lat1=output_maxy-((blscan)*yspace);//check by giving 0 inplace of r
							Out_lon1=output_minx+((blpix)*xspace);
									
							le_s_in=(int)(((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely)+0.5);
							le_p_in=(int)(((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx)+0.5);

							ri_s_in=(int)(((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely)+0.5);
							ri_p_in=(int)(((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx)+0.5);
								
							//fprintf(rrdfile1,"#L(%d,%d)\t\t\tR(%d,%d)\n",le_s_in,le_p_in,ri_s_in,ri_p_in);
										
							//Actual Blend
							if(end_pix!=start_pix)
								Alpha=(float)(rd-start_pix)/(end_pix-start_pix);
							else
								Alpha=0.5;
							if(Alpha_temp==1)
								Alpha=1-Alpha;
							//raj=0;
							//fprintf(rrdfile1,"2L(%d)\t\t\tR(%d)\tAlpha=%f\t(1-Alpha)=%f\tOldB(%d)\t",inarr1[r][le_s_in][le_p_in],inarr1[s][(int)ri_s_in][(int)ri_p_in],Alpha,1-Alpha,outarr[blscan][blpix]);
							if(le_s_in < InDem[r].rows && le_p_in < InDem[r].cols && ri_s_in < InDem[s].rows && ri_p_in < InDem[s].cols)
							{
								if(inarr1[r][le_s_in][le_p_in]!=0 && inarr1[s][ri_s_in][ri_p_in]==0)
								{
									//printf("L2R FBexist=%d\tLeft=%d\tRight=%d\n",outarr[blscan][blpix],inarr1[r][le_s_in][le_p_in],inarr1[s][(int)pr1][(int)t1]);
									outarr[blscan][blpix]=(int)((outarr[blscan][blpix])+(inarr1[r][le_s_in][le_p_in]))/2.0;
													
									//printf("Blend=%d\n",outarr[blscan][blpix]);
								}
								else if(inarr1[r][le_s_in][le_p_in]==0 && inarr1[s][ri_s_in][ri_p_in]!=0)
								{
									//printf("L2R FBexist=%d\tLeft=%d\tRight=%d\n",outarr[blscan][blpix],inarr1[r][le_s_in][le_p_in],inarr1[s][(int)pr1][(int)t1]);
								
									outarr[blscan][blpix]=(int)((outarr[blscan][blpix])+(inarr1[s][ri_s_in][ri_p_in]))/2.0;					
									//printf("Blend=%d\n",outarr[blscan][blpix]);
								}
								else 
									outarr[blscan][blpix]=(int)(outarr[blscan][blpix])+(int)((double)((inarr1[r][le_s_in][le_p_in]*Alpha)+(double)(inarr1[s][ri_s_in][ri_p_in]*(1-Alpha))))/2.0;
							
							
							}
							//outarr[blscan][blpix]=(int)((double)(outarr[blscan][blpix]*Alpha)+(((double)(inarr1[r][le_s_in][le_p_in]+inarr1[s][(int)ri_s_in][(int)ri_p_in])/2.0)*(1-Alpha)));
							
							//fprintf(rrdfile1,"B(%d)\n",outarr[blscan][blpix]);
							
							//fprintf(rrdfile1,"usedB(%d)\n",outarr[blscan][blpix]);
						}
					}
					
				}
			}
			if(blend_freq==1)
			{
				for(t=A1StPix;t<=A1EndPix;t++)
				{
					blscan =Oinfo[intersect_count].output_st_scan+pr;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
					blpix= t;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
					//Keep track positions									
					if(outarr[blscan][blpix]==NoData && Fflag==0)
					{
						//firstBlend[2],SecondBlend[2];
						firstBlend[0]=t;
						Fflag=1;
					}
					else if(outarr[blscan][blpix]!=NoData && Fflag==1)
					{
						firstBlend[1]=t-1;
						break;
					}	
					else
					{
						firstBlend[1]=t;
					}
									
				}
								
				//blending if first time
				if(firstBlend[0]>=0 &&firstBlend[1]>=0)// && (firstBlend[1]-firstBlend[0])>=50)
				{					
					int pixel_size=firstBlend[1]-firstBlend[0];
					int start_pix,end_pix;
					int times=1,Alpha_temp=0,part;					
					if(fifty==1)
					{						
						times=2;						
					}					
					for(part=0;part<times;part++)
					{
						start_pix=firstBlend[0]+((pixel_size/2)+1)*part;
						if(fifty==0)
							end_pix=firstBlend[1];
						else
							end_pix=(firstBlend[0]+(pixel_size/2)*(1+part));
						if(part==0)
							Alpha_temp=1;
						else
							Alpha_temp=0;
						fprintf(fdrr,"(StPix,EnPix)=(%d,%d)\n",start_pix,end_pix);
						for(rd=start_pix;rd<=end_pix;rd++)
						{
							Bil_Flag=false;
							blscan =Oinfo[intersect_count].output_st_scan+pr;//(int)((double)(Oinfo[intersect_count].ul_y-Out_lat1)/(double)InDem[0].dely);;
							blpix= rd;//t is current pixel(instead of qr)(int)((double)(Out_lon1-Oinfo[intersect_count].ul_x)/(double)InDem[0].delx);;//
								
							Out_lat1=output_maxy-((blscan)*yspace);//check by giving 0 inplace of r
							Out_lon1=output_minx+((blpix)*xspace);
									
							//le_s_in=(int)((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely);
							//le_p_in=(int)((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx);
							//For CC
							X_Residual=((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx);
							Y_Residual=((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely);
							le_s_in=(int)Y_Residual;
							le_p_in=(int)X_Residual;
							/*if(blscan>=491 && blscan<=494 && blpix >=5524 && blpix<=5531)
								int j=0;*/

							if(le_s_in >= 0 && le_s_in+1 <= InDem[r].rows-1 && le_p_in >= 0 && le_p_in+1 <= InDem[r].cols-1)
							{
								for(k=0;k<=1;k++)
								{
									for(l=0;l<=1;l++)
									{								
										cc_adj[k][l]=inarr1[r][le_s_in+k][le_p_in+l];
										if(cc_adj[k][l]==NoData && Bil_Flag==false)
										{
											Bil_Flag=true;
											k=2;
											break;
										}
									}
								}	
								if(Bil_Flag==true)
								{
									le_s_in=(int)(((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely)+0.5);
									le_p_in=(int)(((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx)+0.5);
									if(le_s_in < InDem[r].rows && le_p_in < InDem[r].cols)
										Left_Ht=inarr1[r][le_s_in][le_p_in];
								}
								else
								{
									Left_Ht=Bilinear(X_Residual,Y_Residual,cc_adj);
								}
								
								//Left_Ht=cubic_conv(X_Residual,Y_Residual,cc_adj);
							}
							else
							{
								le_s_in=(int)(((double)(InDem[r].ul_y-Out_lat1)/(double)InDem[r].dely)+0.5);
								le_p_in=(int)(((double)(Out_lon1-InDem[r].ul_x)/(double)InDem[r].delx)+0.5);
								if(le_s_in < InDem[r].rows && le_p_in < InDem[r].cols)
									Left_Ht=inarr1[r][le_s_in][le_p_in];
							}
							fprintf(fdrr,"L=%d\t",Left_Ht);
							//Left_Ht=0.0,Right_Ht=0.0;
							
							//EOF CC
							//ri_s_in=(int)((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely);
							//ri_p_in=(int)((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx);
							Bil_Flag=false;	
							X_Residual=((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx);
							Y_Residual=((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely);
							ri_s_in=(int)Y_Residual;
							ri_p_in=(int)X_Residual;							

							if(ri_s_in >= 0 && ri_s_in+1 <= InDem[s].rows-1 && ri_p_in >= 0 && ri_p_in+1 <= InDem[s].cols-1)
							{
								for(k=0;k<=1;k++)
								{
									for(l=0;l<=1;l++)
									{								
										cc_adj[k][l]=inarr1[s][ri_s_in+k][ri_p_in+l];
										if(cc_adj[k][l]==NoData && Bil_Flag==false)
										{
											Bil_Flag=true;
											k=2;
											break;
										}
									}
								}	
								if(Bil_Flag==true)
								{
									ri_s_in=(int)(((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely)+0.5);
									ri_p_in=(int)(((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx)+0.5);
									if(ri_s_in < InDem[s].rows && ri_p_in < InDem[s].cols)
										Right_Ht=inarr1[s][ri_s_in][ri_p_in];
								}
								else
								{
									Right_Ht=Bilinear(X_Residual,Y_Residual,cc_adj);
								}
								//Right_Ht=cubic_conv(X_Residual,Y_Residual,cc_adj);
								
							}
							else
							{
								ri_s_in=(int)(((double)(InDem[s].ul_y-Out_lat1)/(double)InDem[s].dely)+0.5);
								ri_p_in=(int)(((double)(Out_lon1-InDem[s].ul_x)/(double)InDem[s].delx)+0.5);
								if(ri_s_in < InDem[s].rows && ri_p_in < InDem[s].cols)
									Right_Ht=inarr1[s][ri_s_in][ri_p_in];
							}
							fprintf(fdrr,"R=%d\t",Right_Ht);
							//eof
							if(start_pix!=end_pix)
								Alpha=(float)(rd-start_pix)/(end_pix-start_pix);
							else
								Alpha=0.5;
							
							if(Alpha_temp==1)
								Alpha=1-Alpha;							
										
							if((le_s_in < InDem[r].rows && le_p_in < InDem[r].cols) && (ri_s_in < InDem[s].rows && ri_p_in < InDem[s].cols))
							{
								if(inarr1[r][le_s_in][le_p_in]!=NoData && inarr1[s][ri_s_in][ri_p_in]==NoData)
								{
									outarr[blscan][blpix]=(Left_Ht);
								}
								else if(inarr1[r][le_s_in][le_p_in]==NoData && inarr1[s][ri_s_in][ri_p_in]!=NoData)
								{						
									outarr[blscan][blpix]=(Right_Ht);
								}
								else if(inarr1[r][le_s_in][le_p_in]==NoData && inarr1[s][ri_s_in][ri_p_in]==NoData)
								{
									outarr[blscan][blpix]=NoData;
								}
								else
								{
									if(LorR=='L')								
										outarr[blscan][blpix]=(int)(((double)(Left_Ht*(Alpha))+(double)(Right_Ht*(1-Alpha)))+0.5);	
									else if(LorR=='R')
										outarr[blscan][blpix]=(int)(((double)(Left_Ht*(1-Alpha))+(double)(Right_Ht*(Alpha)))+0.5);	
									else
										outarr[blscan][blpix]=(int)(((double)(Left_Ht*(Alpha))+(double)(Right_Ht*(1-Alpha)))+0.5);									
									
								}	
								fprintf(fdrr,"A[%d][%d]=%d\tAlpha=%f\n",blscan,blpix,outarr[blscan][blpix],Alpha);
							}
						}
					}
					//fprintf(rrdfile1,"***********************From Scan=%dtoScan=%d**************\n",start_scan,end_scan);
					
						//fprintf(rrdfile1,"L(%d)\t\t\tR(%d)\tAlpha=%f\t(1-Alpha)=%f\tBlend(%d)\n",inarr1[r][le_s_in][le_p_in],inarr1[s][(int)pr1][(int)t1],Alpha,1-Alpha,outarr[blscan][blpix]);
						//fprintf(rrdfile1,"usedB(%d)\n",outarr[blscan][blpix]);	
										
					}
					
				}
			}

		}
							
							
								
		
	return 0;
}

 vector<string> MyDEMFilter::Mosaic_TwoAtaTime(char infile[300],std::vector<string> Pathwise1,int path1,int fl,char out[300],int North,int East)
{
	vector<string> Pathwise_Phases;
	vector<string> Pathwise_Final;
	vector<string> temp;
	int Phase_count=0;
	int Con_flag=1;
	int it_count=0;
	int pat=path1;
	char med_file[300];
	char Orbs_temp[30];
	while(Con_flag!=0 )
	{
		if(Pathwise1.size() > 2)
		{
			Phase_count=0;
			Pathwise_Phases.clear();
			strcpy(Orbs_temp,"");
			for(int ii=0;ii<Pathwise1.size();ii++)
			{
				
				if(Phase_count<2)
				{
					Pathwise_Phases.push_back(Pathwise1[ii]);
					if(Phase_count==1)
						strcat(Orbs_temp,"_");
					int inde1 = (Pathwise1[ii]).find_last_of ("Orbit");
					int inde2 = (Pathwise1[ii]).find_last_of (".");
					strcat(Orbs_temp,(Pathwise1[ii]).substr(inde1+1,inde2-inde1-1).c_str());
					
					
					//To do
					if(fl==1)
					{
						int index1 = (Pathwise1[ii]).find_last_of ("\\");
	
						pat =atoi((Pathwise1[ii]).substr(index1+4,3).c_str());
					}
					Phase_count++;
				}
				if(Phase_count==2)
				{				
					//Added 2017
					
					sprintf(dummy,"%s%sFor%dCount%s.txt",infile,"\\",pat,Orbs_temp);	
					if( (err  = fopen_s( &fdrr, dummy, "w+" )) !=0 )
					{
						printf( "The output file: %s was not opened\n",dummy);
						//return -1;
					}
					//sprintf(med_file,"%s%sFor%dCount%d.DEM",infile,"\\",pat,it_count);	
					sprintf(med_file,"%s%sFor%dCount%s.DEM",infile,"\\",pat,Orbs_temp);	
					strcpy(Orbs_temp,"");
					temp.push_back(med_file);
					if(fl==1)
						Mosaic_process(Pathwise_Phases,infile,'H',med_file,0,North,East);//,0);
					else
						Mosaic_process(Pathwise_Phases,infile,'C',med_file,0,North,East);//,0);
					fclose(fdrr);
					Pathwise_Phases.clear();
					if(ii!=Pathwise1.size()-1)
					{
						//Pathwise_Phases.push_back(Pathwise1[ii]);
						Phase_count=0;	
					}
					else
					{
						Con_flag=1;
					}
				}
			}
			if(Con_flag==1)
			{
				if(Pathwise_Phases.size()==1)
					temp.push_back(Pathwise_Phases[0]);
				Pathwise1.clear();
				Pathwise1=temp;
				temp.clear();
			}
		}
		else
		{
			char final_file[300];
			
			if(fl==0)
			{
				//Added 2017
				sprintf(dummy,"%s%sFor%d_%d.txt",infile,"\\",path1,it_count);	
				if( (err  = fopen_s( &fdrr, dummy, "w+" )) !=0 )
				{
					printf( "The output file: %s was not opened\n",dummy);
					//return -1;
				}
				//EOF 2017
				sprintf(final_file,"%s%sFor%d_%d.DEM",infile,"\\",path1,it_count);
				Pathwise_Final.push_back(final_file);
				//cout<<"Pathwise_Final size="<<Pathwise_Final.size()<<endl;
				Mosaic_process(Pathwise1,infile,'C',final_file,fl,North,East);//,0);
				Con_flag=0;
			}
			else
			{
				//Added 2017
				sprintf(dummy,"%s%s%s.txt",infile,"\\",out);	
				if( (err  = fopen_s( &fdrr, dummy, "w+" )) !=0 )
				{
					printf( "The output file: %s was not opened\n",dummy);
					//return -1;
				}
				//EOF 2017
				sprintf(final_file,"%s%s%s",infile,"\\",out);
				Mosaic_process(Pathwise1,infile,'H',final_file,fl,North,East);//,zeroflag);
				Con_flag=0;
			}
		}

		it_count++;
	}
	fclose(fdrr);
	Pathwise_Phases.clear();

	
	return Pathwise_Final;
	
}
 int MyDEMFilter::Delete_TempFiles(vector<string> TempFiles)
 {
	 for(int jj=0;jj<TempFiles.size();jj++)
	 {
		//cout<<"Deleting.."<<TempFiles[jj]<<endl;
		CString cmd;
		stringstream exe, arglist;			
		exe << "Del";			
		arglist << TempFiles[jj];		
		cmd.Format("%s %s",exe.str().c_str(), arglist.str().c_str());		
		system(cmd.operator LPCSTR());

	 }
	 return 0;
 }
 bool MyDEMFilter::BasedonPathRow (string elem1, string elem2 )
{
	//P5030007_1P_20101120_494252.DEM
	int index1 = elem1.find_last_of ("_");
	int index2 = elem2.find_last_of ("_");

	string pathrow1 = (elem1).substr(index1+1,6).c_str();	
	string pathrow2 = (elem2).substr(index2+1,6).c_str();			
   return pathrow1 < pathrow2;
}
int MyDEMFilter::Compute_Delxy(double minx,double maxx,double miny,double maxy,float Resolution,double &xspace,double &yspace)//Computes DelX and DelY spacing for Output(Mosaicked DEM)
{
	//1. Compute Mid Lat and Mid Lon of the Output grid	
	double mid_lat= (double)(miny+maxy)/2.0;
	//2. Input the computed Mid Lat to the below method	
	double PI_VAL=3.1415926535897932384626433832795;
	double rlat=(mid_lat)*PI_VAL/180.0;
	double p_deg = (111415.13 * cos(rlat) - 94.55 * cos(3 * rlat)); //1 deg. lon direction 
	double m_deg = (111132.09  -566.05 * cos(2 * rlat) + 1.2 * cos(4 * rlat)); //1 deg. lat direction

	xspace=Resolution/p_deg;
	yspace=Resolution/m_deg;
	//Errors: (original_lat-computed_lat)*m,(original_lon-computed_lon)*p;//in meters
	return 0;
}
int MyDEMFilter::orientation(double Px, double Py, double Qx, double Qy, double Rx, double Ry)//int orientation(Point p, Point q, Point r)
{
	double val = (Qy - Py) * (Rx - Qx) - (Qx - Px) * (Ry - Qy);

	if (val == 0) return 0;  // collinear
	return (val > 0) ? 1 : 2; // clock or counterclock wise
}
	
bool MyDEMFilter::onSegment(double Px, double Py, double Qx, double Qy, double Rx, double Ry)
{
	// Given three colinear points p, q, r, the function checks if
	// point q lies on line segment 'pr'
	if (Qx <= Math::Max(Px, Rx) && Qx >= Math::Min(Px, Rx) && Qy <= Math::Max(Py, Ry) && Qy >= Math::Min(Py, Ry))
		return true;
	return false;


}
// Returns true if the point p lies inside the polygon[] with n vertices
//bool MyDEMFilter::isInside(double a1x, double a1y, double b1x, double b1y, double c1x, double c1y, double d1x, double d1y, int n, double t1x,double t1y)
//{
//    // There must be at least 3 vertices in polygon[]
//    if (n < 3)  return false;
// 
//    // Create a point for line segment from p to infinite
//    Point extreme = {INF, p.y};
// 
//    // Count intersections of the above line with sides of polygon
//    int count = 0, i = 0;
//    do
//    {
//        int next = (i+1)%n;
// 
//        // Check if the line segment from 'p' to 'extreme' intersects
//        // with the line segment from 'polygon[i]' to 'polygon[next]'
//        if (doIntersect(polygon[i], polygon[next], p, extreme))
//        {
//            // If the point 'p' is colinear with line segment 'i-next',
//            // then check if it lies on segment. If it lies, return true,
//            // otherwise false
//            if (orientation(polygon[i], p, polygon[next]) == 0)
//               return onSegment(polygon[i], p, polygon[next]);
// 
//            count++;
//        }
//        i = next;
//    } while (i != 0);
// 
//    // Return true if count is odd, false otherwise
//    return count&1;  // Same as (count%2 == 1)
//}
bool MyDEMFilter::doIntersect(double p1x, double p1y, double q1x, double q1y, double p2x, double p2y, double q2x, double q2y)
{
    // Find the four orientations needed for general and
    // special cases
    int o1 = orientation(p1x,p1y, q1x,q1y, p2x,p2y);
    int o2 = orientation(p1x, p1y, q1x, q1y, q2x,q2y);
    int o3 = orientation(p2x,p2y, q2x,q2y, p1x, p1y);
    int o4 = orientation(p2x, p2y, q2x, q2y, q1x,q1y);

    // General case
    if (o1 != o2 && o3 != o4)
	{
		//sideno=side;
        return true;
		//return side;
	}

    // Special Cases
    // p1, q1 and p2 are colinear and p2 lies on segment p1q1
    if (o1 == 0 && onSegment(p1x, p1y, p2x, p2y, q1x, q1y)) 
	{
		//sideno=side;
		return true;
		//return side;
	}

    // p1, q1 and p2 are colinear and q2 lies on segment p1q1
    if (o2 == 0 && onSegment(p1x, p1y, q2x, q2y, q1x, q1y)) 
	{
		//sideno=side;	
		return true;
		//return side;
	}

    // p2, q2 and p1 are colinear and p1 lies on segment p2q2
    if (o3 == 0 && onSegment(p2x, p2y, p1x, p1y, q2x, q2y))
	{
		//sideno=side;	
		return true;
		//return side;
	}

    // p2, q2 and q1 are colinear and q1 lies on segment p2q2
    if (o4 == 0 && onSegment(p2x, p2y, q1x, q1y, q2x, q2y)) 
	{
		//sideno=side;	
		return true;
		//return side;
	}

    return false; // Doesn't fall in any of the above cases
}
//struct overlap_struct MyDEMFilter::computeInters_point(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4)
// {
//	 double c1=0.0,m1=0.0,c2=0.0,m2=0.0;
//	 double *inter1;
//	 inter1=(double *)malloc(sizeof(double)*2);
//	 struct overlap_struct OverlapDEM;
//	 //OverlapDEM=(struct overlap_struct *)malloc(sizeof(struct overlap_struct));
//
//	 m1=(double)(y2-y1)/(double)(x2-x1);
//	 m2=(double)(y4-y3)/(double)(x4-x3);
//	 c1=(double)((y1*x2)-(y2*x1))/(double)(x2-x1);
//	 c2=(double)((y3*x4)-(y4*x3))/(double)(x4-x3);
//	 inter1[0]=(double)(c2-c1)/(double)(m1-m2);
//	 inter1[1]=(double)(m1*c2-c1*m2)/(double)(m1-m2);
//	 OverlapDEM.ul_x=inter1[0];
//	 OverlapDEM.ul_y=inter1[1];
//	 return OverlapDEM;
// }

bool MyDEMFilter::quickRejection_Passed(double rx1, double ry1, double rx2, double ry2, double rx3, double ry3, double rx4, double ry4,int side)
{
	bool rr = false;
	
	if ((Math::Max(rx1, rx2) >= Math::Min(rx3, rx4)) && (Math::Max(rx3, rx4) >= Math::Min(rx1, rx2)) && (Math::Max(ry1, ry2) >= Math::Min(ry3, ry4)) && (Math::Max(ry3, ry4) >= Math::Min(ry1, ry2)))
	{
		rr=true;
	}
	else
	{
		//sideno=0;
		rr= false;
	}
	if (rr)
	{
		if (doIntersect(rx1, ry1, rx2, ry2, rx3, ry3, rx4, ry4))
		{
			//sideno=side;
			return true;

		}
		else
		{
			//sideno=0;
			return false;
		}
	}
	else
	{
		//sideno=0;
		return false;					
	}

//throw new NotImplementedException();
}	
 bool MyDEMFilter::isIntersected(double Pt_x1, double Pt_y1, double Pt_x2, double Pt_y2, double Test_x1, double Test_y1, double Test_x2, double Test_y2)
{
	int inter_count = 0;
	bool rr = false;
	double virtual_x1 = Test_x2, virtual_y1 = Test_y2;//Infinite horizontal line,here Inf=1000.00
	int sideno;
	//check no.of intersection that seg(Test_x1,Test_x2--virtual_x1,virtual_y1) makes with the given Poly
	if (quickRejection_Passed(Pt_x1, Pt_y1, Pt_x2, Pt_y2, Test_x1, Test_y1, virtual_x1, virtual_y1,1))
	{
		/*sideno=1;
		return true;*/
		return 1;
               
	}
	//else if (quickRejection_Passed(Pt_x2, Pt_y2, Pt_x3, Pt_y3, Test_x1, Test_y1, virtual_x1, virtual_y1,2))
	//{
	//	/*sideno=2;
	//	return true;*/
	//	return 2;
 //               
	//}
	//else if (quickRejection_Passed(Pt_x3, Pt_y3, Pt_x4, Pt_y4, Test_x1, Test_y1, virtual_x1, virtual_y1,3))
	//{
 //               
	//	/*sideno=3;
	//	return true;*/
	//	return 3;

	//}
	//else if (quickRejection_Passed(Pt_x4, Pt_y4, Pt_x1, Pt_y1, Test_x1, Test_y1, virtual_x1, virtual_y1,4))
	//{
 //               
	//	/*sideno=4;
	//	return true;
 //              */
	//	return 4;
	//}
	else
	{
		/*sideno=0;
		return false;*/
		return 0;
	}
	//return inter_count & 1;  // Same as (count%2 == 1)
}

 

 }




